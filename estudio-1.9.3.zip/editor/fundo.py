"""Tirar o fundo do vídeo principal: máscara da pessoa (IA ou tela verde) + prévia com transparência.

- IA: Robust Video Matting (modelo pequeno, ~15 MB, baixado na 1ª vez) rodando com onnxruntime
  (placa de vídeo pelo DirectML no Windows; senão o processador). Funciona sem tela verde.
- Tela verde (chroma key): o FFmpeg tira a cor escolhida.

A máscara fica no tempo do vídeo original (mascara_<chave>.mkv, tons de cinza: branco = pessoa).
A exportação corta a máscara junto com os trechos; a prévia usa um .webm com transparência."""
from __future__ import annotations

import hashlib
import importlib
import json
import os
import subprocess
import sys
import threading
import urllib.request
from pathlib import Path

from .util import RAIZ, aviso, info, rodar_ffmpeg

MODELO_URL = "https://github.com/PeterL1n/RobustVideoMatting/releases/download/v1.0.0/rvm_mobilenetv3_fp32.onnx"
MODELO = RAIZ / "modelos" / "rvm_mobilenetv3_fp32.onnx"
LADO_IA = 720          # a IA trabalha com o lado menor em 720 px (a máscara é ampliada na exportação)
_trava_instalar = threading.Lock()


# ------------------------------------------------------------------ chaves e arquivos
def chave(cfg_fundo: dict, fonte: Path) -> str:
    met = cfg_fundo.get("metodo", "ia")
    partes = [met, str(fonte.stat().st_size), int(fonte.stat().st_mtime)]
    if met == "chroma":
        c = cfg_fundo.get("chroma") or {}
        partes += [str(c.get("cor", "#00FF00")).upper(), round(float(c.get("tol", 0.3)), 3), round(float(c.get("suave", 0.08)), 3)]
    if met == "vazio":
        vz = cfg_fundo.get("vazio") or {}
        partes += [round(float(vz.get("ini", 0)), 2), round(float(vz.get("fim", 3)), 2), round(float(vz.get("sens", 0.5)), 3),
                   bool(vz.get("sombras", True)), bool(vz.get("alinhar", True))]
    if met in ("ia", "vazio", "marcar"):
        partes.append([[round(float(c.get(k, 0)), 3) for k in ("t", "x", "y", "w", "h")] for c in caixas(cfg_fundo)])
    return hashlib.sha1(json.dumps(partes).encode()).hexdigest()[:12]


def caixas(cfg_fundo: dict) -> list[dict]:
    """Retângulos que o usuário marcou (fantoche, objetos) — x, y, w, h de 0 a 1 no quadro original, no tempo t."""
    out = []
    for c in cfg_fundo.get("caixas") or []:
        try:
            x, y, w, h = (min(1.0, max(0.0, float(c[k]))) for k in ("x", "y", "w", "h"))
            if w > 0.01 and h > 0.01:
                out.append({"t": max(0.0, float(c.get("t", 0))), "x": x, "y": y, "w": min(w, 1 - x), "h": min(h, 1 - y)})
        except (KeyError, TypeError, ValueError):
            continue
    return out[:6]


def arquivos(pasta: Path, ch: str) -> tuple[Path, Path]:
    return pasta / f"mascara_{ch}.mkv", pasta / f"previa_alpha_{ch}.webm"


def pronta(pasta: Path, ch: str) -> bool:
    m, p = arquivos(pasta, ch)
    return m.exists() and m.stat().st_size > 0 and p.exists() and p.stat().st_size > 0


# ------------------------------------------------------------------ IA (onnxruntime)
def _instalar_onnx() -> None:
    with _trava_instalar:
        try:
            importlib.invalidate_caches()
            import onnxruntime  # noqa: F401
            return
        except Exception:  # noqa: BLE001
            pass
        pacote = "onnxruntime-directml" if sys.platform == "win32" else "onnxruntime"
        info(f"Instalando o componente da IA que tira o fundo ({pacote})…")
        exe = Path(sys.executable)
        py = exe.parent / "python.exe" if exe.name.lower() == "pythonw.exe" and (exe.parent / "python.exe").exists() else exe
        uv = RAIZ / "tools" / ("uv.exe" if sys.platform == "win32" else "uv")
        cmd = ([str(uv), "pip", "install", "--python", str(py), pacote] if uv.exists()
               else [str(py), "-m", "pip", "install", "--disable-pip-version-check", pacote])
        r = subprocess.run(cmd, cwd=RAIZ, capture_output=True, text=True, timeout=1800,
                           env={**os.environ, "UV_CACHE_DIR": str(RAIZ / ".cache" / "uv")},
                           **({"creationflags": 0x08000000} if sys.platform == "win32" else {}))
        if r.returncode != 0:
            raise RuntimeError("não consegui instalar o componente da IA: "
                               + ((r.stderr or r.stdout or "").strip().splitlines() or ["?"])[-1][:200])
        importlib.invalidate_caches()


def _modelo() -> Path:
    if MODELO.exists() and MODELO.stat().st_size > 1_000_000:
        return MODELO
    MODELO.parent.mkdir(parents=True, exist_ok=True)
    info("Baixando o modelo da IA que tira o fundo (15 MB, uma vez só)…")
    tmp = MODELO.with_suffix(".parcial")
    req = urllib.request.Request(MODELO_URL, headers={"User-Agent": "EstudioDeVideo"})
    with urllib.request.urlopen(req, timeout=120) as r, open(tmp, "wb") as f:
        while True:
            b = r.read(1 << 20)
            if not b:
                break
            f.write(b)
    tmp.replace(MODELO)
    return MODELO


def _sessao():
    _instalar_onnx()
    import onnxruntime as ort
    disp = ort.get_available_providers()
    prov = [p for p in ("DmlExecutionProvider", "CUDAExecutionProvider", "CPUExecutionProvider") if p in disp] or disp
    try:
        return ort.InferenceSession(str(_modelo()), providers=prov), prov[0]
    except Exception:  # noqa: BLE001  (placa recusou: vai no processador)
        return ort.InferenceSession(str(_modelo()), providers=["CPUExecutionProvider"]), "CPUExecutionProvider"


def _medidas(fonte: Path) -> tuple[int, int, float, float]:
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                        "stream=width,height,avg_frame_rate:stream_side_data=rotation:format=duration", "-of", "json", str(fonte)],
                       capture_output=True, text=True)
    d = json.loads(r.stdout or "{}")
    s = (d.get("streams") or [{}])[0]
    w, h = int(s.get("width", 1080)), int(s.get("height", 1920))
    rot = 0
    for sd in s.get("side_data_list") or []:
        rot = int(float(sd.get("rotation", 0) or 0))
    if abs(rot) in (90, 270):
        w, h = h, w
    num, _, den = str(s.get("avg_frame_rate", "30/1")).partition("/")
    fps = float(num) / float(den or 1) if float(den or 1) else 30.0
    return w, h, fps or 30.0, float((d.get("format") or {}).get("duration", 0) or 0)


def _tam_trabalho(w: int, h: int, lado: int) -> tuple[int, int]:
    k = min(1.0, lado / min(w, h))
    return max(2, int(w * k) // 2 * 2), max(2, int(h * k) // 2 * 2)


def mascara_ia(fonte: Path, saida: Path, fps: float, progresso=None) -> str:
    import numpy as np
    sess, prov = _sessao()
    W, H, _, dur = _medidas(fonte)
    w, h = _tam_trabalho(W, H, LADO_IA)
    n_total = max(1, int(dur * fps))
    dec = subprocess.Popen(["ffmpeg", "-v", "error", "-nostdin", "-i", str(fonte), "-an",
                            "-vf", f"fps={fps:.6f},scale={w}:{h}:flags=bilinear,format=rgb24",
                            "-f", "rawvideo", "-"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                           **({"creationflags": 0x08000000} if sys.platform == "win32" else {}))
    tmp = saida.with_name(saida.stem + ".parcial.mkv")
    enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "gray", "-s", f"{w}x{h}",
                            "-r", f"{fps:.6f}", "-i", "-", "-c:v", "libx264", "-preset", "veryfast", "-crf", "16",
                            "-pix_fmt", "gray", str(tmp)], stdin=subprocess.PIPE, stderr=subprocess.DEVNULL,
                           **({"creationflags": 0x08000000} if sys.platform == "win32" else {}))
    rec = [np.zeros((1, 1, 1, 1), dtype=np.float32)] * 4
    ds = np.array([min(1.0, 512 / max(w, h))], dtype=np.float32)
    n = 0
    tam = w * h * 3
    try:
        while True:
            b = dec.stdout.read(tam)
            if len(b) < tam:
                break
            src = np.frombuffer(b, np.uint8).reshape(h, w, 3).transpose(2, 0, 1)[None].astype(np.float32) / 255.0
            out = sess.run(None, {"src": src, "r1i": rec[0], "r2i": rec[1], "r3i": rec[2], "r4i": rec[3], "downsample_ratio": ds})
            pha, rec = out[1], out[2:6]
            enc.stdin.write((np.clip(pha[0, 0], 0, 1) * 255 + 0.5).astype(np.uint8).tobytes())
            n += 1
            if progresso and n % 10 == 0:
                progresso(min(0.99, n / n_total), f"Tirando o fundo com IA… {n} de ~{n_total} quadros")
    finally:
        enc.stdin.close()
        enc.wait()
        dec.stdout.close()
        dec.wait()
    if n == 0 or enc.returncode != 0:
        tmp.unlink(missing_ok=True)
        raise RuntimeError("a IA não conseguiu ler o vídeo")
    tmp.replace(saida)
    return "placa de vídeo" if prov != "CPUExecutionProvider" else "processador"


def _hex(c: str) -> str:
    c = str(c or "#00FF00").lstrip("#")
    return c if len(c) == 6 else "00FF00"


def mascara_chroma(fonte: Path, saida: Path, fps: float, ch: dict, progresso=None) -> None:
    W, H, _, dur = _medidas(fonte)
    w, h = _tam_trabalho(W, H, 1080)
    tol = max(0.01, min(0.9, float(ch.get("tol", 0.3))))
    suave = max(0.0, min(0.5, float(ch.get("suave", 0.08))))
    tmp = saida.with_name(saida.stem + ".parcial.mkv")
    rodar_ffmpeg(["-i", str(fonte), "-an", "-vf",
                  f"fps={fps:.6f},scale={w}:{h},format=yuva444p,chromakey=0x{_hex(ch.get('cor'))}:{tol:.3f}:{suave:.3f},"
                  f"alphaextract,format=gray", "-c:v", "libx264", "-preset", "veryfast", "-crf", "16", "-pix_fmt", "gray",
                  str(tmp)], duracao=dur, rotulo="tela verde")
    tmp.replace(saida)


# ------------------------------------------------------------------ cenário vazio (fantoches e objetos)
def _ler_quadros(fonte: Path, w: int, h: int, fps: float, ini: float | None = None, dur: float | None = None):
    """Quadros RGB (h, w, 3) em sequência, direto do FFmpeg."""
    import numpy as np
    cmd = ["ffmpeg", "-v", "error", "-nostdin"]
    if ini is not None:
        cmd += ["-ss", f"{ini:.3f}"]
    cmd += ["-i", str(fonte)]
    if dur is not None:
        cmd += ["-t", f"{dur:.3f}"]
    cmd += ["-an", "-vf", f"fps={fps:.6f},scale={w}:{h}:flags=area,format=rgb24", "-f", "rawvideo", "-"]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                         **({"creationflags": 0x08000000} if sys.platform == "win32" else {}))
    tam = w * h * 3
    try:
        while True:
            b = p.stdout.read(tam)
            if len(b) < tam:
                break
            yield np.frombuffer(b, np.uint8).reshape(h, w, 3)
    finally:
        p.stdout.close()
        p.wait()


class _Gravador:
    """Escreve a máscara (tons de cinza) quadro a quadro."""

    def __init__(self, saida: Path, w: int, h: int, fps: float):
        self.tmp = saida.with_name(saida.stem + ".parcial.mkv")
        self.saida = saida
        self.p = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "gray", "-s", f"{w}x{h}",
                                   "-r", f"{fps:.6f}", "-i", "-", "-c:v", "libx264", "-preset", "veryfast", "-crf", "16",
                                   "-pix_fmt", "gray", str(self.tmp)], stdin=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                  **({"creationflags": 0x08000000} if sys.platform == "win32" else {}))
        self.n = 0

    def escrever(self, m) -> None:
        self.p.stdin.write(m.tobytes())
        self.n += 1

    def fechar(self) -> None:
        self.p.stdin.close()
        self.p.wait()
        if self.n == 0 or self.p.returncode != 0:
            self.tmp.unlink(missing_ok=True)
            raise RuntimeError("não consegui gravar a máscara")
        self.tmp.replace(self.saida)


def _limpar(m, minimo: float):
    """Tira sujeirinhas, fecha buracos e suaviza a borda da máscara (0..1)."""
    import cv2
    import numpy as np
    b = (m > 0.5).astype(np.uint8)
    b = cv2.morphologyEx(b, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    b = cv2.morphologyEx(b, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9)))
    n, rot, st, _ = cv2.connectedComponentsWithStats(b, 8)
    area_min = minimo * b.size
    manter = np.zeros(n, np.uint8)
    manter[1:] = (st[1:, cv2.CC_STAT_AREA] >= area_min).astype(np.uint8)
    b = manter[rot]
    comp = b.copy()
    # buracos dentro do objeto (olhos do fantoche da mesma cor do fundo, por exemplo)
    inv = (1 - b).astype(np.uint8)
    n2, rot2, st2, _ = cv2.connectedComponentsWithStats(inv, 4)
    h, w = b.shape
    for k in range(1, n2):
        x, y, ww, hh, a = st2[k]
        if x > 0 and y > 0 and x + ww < w and y + hh < h and a < 0.02 * b.size:
            b[rot2 == k] = 1
    out = np.maximum(m * comp, (b - comp).astype(np.float32))   # borda macia + buracos preenchidos
    return cv2.GaussianBlur(np.clip(out, 0, 1).astype(np.float32), (5, 5), 0)


def mascara_vazio(fonte: Path, saida: Path, fps: float, vz: dict, progresso=None) -> None:
    """Compara cada quadro com o cenário vazio: o que é diferente (fantoche, pessoa, objetos) fica.
    Se a câmera se mexer um pouco, o cenário é alinhado a cada quadro (pontos em comum)."""
    import cv2
    import numpy as np
    W, H, _, dur = _medidas(fonte)
    w, h = _tam_trabalho(W, H, 540)
    ini = max(0.0, float(vz.get("ini", 0)))
    fim = max(ini + 0.5, float(vz.get("fim", ini + 3)))
    amostras = [q.astype(np.float32) for q in _ler_quadros(fonte, w, h, min(fps, 10), ini, fim - ini)]
    if not amostras:
        raise RuntimeError("não achei o trecho do cenário vazio no vídeo")
    placa = np.median(np.stack(amostras[:40]), axis=0).astype(np.uint8)
    placa_lab = cv2.cvtColor(placa, cv2.COLOR_RGB2LAB).astype(np.float32)
    alinhar = bool(vz.get("alinhar", True))
    orb = cv2.ORB_create(1500) if alinhar else None
    kp_p, des_p = (orb.detectAndCompute(cv2.cvtColor(placa, cv2.COLOR_RGB2GRAY), None) if orb else (None, None))
    bf = cv2.BFMatcher(cv2.NORM_HAMMING) if orb else None
    sens = max(0.0, min(1.0, float(vz.get("sens", 0.5))))
    lim = 30 - 22 * sens                 # diferença de cor (Lab) para contar como "não é o cenário"
    macio = lim * 0.35
    peso_luz = 0.35 if vz.get("sombras", True) else 1.0   # ignora sombras: luz pesa menos que a cor
    rec = _Gravador(saida, w, h, fps)
    total = max(1, int(dur * fps))
    anterior = None
    Hm = np.eye(3)
    try:
        for n, q in enumerate(_ler_quadros(fonte, w, h, fps)):
            ref, valido = placa_lab, None
            if orb is not None and des_p is not None and n % 2 == 0:
                kp, des = orb.detectAndCompute(cv2.cvtColor(q, cv2.COLOR_RGB2GRAY), None)
                if des is not None and len(kp) > 20:
                    pares = [m[0] for m in bf.knnMatch(des_p, des, k=2) if len(m) == 2 and m[0].distance < 0.75 * m[1].distance]
                    if len(pares) >= 15:
                        a = np.float32([kp_p[m.queryIdx].pt for m in pares])
                        b = np.float32([kp[m.trainIdx].pt for m in pares])
                        Hn, _ = cv2.findHomography(a, b, cv2.RANSAC, 3.0)
                        if Hn is not None:
                            Hm = Hn
            if orb is not None and np.abs(Hm - np.eye(3)).max() > 0.004:
                ref = cv2.warpPerspective(placa_lab, Hm, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
                valido = cv2.warpPerspective(np.ones((h, w), np.uint8), Hm, (w, h)) > 0
            lab = cv2.cvtColor(q, cv2.COLOR_RGB2LAB).astype(np.float32)
            d = lab - ref
            dist = np.sqrt(peso_luz * d[..., 0] ** 2 + d[..., 1] ** 2 + d[..., 2] ** 2)
            dist = cv2.GaussianBlur(dist, (5, 5), 0)
            m = np.clip((dist - (lim - macio)) / (2 * macio), 0, 1)
            if valido is not None:
                m[~valido] = 0
            m = _limpar(m, 0.002)
            if anterior is not None:
                m = 0.65 * m + 0.35 * anterior     # menos tremido entre um quadro e outro
            anterior = m
            rec.escrever((m * 255 + 0.5).astype(np.uint8))
            if progresso and n % 10 == 0:
                progresso(min(0.99, n / total), f"Comparando com o cenário vazio… {n} de ~{total} quadros")
    finally:
        rec.fechar()


# ------------------------------------------------------------------ marcar o que fica (rastreia e recorta)
def mascara_caixas(fonte: Path, saida: Path, fps: float, cxs: list[dict], progresso=None) -> None:
    """Segue cada retângulo marcado pelo vídeo inteiro (para frente e para trás) e recorta o objeto dentro dele."""
    import cv2
    import numpy as np
    W, H, _, dur = _medidas(fonte)
    wr, hr = _tam_trabalho(W, H, 360)           # rastrear em baixa resolução (rápido)
    total = max(1, int(dur * fps))
    guardados = []
    for n, q in enumerate(_ler_quadros(fonte, wr, hr, fps)):
        guardados.append(cv2.imencode(".jpg", cv2.cvtColor(q, cv2.COLOR_RGB2BGR), [cv2.IMWRITE_JPEG_QUALITY, 85])[1])
        if progresso and n % 30 == 0:
            progresso(0.25 * n / total, "Lendo o vídeo para seguir o que você marcou…")
    N = len(guardados)
    if N == 0:
        raise RuntimeError("não consegui ler o vídeo")
    quadro = lambda i: cv2.imdecode(guardados[i], cv2.IMREAD_COLOR)  # noqa: E731
    trilhas: list[list] = []
    for j, c in enumerate(cxs):
        k0 = min(N - 1, int(round(c["t"] * fps)))
        caixa0 = (int(c["x"] * wr), int(c["y"] * hr), max(4, int(c["w"] * wr)), max(4, int(c["h"] * hr)))
        trilha = [None] * N
        trilha[k0] = caixa0
        for passo in (1, -1):
            tr = cv2.TrackerMIL_create()
            tr.init(quadro(k0), caixa0)
            ultima = caixa0
            i = k0 + passo
            while 0 <= i < N:
                ok, bx = tr.update(quadro(i))
                if ok:
                    ultima = tuple(int(v) for v in bx)
                trilha[i] = ultima
                i += passo
        trilhas.append(trilha)
        if progresso:
            progresso(0.25 + 0.25 * (j + 1) / len(cxs), "Seguindo o que você marcou…")
    # recorte em resolução maior, só dentro da caixa (GrabCut)
    w, h = _tam_trabalho(W, H, 540)
    fx, fy = w / wr, h / hr
    rec = _Gravador(saida, w, h, fps)
    anterior = None
    try:
        for n, q in enumerate(_ler_quadros(fonte, w, h, fps)):
            m = np.zeros((h, w), np.float32)
            bgr = cv2.cvtColor(q, cv2.COLOR_RGB2BGR)
            for trilha in trilhas:
                bx = trilha[min(n, N - 1)]
                if not bx:
                    continue
                x, y, ww, hh = bx[0] * fx, bx[1] * fy, bx[2] * fx, bx[3] * fy
                mx, my = ww * 0.15, hh * 0.15
                x0, y0 = int(max(0, x - mx)), int(max(0, y - my))
                x1, y1 = int(min(w, x + ww + mx)), int(min(h, y + hh + my))
                if x1 - x0 < 8 or y1 - y0 < 8:
                    continue
                roi = bgr[y0:y1, x0:x1]
                k = min(1.0, 170 / max(roi.shape[:2]))     # GrabCut num tamanho pequeno (rápido) e amplia depois
                peq = cv2.resize(roi, (max(8, int(roi.shape[1] * k)), max(8, int(roi.shape[0] * k))), interpolation=cv2.INTER_AREA)
                gm = np.zeros(peq.shape[:2], np.uint8)
                ret = (max(1, int((x - x0) * k)), max(1, int((y - y0) * k)), max(2, int(ww * k)), max(2, int(hh * k)))
                ret = (ret[0], ret[1], min(ret[2], peq.shape[1] - ret[0] - 1), min(ret[3], peq.shape[0] - ret[1] - 1))
                try:
                    cv2.grabCut(peq, gm, ret, np.zeros((1, 65), np.float64), np.zeros((1, 65), np.float64), 3, cv2.GC_INIT_WITH_RECT)
                    fgp = ((gm == cv2.GC_FGD) | (gm == cv2.GC_PR_FGD)).astype(np.float32)
                except cv2.error:
                    fgp = np.zeros(peq.shape[:2], np.float32)
                    fgp[ret[1]:ret[1] + ret[3], ret[0]:ret[0] + ret[2]] = 1
                fg = cv2.resize(fgp, (roi.shape[1], roi.shape[0]), interpolation=cv2.INTER_LINEAR)
                m[y0:y1, x0:x1] = np.maximum(m[y0:y1, x0:x1], fg)
            m = _limpar(m, 0.001)
            if anterior is not None:
                m = 0.6 * m + 0.4 * anterior
            anterior = m
            rec.escrever((m * 255 + 0.5).astype(np.uint8))
            if progresso and n % 10 == 0:
                progresso(0.5 + 0.5 * min(0.99, n / total), f"Recortando o que você marcou… {n} de ~{total} quadros")
    finally:
        rec.fechar()


def juntar_mascaras(a: Path, b: Path, saida: Path) -> None:
    """O que estiver em qualquer uma das duas máscaras fica (pessoa + fantoche, por exemplo)."""
    tmp = saida.with_name(saida.stem + ".parcial.mkv")
    rodar_ffmpeg(["-i", str(a), "-i", str(b), "-filter_complex",
                  "[0:v]format=gray[a];[1:v]format=gray[b0];[b0][a]scale2ref=flags=bilinear[b][a2];"
                  "[a2][b]blend=all_mode=lighten,format=gray[m]", "-map", "[m]",
                  "-c:v", "libx264", "-preset", "veryfast", "-crf", "16", "-pix_fmt", "gray", str(tmp)], rotulo="juntando")
    tmp.replace(saida)


def previa_alpha(previa: Path, mascara: Path, saida: Path) -> None:
    """Prévia com transparência (VP9 + alfa): toca no Edge/Chrome/janela do Estúdio."""
    w, h, fps, dur = _medidas(previa)
    tmp = saida.with_name(saida.stem + ".parcial.webm")
    rodar_ffmpeg(["-i", str(previa), "-i", str(mascara), "-filter_complex",
                  f"[1:v]scale={w}:{h}:flags=bilinear,format=gray,setpts=PTS-STARTPTS[m];"
                  f"[0:v]setpts=PTS-STARTPTS,format=yuv420p[c];[c][m]alphamerge,format=yuva420p[v]",
                  "-map", "[v]", "-an", "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p", "-deadline", "realtime",
                  "-cpu-used", "8", "-row-mt", "1", "-crf", "36", "-b:v", "0", "-auto-alt-ref", "0", "-g", "30",
                  str(tmp)], duracao=dur, rotulo="prévia sem fundo")
    tmp.replace(saida)


def gerar(fonte: Path, previa: Path, pasta: Path, cfg_fundo: dict, fps: float, progresso=None) -> dict:
    """Faz a máscara e a prévia (se ainda não existem). Devolve {chave, mascara, previa, onde}."""
    ch = chave(cfg_fundo, fonte)
    mascara, alpha = arquivos(pasta, ch)
    onde = ""
    if not (mascara.exists() and mascara.stat().st_size > 0):
        for velho in pasta.glob("mascara_*.mkv"):
            velho.unlink(missing_ok=True)
        met = cfg_fundo.get("metodo")
        cx = caixas(cfg_fundo)
        if met == "chroma":
            if progresso:
                progresso(0.1, "Tirando a tela verde…")
            mascara_chroma(fonte, mascara, fps, cfg_fundo.get("chroma") or {}, progresso)
        elif met == "marcar":
            if not cx:
                raise RuntimeError("marque pelo menos um retângulo em volta do que deve ficar")
            mascara_caixas(fonte, mascara, fps, cx, progresso)
        else:
            base = mascara.with_name(mascara.stem + "_base.mkv") if cx else mascara
            if met == "vazio":
                mascara_vazio(fonte, base, fps, cfg_fundo.get("vazio") or {}, (lambda f, m: progresso(f * (0.6 if cx else 1), m)) if progresso else None)
            else:
                onde = mascara_ia(fonte, base, fps, (lambda f, m: progresso(f * (0.6 if cx else 1), m)) if progresso else None)
            if cx:   # soma o que foi marcado (fantoche/objetos) ao que a IA ou o cenário vazio acharam
                extra = mascara.with_name(mascara.stem + "_caixas.mkv")
                mascara_caixas(fonte, extra, fps, cx, (lambda f, m: progresso(0.6 + 0.38 * f, m)) if progresso else None)
                juntar_mascaras(base, extra, mascara)
                base.unlink(missing_ok=True)
                extra.unlink(missing_ok=True)
    if previa and Path(previa).exists() and not (alpha.exists() and alpha.stat().st_size > 0):
        for velho in pasta.glob("previa_alpha_*.webm"):
            velho.unlink(missing_ok=True)
        if progresso:
            progresso(0.99, "Preparando a prévia sem fundo…")
        previa_alpha(previa, mascara, alpha)
    return {"chave": ch, "mascara": mascara, "previa": alpha, "onde": onde}


def mascara_existente(pasta: Path, cfg_fundo: dict, fonte: Path) -> Path | None:
    m, _ = arquivos(pasta, chave(cfg_fundo, fonte))
    return m if m.exists() and m.stat().st_size > 0 else None


def avisar(msg: str) -> None:
    aviso(msg)
