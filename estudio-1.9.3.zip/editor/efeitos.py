"""Transições entre cortes e animações de entrada/saída por pedaço (como no CapCut).

Tudo vira expressões do FFmpeg no tempo do vídeo final (t): multiplicador de tamanho, deslocamento,
giro, brilho (flash/escurecer), desfoque e glitch em janelas de tempo. A prévia (estudio.html,
efeitosEm) usa exatamente as mesmas contas.

Transição de um corte: janela [a - d/2, a + d/2] em volta do corte (a = começo do pedaço).
Entrada: [a, a + d]. Saída: [b - d, b]."""
from __future__ import annotations

TRANSICOES = ("nenhuma", "zoom", "zoom_out", "desl_esq", "desl_dir", "desl_cima", "desl_baixo", "girar",
              "desfocar", "branco", "preto", "glitch", "tremor")
ANIM_ENTRADA = ("nenhuma", "zoom_in", "zoom_out", "desl_esq", "desl_dir", "desl_cima", "desl_baixo", "girar", "aparecer")
ANIM_SAIDA = ANIM_ENTRADA


def _pedaco(pedacos, s, e):
    m = (s + e) / 2
    for p in pedacos or []:
        try:
            if float(p.get("s", 0)) <= m <= float(p.get("e", 0)):
                return p
        except (TypeError, ValueError):
            continue
    return {}


def janelas(pedacos: list, mapa) -> list[dict]:
    """Lista de efeitos: {tipo, t0, t1, modo: trans|in|out}."""
    out = []
    n = len(mapa.trechos)
    for k, (s, e) in enumerate(mapa.trechos):
        p = _pedaco(pedacos, s, e)
        a = mapa.acum[k]
        b = a + (e - s)
        dur_seg = b - a
        tr = p.get("transicao") or "nenhuma"
        if k > 0 and tr in TRANSICOES and tr != "nenhuma":
            d = max(0.15, min(1.2, float(p.get("trans_dur") or 0.4)))
            ant = mapa.acum[k - 1]
            d = min(d, 2 * (a - ant), 2 * dur_seg)       # não passa do pedaço anterior nem deste
            out.append({"tipo": tr, "t0": a - d / 2, "t1": a + d / 2, "modo": "trans"})
        da = max(0.15, min(1.5, float(p.get("anim_dur") or 0.5)))
        if (p.get("anim_in") or "nenhuma") != "nenhuma":
            dd = min(da, dur_seg / 2)
            out.append({"tipo": p["anim_in"], "t0": a, "t1": a + dd, "modo": "in"})
        if (p.get("anim_out") or "nenhuma") != "nenhuma":
            dd = min(da, dur_seg / 2)
            out.append({"tipo": p["anim_out"], "t0": b - dd, "t1": b, "modo": "out"})
    del n
    return out


def _u(j):
    return f"((t-{j['t0']:.3f})/{max(1e-3, j['t1'] - j['t0']):.3f})"


def _termo(j, campo):
    """Contribuição de uma janela num campo: 's' (multiplica tamanho: devolve s-1), 'x', 'y' (fração da tela),
    'r' (graus), 'b' (brilho -1..1). '' se não mexe nesse campo."""
    u = _u(j)
    tri = f"(1-abs(2*{u}-1))"
    ease = f"(1-pow(1-{u},3))"          # entrada: rápido no começo, suave no fim
    ein = f"pow({u},3)"                 # saída: começa devagar
    t, modo = j["tipo"], j["modo"]
    if modo == "trans":
        antes = f"lt({u},0.5)"
        sobe = f"pow({u}/0.5,2)"
        desce = f"pow(1-({u}-0.5)/0.5,2)"
        tabela = {
            ("zoom", "s"): f"0.35*{tri}", ("zoom_out", "s"): f"-0.25*{tri}",
            ("desl_esq", "x"): f"if({antes},-0.6*{sobe},0.6*{desce})", ("desl_dir", "x"): f"if({antes},0.6*{sobe},-0.6*{desce})",
            ("desl_cima", "y"): f"if({antes},-0.6*{sobe},0.6*{desce})", ("desl_baixo", "y"): f"if({antes},0.6*{sobe},-0.6*{desce})",
            ("girar", "r"): f"if({antes},180*{sobe},-180*{desce})", ("girar", "s"): f"0.2*{tri}",
            ("branco", "b"): f"0.85*{tri}", ("preto", "b"): f"-0.85*{tri}",
            ("tremor", "x"): f"0.025*sin(t*71)*{tri}", ("tremor", "y"): f"0.02*sin(t*53+1)*{tri}",
            ("glitch", "x"): f"0.03*sin(t*97)*{tri}",
        }
        return tabela.get((t, campo), "")
    if modo == "in":
        f = f"(1-{ease})"
        tabela = {
            ("zoom_in", "s"): f"0.4*{f}", ("zoom_out", "s"): f"-0.4*{f}",
            ("desl_esq", "x"): f"1.0*{f}", ("desl_dir", "x"): f"-1.0*{f}",
            ("desl_cima", "y"): f"1.0*{f}", ("desl_baixo", "y"): f"-1.0*{f}",
            ("girar", "r"): f"-90*{f}", ("girar", "s"): f"-0.4*{f}",
            ("aparecer", "b"): f"-1*{f}",
        }
        return tabela.get((t, campo), "")
    f = ein
    tabela = {
        ("zoom_in", "s"): f"0.4*{f}", ("zoom_out", "s"): f"-0.4*{f}",
        ("desl_esq", "x"): f"-1.0*{f}", ("desl_dir", "x"): f"1.0*{f}",
        ("desl_cima", "y"): f"-1.0*{f}", ("desl_baixo", "y"): f"1.0*{f}",
        ("girar", "r"): f"90*{f}", ("girar", "s"): f"-0.4*{f}",
        ("aparecer", "b"): f"-1*{f}",
    }
    return tabela.get((t, campo), "")


def expr(js: list[dict], campo: str) -> str:
    """Soma das contribuições (0 fora das janelas). '' se nenhuma janela mexe no campo."""
    partes = []
    for j in js:
        termo = _termo(j, campo)
        if termo:
            partes.append(f"between(t,{j['t0']:.3f},{j['t1']:.3f})*({termo})")
    return "+".join(partes)


def girar_max(js: list[dict]) -> float:
    m = 0.0
    for j in js:
        if j["tipo"] == "girar":
            m = max(m, 180.0 if j["modo"] == "trans" else 90.0)
    return m


def filtros_extra(js: list[dict], Wt: int) -> str:
    """Desfoque e glitch nas janelas (vão depois da cena montada). Devolve ',filtro,...' ou ''."""
    out = ""
    des = [j for j in js if (j["tipo"] in ("desfocar", "desl_esq", "desl_dir", "desl_cima", "desl_baixo", "girar") and j["modo"] == "trans")]
    for nivel, frac in ((1, 0.5), (2, 0.25)):
        quando = "+".join(f"between(t,{(j['t0'] + j['t1']) / 2 - (j['t1'] - j['t0']) * frac / 2:.3f},"
                          f"{(j['t0'] + j['t1']) / 2 + (j['t1'] - j['t0']) * frac / 2:.3f})" for j in des)
        if quando:
            r = max(2, int(Wt / 160)) * nivel
            out += f",boxblur={r}:1:enable='{quando}'"
    gl = [j for j in js if j["tipo"] == "glitch"]
    if gl:
        quando = "+".join(f"between(t,{j['t0']:.3f},{j['t1']:.3f})" for j in gl)
        d = max(4, int(Wt / 90))
        out += f",rgbashift=rh=-{d}:bh={d}:enable='{quando}',noise=alls=35:allf=t:enable='{quando}'"
    return out


def ativo(pedacos: list) -> bool:
    for p in pedacos or []:
        if (p.get("transicao") or "nenhuma") != "nenhuma" or (p.get("anim_in") or "nenhuma") != "nenhuma" \
                or (p.get("anim_out") or "nenhuma") != "nenhuma":
            return True
    return False
