@echo off
chcp 65001 >nul
cd /d "%~dp0"
REM Arraste um ou mais videos para cima deste arquivo: eles entram na fila do Estudio.
if not exist ".venv\Scripts\pythonw.exe" (
  echo Rode primeiro o INSTALAR.bat
  pause & exit /b
)
if "%~1"=="" (
  start "" ".venv\Scripts\pythonw.exe" -m editor
  exit /b
)
start "" ".venv\Scripts\pythonw.exe" -m editor %*
