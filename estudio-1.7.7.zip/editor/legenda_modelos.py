"""Modelos de legenda: os que já vêm prontos, os que você salvou e qual é o padrão para vídeos novos.
Também escolhe palavras-chave e emojis (com a IA local, ou por regras simples sem ela)."""
from __future__ import annotations

import json
import re
import time
import unicodedata

from . import emojis, ia
from .subtitles import PADRAO
from .util import RAIZ, aviso

ARQUIVO = RAIZ / "modelos_legenda.json"

EMBUTIDOS: list[dict] = [
    {"id": "classico", "nome": "Clássico", "estilo": {
        "modo": "karaoke", "fonte": "Montserrat ExtraBold", "cor": "#FFFFFF", "destaque": "#FFD60A",
        "contorno": "#000000", "fundo": "sombra", "animacao": "saltar"}},
    {"id": "caixa_verde", "nome": "Caixa verde", "estilo": {
        "modo": "caixa", "fonte": "Montserrat ExtraBold", "cor": "#FFFFFF", "destaque": "#3CFF8F",
        "texto_caixa": "#000000", "contorno": "#000000", "cor_chave": "#FFD60A", "fundo": "sombra", "animacao": "saltar"}},
    {"id": "caixa_roxa", "nome": "Caixa roxa", "estilo": {
        "modo": "caixa", "fonte": "Poppins ExtraBold", "cor": "#FFFFFF", "destaque": "#7C3AED",
        "texto_caixa": "#FFFFFF", "contorno": "#000000", "espessura_contorno": 60, "fundo": "sombra", "cor_chave": "#FFD60A",
        "animacao": "saltar"}},
    {"id": "impacto", "nome": "Impacto", "estilo": {
        "modo": "karaoke", "fonte": "Anton", "cor": "#FFFFFF", "destaque": "#FFD60A", "contorno": "#000000",
        "tamanho": 112, "chave": True, "cor_chave": "#3CFF8F", "fundo": "sombra", "animacao": "saltar"}},
    {"id": "uma_palavra", "nome": "Uma palavra", "estilo": {
        "modo": "palavra", "fonte": "Bebas Neue", "cor": "#FFFFFF", "contorno": "#000000", "tamanho": 115,
        "chave": True, "cor_chave": "#FFD60A", "fundo": "sombra", "animacao": "surgir"}},
    {"id": "neon", "nome": "Neon", "estilo": {
        "modo": "karaoke", "fonte": "Poppins ExtraBold", "cor": "#FFFFFF", "destaque": "#7DF9FF",
        "contorno": "#00B3FF", "espessura_contorno": 70, "fundo": "neon", "animacao": "deslizar"}},
    {"id": "maquina", "nome": "Máquina", "estilo": {
        "modo": "karaoke", "fonte": "Archivo Black", "cor": "#FFFFFF", "destaque": "#FF4FA3",
        "contorno": "#000000", "fundo": "sombra", "animacao": "maquina"}},
    {"id": "classica", "nome": "Frase", "estilo": {
        "modo": "classica", "fonte": "Poppins ExtraBold", "cor": "#FFFFFF", "contorno": "#000000",
        "maiusculas": False, "max_palavras": 7, "max_caracteres": 40, "tamanho": 100,
        "espessura_contorno": 0, "fundo": "tarja", "cor_fundo": "#000000", "animacao": "deslizar"}},
    {"id": "quadrinhos", "nome": "Quadrinhos", "estilo": {
        "modo": "karaoke", "fonte": "Bangers", "cor": "#FFFFFF", "destaque": "#FFD60A", "contorno": "#000000",
        "tamanho": 120, "espessura_contorno": 160, "fundo": "sombra", "animacao": "saltar"}},
    {"id": "divertido", "nome": "Divertido", "estilo": {
        "modo": "palavra", "fonte": "Luckiest Guy", "cor": "#FFFFFF", "contorno": "#000000",
        "chave": True, "cor_chave": "#FF4FA3", "fundo": "sombra", "animacao": "saltar"}},
    {"id": "discreto", "nome": "Discreto", "estilo": {
        "modo": "karaoke", "fonte": "Roboto Black", "cor": "#FFFFFF", "destaque": "#FFFFFF",
        "contorno": "#000000", "maiusculas": False, "tamanho": 80, "espessura_contorno": 70,
        "fundo": "sombra", "animacao": "nenhuma"}},
    {"id": "claro", "nome": "Claro", "estilo": {
        "modo": "karaoke", "fonte": "Montserrat ExtraBold", "cor": "#111111", "destaque": "#E11D48",
        "contorno": "#FFFFFF", "fundo": "nenhum", "animacao": "saltar"}},
]
# o que um modelo NÃO muda (é do vídeo, não do visual)
PRESERVAR = ("ativar", "posicao_vertical", "posicao_horizontal", "pos_x", "emojis")
CAMPOS = tuple(PADRAO)


def _ler() -> dict:
    try:
        d = json.loads(ARQUIVO.read_text(encoding="utf-8"))
        if isinstance(d, dict):
            return {"meus": list(d.get("meus") or []), "padrao": d.get("padrao")}
    except FileNotFoundError:
        pass
    except Exception as e:  # noqa: BLE001
        aviso(f"modelos_legenda.json ilegível: {e}")
    return {"meus": [], "padrao": None}


def _gravar(d: dict) -> None:
    tmp = ARQUIVO.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(ARQUIVO)


def listar() -> dict:
    d = _ler()
    return {"embutidos": EMBUTIDOS, "meus": d["meus"], "padrao": d["padrao"], "base": PADRAO}


def _limpo(estilo: dict) -> dict:
    return {k: v for k, v in (estilo or {}).items() if k in CAMPOS and k not in PRESERVAR}


def salvar(nome: str, estilo: dict) -> dict:
    d = _ler()
    nome = (nome or "Meu modelo").strip()[:40]
    existente = next((m for m in d["meus"] if m["nome"].lower() == nome.lower()), None)
    if existente:
        existente["estilo"] = _limpo(estilo)
    else:
        d["meus"].append({"id": f"meu_{int(time.time() * 1000)}", "nome": nome, "estilo": _limpo(estilo)})
    _gravar(d)
    return listar()


def apagar(mid: str) -> dict:
    d = _ler()
    d["meus"] = [m for m in d["meus"] if m["id"] != mid]
    if d["padrao"] == mid:
        d["padrao"] = None
    _gravar(d)
    return listar()


def definir_padrao(mid: str | None) -> dict:
    d = _ler()
    d["padrao"] = mid or None
    _gravar(d)
    return listar()


def estilo_padrao() -> dict:
    """Visual do modelo marcado como padrão (vazio = usa o config.yaml)."""
    d = _ler()
    mid = d.get("padrao")
    if not mid:
        return {}
    m = next((x for x in EMBUTIDOS + d["meus"] if x["id"] == mid), None)
    return dict(m["estilo"]) if m else {}


# ============================================================ palavras-chave e emojis
_COMUNS = set("""a o as os um uma uns umas de da do das dos em na no nas nos por para pra pro com sem e ou mas que se
eu tu ele ela nos vos eles elas voce voces me te lhe meu minha seu sua isso isto aquilo esse essa este esta ai la
aqui entao ja nao sim mais menos muito muita bem tambem so ate como quando onde porque pois ser estar ter foi
era sao esta estou tem tinha vai vou fazer faz feito ao aos ne tipo assim coisa gente""".split())


def _sem_acento(t: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", t.lower()) if unicodedata.category(c) != "Mn")


def _chaves_regras(grupos: list[dict]) -> list[int]:
    """Sem IA: números e a palavra mais 'forte' de cada frase."""
    fortes = ("nunca", "sempre", "gratis", "segredo", "important", "erro", "dinheiro", "rapido", "facil",
              "melhor", "pior", "verdade", "cuidado", "atencao", "agora", "hoje", "todo", "nada", "unico")
    out = []
    for g in grupos:
        cand = []
        for i, w in zip(g["i"], g["t"].split()):
            n = re.sub(r"[^\w%]", "", _sem_acento(w))
            if not n or n in _COMUNS:
                continue
            nota = len(n) + (8 if any(n.startswith(f) for f in fortes) else 0) + (10 if re.search(r"\d", n) else 0)
            cand.append((nota, i))
        if cand:
            nota, i = max(cand)
            if nota >= 7:
                out.append(i)
    return out


def _emojis_regras(grupos: list[dict]) -> dict[str, str]:
    out: dict[str, str] = {}
    ultimo = -99
    for k, g in enumerate(grupos):
        if k - ultimo < 2:      # no máximo um emoji a cada 2 legendas, para não poluir
            continue
        e = emojis.sugerir_para(g["t"])
        if e and emojis.arquivo(e):
            out[str(g["i"][0])] = e
            ultimo = k
    return out


PROMPT = """Você edita legendas de vídeos curtos em português (Reels/TikTok).
Abaixo estão as legendas, uma por linha, no formato  N | i:palavra i:palavra ...
1) Escolha as PALAVRAS-CHAVE: as que mais importam para a mensagem (números, promessas, emoções,
   conceitos centrais). No máximo uma por legenda e só em cerca de metade delas. Nunca artigos, preposições ou vícios.
2) Escolha EMOJIS para algumas legendas (no máximo 1 a cada 3 legendas), só quando combinar muito bem.
   Use SOMENTE emojis desta lista: {lista}
Responda só com JSON: {{"chave": [i, i, ...], "emoji": {{"i": "emoji", ...}}}}
(i é o número que aparece antes da palavra; para emoji use o i da primeira palavra da legenda).

{texto}"""


def chaves_e_emojis(grupos: list[dict], cfg: dict) -> dict:
    """grupos: [{"i": [índices], "t": "texto"}]. Devolve {"chave": [...], "emoji": {i: e}, "fonte": "ia"|"regras"}."""
    lista = emojis.disponiveis()
    if ia.provedor(cfg) is not None and grupos:
        try:
            texto = "\n".join(f"{k + 1} | " + " ".join(f"{i}:{w}" for i, w in zip(g["i"], g["t"].split()))
                              for k, g in enumerate(grupos[:220]))
            d = ia.perguntar_json(cfg, PROMPT.format(lista=" ".join(lista), texto=texto), max_tokens=1500)
            validos = {i for g in grupos for i in g["i"]}
            primeiros = {g["i"][0] for g in grupos}
            chave = [int(i) for i in d.get("chave", []) if str(i).lstrip("-").isdigit() and int(i) in validos]
            emo = {}
            for i, e in (d.get("emoji") or {}).items():
                e = str(e).strip()
                if str(i).isdigit() and e in lista:
                    i = int(i)
                    alvo = next((g["i"][0] for g in grupos if i in g["i"]), None)
                    if alvo in primeiros:
                        emo[str(alvo)] = e
            if chave or emo:
                return {"chave": chave, "emoji": emo, "fonte": "ia"}
        except Exception as e:  # noqa: BLE001
            aviso(f"IA não escolheu palavras-chave/emojis ({str(e)[:120]}); usando regras simples.")
    return {"chave": _chaves_regras(grupos), "emoji": _emojis_regras(grupos), "fonte": "regras"}


# ============================================================ copiar o estilo de um vídeo de referência
PROMPT_COPIAR = """Estas imagens são quadros de UM vídeo curto com legendas queimadas na imagem.
Analise SÓ a legenda (o texto sobreposto que acompanha a fala) e descreva o estilo dela.
Responda só com JSON:
{{"tem_legenda": true/false,
 "modo": "karaoke" (frase com a palavra falada em outra cor) | "caixa" (palavra falada dentro de um retângulo colorido) | "palavra" (só uma palavra por vez, grande) | "classica" (frase inteira, sem destaque),
 "cor": "#RRGGBB cor principal das letras",
 "destaque": "#RRGGBB cor da palavra destacada ou da caixa",
 "texto_caixa": "#RRGGBB cor das letras dentro da caixa (se houver)",
 "contorno": "#RRGGBB cor do contorno das letras",
 "contorno_grosso": "nenhum" | "fino" | "medio" | "grosso",
 "fundo": "nenhum" | "sombra" | "neon" | "tarja",
 "cor_fundo": "#RRGGBB cor da tarja (se houver)",
 "maiusculas": true/false,
 "posicao_vertical": número de 0 (topo) a 1 (base) — onde fica o centro da legenda,
 "tamanho": "pequeno" | "medio" | "grande" | "enorme",
 "palavras_por_vez": número,
 "tipo_de_letra": "condensada alta" | "geometrica pesada" | "arredondada" | "quadrinhos" | "divertida" | "simples",
 "emojis": true/false}}
{extra}"""

FONTE_POR_TIPO = {"condensada alta": "Anton", "geometrica pesada": "Montserrat ExtraBold", "arredondada": "Poppins ExtraBold",
                  "quadrinhos": "Bangers", "divertida": "Luckiest Guy", "simples": "Roboto Black"}
TAMANHO = {"pequeno": 80, "medio": 100, "grande": 120, "enorme": 145}
CONTORNO = {"nenhum": 0, "fino": 60, "medio": 100, "grosso": 170}


def _cor(v, padrao):
    v = str(v or "").strip()
    return v.upper() if re.fullmatch(r"#[0-9a-fA-F]{6}", v) else padrao


def copiar_de_video(video, cfg: dict, nome: str = "") -> dict:
    """Extrai quadros do vídeo de exemplo, pede à IA (que enxerga imagens) o estilo da legenda e salva
    como um modelo seu. Só o visual é copiado (cores, caixa, posição, tamanho, tipo de letra)."""
    import base64
    import subprocess
    import tempfile
    from pathlib import Path
    from .util import sondar
    if ia.provedor(cfg) is None or not ia.enxerga_imagens(cfg):
        raise RuntimeError("para copiar um estilo é preciso a IA local que enxerga imagens (Gemma 3). "
                           "Abra o Ollama e confira o modelo em config.yaml.")
    dur = max(1.0, float(sondar(Path(video), exigir_audio=False)["duracao"]))
    imagens = []
    with tempfile.TemporaryDirectory() as tmp:
        for k, frac in enumerate((0.12, 0.27, 0.42, 0.57, 0.72, 0.87)):
            arq = Path(tmp) / f"q{k}.jpg"
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{dur * frac:.2f}", "-i", str(video), "-frames:v", "1",
                            "-vf", "scale='if(gt(iw,ih),768,-2)':'if(gt(iw,ih),-2,768)'", "-q:v", "4", str(arq)],
                           capture_output=True)
            if arq.exists():
                imagens.append(base64.b64encode(arq.read_bytes()).decode())
    if not imagens:
        raise RuntimeError("não consegui ler quadros desse vídeo")
    d = ia.perguntar_json(cfg, PROMPT_COPIAR.format(extra=""), imagens_b64=imagens, max_tokens=600)
    if d.get("tem_legenda") is False:
        raise RuntimeError("não encontrei legenda nesse vídeo — escolha um vídeo com legenda na imagem")
    modo = d.get("modo") if d.get("modo") in ("karaoke", "caixa", "palavra", "classica") else "karaoke"
    fundo = d.get("fundo") if d.get("fundo") in ("nenhum", "sombra", "neon", "tarja") else "sombra"
    estilo = {
        "modo": modo, "fonte": FONTE_POR_TIPO.get(str(d.get("tipo_de_letra", "")).lower(), "Montserrat ExtraBold"),
        "cor": _cor(d.get("cor"), "#FFFFFF"), "destaque": _cor(d.get("destaque"), "#FFD60A"),
        "texto_caixa": _cor(d.get("texto_caixa"), "#000000"), "contorno": _cor(d.get("contorno"), "#000000"),
        "espessura_contorno": CONTORNO.get(str(d.get("contorno_grosso", "")).lower(), 100),
        "fundo": fundo, "cor_fundo": _cor(d.get("cor_fundo"), "#000000"),
        "maiusculas": bool(d.get("maiusculas", True)),
        "tamanho": TAMANHO.get(str(d.get("tamanho", "")).lower(), 100),
        "animacao": "saltar" if modo in ("karaoke", "caixa") else "surgir" if modo == "palavra" else "deslizar",
    }
    try:
        pv = float(d.get("posicao_vertical"))
        if 0.1 <= pv <= 0.95:
            estilo["posicao_vertical"] = round(pv, 2)
    except (TypeError, ValueError):
        pass
    try:
        n = int(d.get("palavras_por_vez"))
        if modo != "palavra" and 1 <= n <= 8:
            estilo["max_palavras"] = n
            estilo["max_caracteres"] = 40 if n > 4 else 20
    except (TypeError, ValueError):
        pass
    nome = (nome or "Copiado de vídeo")[:40]
    salvo = salvar(nome, estilo)
    # salvar() ignora a posição (é do vídeo); devolvemos à parte para aplicar se você quiser
    return {**salvo, "estilo": estilo, "posicao_vertical": estilo.get("posicao_vertical")}
