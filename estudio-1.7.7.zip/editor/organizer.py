"""Biblioteca: título e tema pela IA, data de gravação, pastas Tema > Data, e o vigia da pasta de entrada."""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import time
import unicodedata
from datetime import datetime
from pathlib import Path

from .util import aviso, info

MESES = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto",
         "Setembro", "Outubro", "Novembro", "Dezembro"]
EXTENSOES = {".mp4", ".mov", ".mkv", ".avi", ".m4v", ".webm", ".mts", ".3gp"}
IGNORAR = {"_pausados", "_com_erro", "_trabalho"}


# ------------------------------------------------------------------ caminhos
def pastas(cfg: dict) -> tuple[Path, Path]:
    b = cfg.get("biblioteca", {})
    ent = Path(os.path.expandvars(os.path.expanduser(b.get("entrada", "~/Videos/ENTRADA"))))
    dst = Path(os.path.expandvars(os.path.expanduser(b.get("destino", "~/Videos/Biblioteca"))))
    return ent, dst


def ativa(cfg: dict) -> bool:
    return bool(cfg.get("biblioteca", {}).get("ativar", True))


def impressao_digital(video: Path) -> str:
    """Identifica o vídeo pelo conteúdo (tamanho + início + fim), não pelo nome:
    mesmo depois de renomeado/movido, o trabalho já feito é reaproveitado."""
    h = hashlib.sha1()
    tam = video.stat().st_size
    h.update(str(tam).encode())
    with open(video, "rb") as f:
        h.update(f.read(1 << 20))
        if tam > 2 << 20:
            f.seek(-(1 << 20), 2)
            h.update(f.read(1 << 20))
    return h.hexdigest()[:12]


def nome_seguro(txt: str, maximo: int = 80) -> str:
    txt = unicodedata.normalize("NFC", txt or "").strip()
    txt = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "", txt)
    txt = re.sub(r"\s+", " ", txt).strip(" .")
    if len(txt) > maximo:
        txt = txt[:maximo].rsplit(" ", 1)[0].strip(" .,;-")
    reservados = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(10)), *(f"LPT{i}" for i in range(10))}
    if not txt or txt.upper() in reservados:
        txt = "Vídeo"
    return txt


def data_gravacao(video: Path, iv: dict) -> datetime:
    bruto = iv.get("data_gravacao")
    if bruto:
        try:
            d = datetime.fromisoformat(bruto.replace("Z", "+00:00"))
            if d.year > 2000:
                return d.astimezone() if d.tzinfo else d
        except ValueError:
            pass
    st = video.stat()
    return datetime.fromtimestamp(min(st.st_mtime, getattr(st, "st_birthtime", st.st_mtime)))


def temas_existentes(cfg: dict) -> list[str]:
    _, dst = pastas(cfg)
    if not dst.is_dir():
        return []
    return sorted(p.name for p in dst.iterdir() if p.is_dir() and p.name not in IGNORAR
                  and not p.name.startswith((".", "_")))


def pasta_do_mes(d: datetime) -> str:
    return f"{d.year}-{d.month:02d} {MESES[d.month - 1]}"


def pasta_final(cfg: dict, tema: str, titulo: str, data: datetime, video: Path) -> Path:
    _, dst = pastas(cfg)
    try:  # vídeo que já está na biblioteca (reedição): fica na mesma pasta
        video.resolve().relative_to(dst.resolve())
        if video.parent.name not in IGNORAR:
            return video.parent
    except ValueError:
        pass
    base = dst / nome_seguro(tema, 40) / pasta_do_mes(data)
    alvo = base / nome_seguro(titulo)
    k = 2
    while alvo.exists() and any(alvo.iterdir()):
        alvo = base / f"{nome_seguro(titulo)} ({k})"
        k += 1
    return alvo


# ------------------------------------------------------------------ título e tema (IA)
PROMPT = """Você organiza uma biblioteca de vídeos. Abaixo está a transcrição de um vídeo em português.

Crie:
- "titulo": um título curto e natural para o arquivo (máx. 60 caracteres), que diga do que o vídeo trata. Sem aspas, sem emojis, sem ponto final.
- "tema": o assunto geral, em 1 a 3 palavras, com inicial maiúscula (ex.: "Finanças", "Saúde", "Vida Espiritual"). Se algum destes temas JÁ EXISTENTES servir, use exatamente o mesmo nome: {temas}

Responda SOMENTE com JSON: {{"titulo": "...", "tema": "..."}}

TRANSCRIÇÃO:
{texto}"""


def sugerir_titulo_tema(palavras: list[dict], cfg: dict, cortes: list[dict] | None = None) -> dict:
    removidas = {i for c in (cortes or []) if c.get("ativo") for i in c.get("palavras", [])}
    limpas = [w["w"] for w in palavras if w["i"] not in removidas]
    texto = " ".join(limpas[:1800])
    temas = temas_existentes(cfg)
    inicio = re.sub(r"[.!?…].*$", "", " ".join(limpas[:12])).strip(" ,.;")
    reserva = {"titulo": nome_seguro(inicio[:1].upper() + inicio[1:] if inicio else "Vídeo", 60),
               "tema": cfg.get("biblioteca", {}).get("tema_padrao", "Geral")}
    from . import ia
    if ia.provedor(cfg) is None or not texto:
        ia.avisar_sem_ia(cfg)
        return reserva
    try:
        d = ia.perguntar_json(cfg, PROMPT.format(temas=", ".join(temas) if temas else "(nenhum ainda)",
                                                 texto=" ".join(limpas[:1200])), max_tokens=300)
        titulo = nome_seguro(str(d.get("titulo", "")), 60)
        tema = nome_seguro(str(d.get("tema", "")), 40)
        for t in temas:  # mesmo tema com grafia diferente -> usa a pasta existente
            if t.lower() == tema.lower():
                tema = t
        return {"titulo": titulo or reserva["titulo"], "tema": tema or reserva["tema"]}
    except Exception as e:  # noqa: BLE001
        aviso(f"Não consegui sugerir título/tema com a IA ({str(e)[:100]}).")
        return reserva


# ------------------------------------------------------------------ arquivar
def mover(origem: Path, destino: Path) -> Path:
    destino.parent.mkdir(parents=True, exist_ok=True)
    if origem.resolve() == destino.resolve():
        return destino
    if destino.exists():
        destino.unlink()
    shutil.move(str(origem), str(destino))
    return destino


# ------------------------------------------------------------------ vigia
def _estavel(p: Path, vistos: dict) -> bool:
    """Arquivo terminou de ser copiado? (mesmo tamanho em duas checagens e não está travado)"""
    try:
        st = p.stat()
    except FileNotFoundError:
        return False
    assin = (st.st_size, st.st_mtime)
    anterior = vistos.get(p)
    vistos[p] = assin
    if anterior != assin or st.st_size == 0 or time.time() - st.st_mtime < 5:
        return False
    try:
        with open(p, "ab"):
            pass
    except OSError:
        return False
    return True


def vigiar(cfg: dict, processar) -> None:
    ent, dst = pastas(cfg)
    for p in (ent, dst, ent / "_pausados", ent / "_com_erro"):
        p.mkdir(parents=True, exist_ok=True)
    intervalo = int(cfg.get("biblioteca", {}).get("verificar_a_cada", 10))
    print("\n" + "=" * 64)
    print("  VIGIA DE VÍDEOS LIGADO")
    print(f"  Solte os vídeos crus em:  {ent}")
    print(f"  Eles vão organizados para: {dst}")
    print("  (deixe esta janela aberta; Ctrl+C para desligar)")
    print("=" * 64, flush=True)
    vistos: dict = {}
    while True:
        candidatos = sorted(
            (f for f in ent.rglob("*") if f.is_file() and f.suffix.lower() in EXTENSOES
             and not any(parte in IGNORAR for parte in f.relative_to(ent).parts)),
            key=lambda f: f.stat().st_mtime)
        prontos = [f for f in candidatos if _estavel(f, vistos)]
        for f in prontos:
            if not f.exists():
                continue
            try:
                resultado = processar(f)
                if resultado == "pausado" and f.exists():
                    mover(f, ent / "_pausados" / f.name)
                    info(f"Deixado para depois: {ent / '_pausados' / f.name}")
            except KeyboardInterrupt:
                raise
            except Exception as e:  # noqa: BLE001
                aviso(f"Erro com {f.name}: {e}")
                if f.exists():
                    alvo = mover(f, ent / "_com_erro" / f.name)
                    alvo.with_suffix(alvo.suffix + ".erro.txt").write_text(str(e), encoding="utf-8")
            vistos.pop(f, None)
            print(f"\n  Aguardando novos vídeos em {ent} ...", flush=True)
        time.sleep(intervalo)
