"""Localiza o rosto ao longo do vídeo para reenquadrar (9:16, 1:1) e centralizar o zoom."""
from __future__ import annotations

import subprocess
from pathlib import Path

import numpy as np

from .util import barra

AMOSTRAS_POR_SEG = 3
LARG = 320


def rastrear_rosto(video: Path, info_v: dict) -> list[list[float]]:
    """Retorna [[t, cx, cy, tamanho], ...] normalizados (0–1). Sem rosto: centro."""
    import cv2

    w = LARG
    h = int(round(LARG / info_v["proporcao"] / 2) * 2)
    proc = subprocess.Popen(
        ["ffmpeg", "-v", "error", "-i", str(video), "-an",
         "-vf", f"fps={AMOSTRAS_POR_SEG},scale={w}:{h}", "-f", "rawvideo", "-pix_fmt", "gray", "-"],
        stdout=subprocess.PIPE,
    )
    frontal = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    perfil = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_profileface.xml")
    tam = w * h
    brutos: list[list[float] | None] = []
    k = 0
    total = max(1, int(info_v["duracao"] * AMOSTRAS_POR_SEG))
    while True:
        buf = proc.stdout.read(tam)
        if len(buf) < tam:
            break
        img = np.frombuffer(buf, np.uint8).reshape(h, w)
        min_lado = max(20, int(min(w, h) * 0.08))
        rostos = frontal.detectMultiScale(img, 1.15, 5, minSize=(min_lado, min_lado))
        if len(rostos) == 0:
            rostos = perfil.detectMultiScale(img, 1.15, 5, minSize=(min_lado, min_lado))
        if len(rostos):
            x, y, rw, rh = max(rostos, key=lambda r: r[2] * r[3])
            brutos.append([(x + rw / 2) / w, (y + rh / 2) / h, rh / h])
        else:
            brutos.append(None)
        k += 1
        if k % 30 == 0:
            barra(k / total, sufixo="rosto")
    proc.wait()
    barra(1.0, sufixo="rosto")
    return _suavizar(brutos)


def _suavizar(brutos: list) -> list[list[float]]:
    n = len(brutos)
    if n == 0:
        return []
    validos = [i for i, b in enumerate(brutos) if b]
    if not validos:
        return [[i / AMOSTRAS_POR_SEG, 0.5, 0.42, 0.3] for i in range(n)]
    arr = np.zeros((n, 3))
    for i in range(n):  # preenche buracos com a detecção mais próxima
        j = min(validos, key=lambda v: abs(v - i))
        arr[i] = brutos[j]
    rad = 3  # mediana móvel (~2 s) tira tremidas e falsos positivos
    suave = np.array([np.median(arr[max(0, i - rad): i + rad + 1], axis=0) for i in range(n)])
    return [[round(i / AMOSTRAS_POR_SEG, 3), *map(lambda v: round(float(v), 4), suave[i])]
            for i in range(n)]


def posicao_media(rastro: list[list[float]], t0: float, t1: float) -> tuple[float, float]:
    sel = [r for r in rastro if t0 <= r[0] <= t1]
    if not sel:
        if not rastro:
            return 0.5, 0.42
        r = min(rastro, key=lambda r: abs(r[0] - (t0 + t1) / 2))
        return r[1], r[2]
    return float(np.median([r[1] for r in sel])), float(np.median([r[2] for r in sel]))
