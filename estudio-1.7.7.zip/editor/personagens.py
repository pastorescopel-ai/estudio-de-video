"""Quem fala o quê: separa as vozes do vídeo (sem internet e sem modelos pesados).

Cada trecho de fala vira uma "impressão da voz": timbre (MFCC, como no reconhecimento de voz
clássico) + altura (tom médio). Depois os trechos são agrupados em N vozes (k-médias).
Funciona bem para vozes bem diferentes (adulto x criança, homem x mulher, voz de boneco);
o editor deixa corrigir clicando nas legendas."""
from __future__ import annotations

import subprocess
from pathlib import Path

import numpy as np

SR = 16000


def _audio(arq: Path) -> np.ndarray:
    r = subprocess.run(["ffmpeg", "-v", "error", "-nostdin", "-i", str(arq), "-vn", "-map", "0:a:0?",
                        "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return np.frombuffer(r.stdout, dtype=np.float32)


def _mel(n_fft: int = 512, n_mels: int = 26) -> np.ndarray:
    hz2mel = lambda f: 2595 * np.log10(1 + f / 700)  # noqa: E731
    mel2hz = lambda m: 700 * (10 ** (m / 2595) - 1)  # noqa: E731
    pts = mel2hz(np.linspace(hz2mel(80), hz2mel(7600), n_mels + 2))
    bins = np.floor((n_fft + 1) * pts / SR).astype(int)
    fb = np.zeros((n_mels, n_fft // 2 + 1))
    for m in range(1, n_mels + 1):
        a, b, c = bins[m - 1], bins[m], bins[m + 1]
        for k in range(a, b):
            fb[m - 1, k] = (k - a) / max(1, b - a)
        for k in range(b, c):
            fb[m - 1, k] = (c - k) / max(1, c - b)
    return fb


_FB = None


def _mfcc(sinal: np.ndarray) -> np.ndarray:
    global _FB
    if _FB is None:
        _FB = _mel()
    n, passo = 512, 160
    if len(sinal) < n:
        sinal = np.pad(sinal, (0, n - len(sinal)))
    quadros = np.lib.stride_tricks.sliding_window_view(sinal, n)[::passo] * np.hamming(n)
    esp = np.abs(np.fft.rfft(quadros, n)) ** 2
    energia = esp.sum(axis=1)
    voz = energia > np.percentile(energia, 40)          # só os quadros com som
    if voz.sum() < 3:
        voz[:] = True
    logmel = np.log(esp[voz] @ _FB.T + 1e-10)
    k = np.arange(13)[:, None]
    dct = np.cos(np.pi / logmel.shape[1] * (np.arange(logmel.shape[1]) + 0.5) * k)
    c = logmel @ dct.T
    return np.concatenate([c.mean(axis=0)[1:], c.std(axis=0)[1:]])


def _tom(sinal: np.ndarray) -> float:
    """Tom médio (Hz) por autocorrelação nos quadros mais fortes."""
    n, passo = 1024, 320
    if len(sinal) < n:
        return 0.0
    quadros = np.lib.stride_tricks.sliding_window_view(sinal, n)[::passo]
    energia = (quadros ** 2).sum(axis=1)
    fortes = quadros[energia >= np.percentile(energia, 60)]
    tons = []
    lo, hi = SR // 600, SR // 70
    for q in fortes[:60]:
        q = q - q.mean()
        ac = np.fft.irfft(np.abs(np.fft.rfft(q, 2 * n)) ** 2)[:n]
        if ac[0] <= 0:
            continue
        lag = lo + int(np.argmax(ac[lo:hi]))
        if ac[lag] / ac[0] > 0.35:
            tons.append(SR / lag)
    return float(np.median(tons)) if tons else 0.0


def _kmeans(X: np.ndarray, k: int, rodadas: int = 8) -> np.ndarray:
    rng = np.random.default_rng(7)
    melhor, melhor_custo = None, np.inf
    for _ in range(rodadas):
        centros = X[rng.choice(len(X), k, replace=False)]
        for _ in range(60):
            d = ((X[:, None, :] - centros[None]) ** 2).sum(-1)
            rot = d.argmin(1)
            novos = np.array([X[rot == j].mean(0) if (rot == j).any() else centros[j] for j in range(k)])
            if np.allclose(novos, centros):
                break
            centros = novos
        custo = d.min(1).sum()
        if custo < melhor_custo:
            melhor, melhor_custo = rot, custo
    return melhor


def separar(arq: Path, palavras: list[dict], n: int) -> dict:
    """Devolve {"falas": [personagem por palavra], "tons": [Hz médio de cada personagem]}."""
    N = len(palavras)
    if N == 0 or n <= 1:
        return {"falas": [0] * N, "tons": []}
    sinal = _audio(arq)
    # trechos curtos (até ~1.2 s): troca de quem fala costuma vir com pausa, mas nem sempre
    trechos: list[list[int]] = [[]]
    for i, w in enumerate(palavras):
        t = trechos[-1]
        if t and (w["s"] - palavras[t[-1]]["e"] > 0.25 or w["e"] - palavras[t[0]]["s"] > 1.2):
            trechos.append([])
        trechos[-1].append(i)
    feats, tons, validos = [], [], []
    for k, t in enumerate(trechos):
        a, b = int(palavras[t[0]]["s"] * SR), int(palavras[t[-1]]["e"] * SR)
        pedaco = sinal[a:b]
        if len(pedaco) < SR * 0.15:
            continue
        tom = _tom(pedaco)
        f = _mfcc(pedaco)
        feats.append(np.concatenate([f, [np.log(tom + 50) * 6]]))
        tons.append(tom)
        validos.append(k)
    if len(feats) < n:
        return {"falas": [0] * N, "tons": []}
    X = np.array(feats)
    X = (X - X.mean(0)) / (X.std(0) + 1e-6)
    X[:, -1] *= 2.5                                  # o tom pesa mais (separa bem boneco/criança/adulto)
    rot = _kmeans(X, n)
    # renumera por ordem de aparição
    ordem = list(dict.fromkeys(rot.tolist()))
    mapa = {r: j for j, r in enumerate(ordem)}
    falas = [None] * N
    tons_p: dict[int, list[float]] = {}
    for k, r in zip(validos, rot):
        for i in trechos[k]:
            falas[i] = mapa[int(r)]
        tons_p.setdefault(mapa[int(r)], []).append(tons[validos.index(k)])
    # suaviza: um trecho isolado no meio de outra voz, curto, provavelmente é erro
    for _ in range(2):
        for k in range(1, len(validos) - 1):
            ka, kb, kc = validos[k - 1], validos[k], validos[k + 1]
            pa, pb, pc = falas[trechos[ka][0]], falas[trechos[kb][0]], falas[trechos[kc][0]]
            curto = palavras[trechos[kb][-1]]["e"] - palavras[trechos[kb][0]]["s"] < 0.5
            if pa == pc and pb != pa and curto:
                for i in trechos[kb]:
                    falas[i] = pa
    # trechos curtos demais: herdam o vizinho
    ult = 0
    for i in range(N):
        if falas[i] is None:
            falas[i] = ult
        ult = falas[i]
    return {"falas": falas, "tons": [round(float(np.median(tons_p.get(j, [0]))), 0) for j in range(n)]}
