"""Uma porta só para a inteligência artificial.

Padrão: IA LOCAL e gratuita (Ollama rodando um modelo Gemma no próprio computador).
Opcional: Claude API, se houver chave em .env e o config pedir (ia: provedor: api | auto).
Sem nenhuma das duas, o editor continua funcionando com regras simples."""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request

from .util import aviso

_CACHE: dict = {}


def _cfg_ia(cfg: dict) -> dict:
    return cfg.get("ia", {}) or {}


def _url(cfg: dict) -> str:
    return str(_cfg_ia(cfg).get("url_local", "http://127.0.0.1:11434")).rstrip("/")


def _modelos_locais(cfg: dict) -> list[str]:
    try:
        with urllib.request.urlopen(_url(cfg) + "/api/tags", timeout=3) as r:
            return [m["name"] for m in json.load(r).get("models", [])]
    except Exception:  # noqa: BLE001
        return []


def ligar_local(cfg: dict) -> bool:
    """Se o Ollama estiver instalado mas desligado, liga o servidor dele escondido (sem a janela
    do aplicativo, que pede conta — a conta não é necessária para a IA local)."""
    import shutil
    import subprocess
    import time
    if str(_cfg_ia(cfg).get("provedor", "local")).lower() == "nenhum":
        return False
    try:
        with urllib.request.urlopen(_url(cfg) + "/api/tags", timeout=2):
            return True
    except Exception:  # noqa: BLE001
        pass
    exe = None
    for c in (os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Ollama", "ollama.exe"), shutil.which("ollama")):
        if c and os.path.isfile(c):
            exe = c
            break
    if not exe:
        return False
    try:
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        subprocess.Popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         stdin=subprocess.DEVNULL, creationflags=flags)
    except Exception:  # noqa: BLE001
        return False
    for _ in range(20):
        time.sleep(0.5)
        try:
            with urllib.request.urlopen(_url(cfg) + "/api/tags", timeout=2):
                _CACHE.pop("local", None)
                return True
        except Exception:  # noqa: BLE001
            continue
    return False


def modelo_local(cfg: dict) -> str | None:
    """Modelo configurado, se o Ollama estiver ligado e o modelo baixado."""
    import time
    if "local" in _CACHE and time.time() - _CACHE.get("local_t", 0) < 60:
        return _CACHE["local"]
    _CACHE["local_t"] = time.time()
    disponiveis = _modelos_locais(cfg)
    pedido = str(_cfg_ia(cfg).get("modelo_local", "") or "")
    escolhido = None
    if disponiveis:
        if pedido and any(m == pedido or m.split(":")[0] == pedido or m == pedido + ":latest" for m in disponiveis):
            escolhido = next(m for m in disponiveis if m == pedido or m.split(":")[0] == pedido or m == pedido + ":latest")
        else:  # qualquer Gemma/Qwen-VL instalado serve
            escolhido = next((m for m in disponiveis if m.startswith(("gemma", "qwen"))), None)
    _CACHE["local"] = escolhido
    return escolhido


def provedor(cfg: dict) -> str | None:
    """'local', 'api' ou None (sem IA)."""
    pref = str(_cfg_ia(cfg).get("provedor", "local")).lower()
    tem_api = bool(os.environ.get("ANTHROPIC_API_KEY", "").startswith("sk-"))
    if pref == "api":
        return "api" if tem_api else ("local" if modelo_local(cfg) else None)
    if pref == "nenhum":
        return None
    if modelo_local(cfg):
        return "local"
    return "api" if (pref == "auto" and tem_api) else None


def enxerga_imagens(cfg: dict) -> bool:
    p = provedor(cfg)
    if p == "api":
        return True
    m = (modelo_local(cfg) or "").lower()
    return any(x in m for x in ("gemma3", "gemma4", "vl", "llava", "vision")) and "gemma3:1b" not in m


def descricao(cfg: dict) -> str:
    p = provedor(cfg)
    if p == "local":
        return f"IA local ({modelo_local(cfg)})"
    if p == "api":
        return "Claude API"
    return "sem IA (regras simples)"


def perguntar_json(cfg: dict, texto: str, imagens_b64: list[str] | None = None,
                   max_tokens: int = 2000) -> dict:
    """Faz a pergunta e devolve o JSON da resposta. Levanta erro se não houver IA ou a resposta vier quebrada."""
    p = provedor(cfg)
    if p is None:
        raise RuntimeError("nenhuma IA disponível")
    if p == "local":
        corpo = {
            "model": modelo_local(cfg),
            "messages": [{"role": "user", "content": texto,
                          **({"images": imagens_b64} if imagens_b64 and enxerga_imagens(cfg) else {})}],
            "stream": False,
            "format": "json",
            "keep_alive": "30s",   # libera a placa de vídeo logo depois (ela é usada na transcrição e exportação)
            "options": {"temperature": 0.2, "num_ctx": int(_cfg_ia(cfg).get("contexto", 16384)),
                        "num_predict": max_tokens},
        }
        req = urllib.request.Request(_url(cfg) + "/api/chat", data=json.dumps(corpo).encode("utf-8"),
                                     headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=int(_cfg_ia(cfg).get("tempo_limite", 600))) as r:
                bruto = json.load(r)["message"]["content"]
        except urllib.error.URLError as e:
            raise RuntimeError(f"IA local não respondeu ({e})") from e
    else:
        import anthropic
        conteudo: list[dict] = [{"type": "text", "text": texto}]
        for b in imagens_b64 or []:
            conteudo.append({"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": b}})
        resp = anthropic.Anthropic().messages.create(
            model=_cfg_ia(cfg).get("modelo", "claude-sonnet-5-5"), max_tokens=max_tokens,
            messages=[{"role": "user", "content": conteudo}])
        bruto = "".join(getattr(x, "text", "") for x in resp.content)
    try:
        return json.loads(bruto[bruto.index("{"): bruto.rindex("}") + 1])
    except (ValueError, json.JSONDecodeError) as e:
        raise RuntimeError(f"resposta da IA sem JSON válido: {bruto[:200]}") from e


def tamanho_bloco(cfg: dict) -> int:
    """Quantas palavras mandar por vez (modelos locais têm memória de contexto menor)."""
    return 2500 if provedor(cfg) == "api" else int(_cfg_ia(cfg).get("palavras_por_bloco", 900))


def avisar_sem_ia(cfg: dict) -> None:
    if provedor(cfg) is None and not _CACHE.get("avisado"):
        _CACHE["avisado"] = True
        aviso("IA local não encontrada (o Ollama está aberto?). Usando regras simples para repetições, título e tema.")
