"""Duração alvo: quando o vídeo editado passa do máximo, escolhe as frases menos importantes para
cortar (IA local; sem IA, regras simples). Nunca corta a primeira frase (o gancho) nem a última."""
from __future__ import annotations

import re
import unicodedata

from . import ia
from .util import aviso

PROMPT = """Você edita vídeos curtos (Reels/TikTok/Shorts) em português. O vídeo tem {total:.0f} s e precisa
ficar com no máximo {alvo:.0f} s: é preciso tirar pelo menos {excesso:.0f} s de frases.
Escolha as frases MENOS importantes para a mensagem (repetitivas, rodeios, explicações secundárias,
exemplos a mais). NÃO escolha a primeira frase (é o gancho) nem a última (é a conclusão/chamada).
Frases, no formato  N | duração | texto:
{texto}

Responda só com JSON: {{"ordem": [N, N, ...]}} — os números das frases da MENOS para a MAIS importante
entre as que poderiam sair (inclua frases suficientes para somar bem mais que {excesso:.0f} s)."""

FORTES = ("segredo", "importante", "dica", "nunca", "sempre", "erro", "dinheiro", "resultado", "porque",
          "primeiro", "segundo", "terceiro", "passo", "conclus", "entao", "por isso", "siga", "comente")


def _sem_acento(t: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", t.lower()) if unicodedata.category(c) != "Mn")


def _nota(texto: str) -> float:
    t = _sem_acento(texto)
    return sum(2 for f in FORTES if f in t) + (3 if re.search(r"\d", t) else 0) + (2 if "?" in t else 0)


def escolher(frases: list[dict], total: float, alvo: float, cfg: dict) -> dict:
    """frases: [{"n": k, "ids": [...], "texto": "...", "dur": s}] na ordem do vídeo.
    Devolve {"remover": [n, ...], "fonte": "ia"|"regras", "tirado": s}."""
    excesso = total - alvo
    if excesso <= 0.2 or len(frases) < 3:
        return {"remover": [], "fonte": "nada", "tirado": 0.0}
    meio = frases[1:-1]                        # protege gancho e conclusão
    ordem: list[int] = []
    fonte = "regras"
    if ia.provedor(cfg) is not None:
        try:
            texto = "\n".join(f"{f['n']} | {f['dur']:.1f}s | {f['texto'][:200]}" for f in frases)
            d = ia.perguntar_json(cfg, PROMPT.format(total=total, alvo=alvo, excesso=excesso, texto=texto), max_tokens=800)
            validos = {f["n"] for f in meio}
            ordem = [int(x) for x in d.get("ordem", []) if str(x).lstrip("-").isdigit() and int(x) in validos]
            ordem = list(dict.fromkeys(ordem))
            if ordem:
                fonte = "ia"
        except Exception as e:  # noqa: BLE001
            aviso(f"IA não escolheu as frases para caber no tempo ({str(e)[:100]}); usando regras simples.")
    if not ordem:
        # sem IA: frases com menos "peso" primeiro; entre iguais, as mais longas (rendem mais tempo)
        ordem = [f["n"] for f in sorted(meio, key=lambda f: (_nota(f["texto"]), -f["dur"]))]
    # completa com as que a IA não citou, para garantir que dá para caber
    resto = [f["n"] for f in sorted(meio, key=lambda f: (_nota(f["texto"]), -f["dur"])) if f["n"] not in ordem]
    ordem += resto
    por_n = {f["n"]: f for f in frases}
    remover, tirado = [], 0.0
    for n in ordem:
        if tirado >= excesso:
            break
        remover.append(n)
        tirado += por_n[n]["dur"]
    return {"remover": sorted(remover), "fonte": fonte, "tirado": round(tirado, 2)}
