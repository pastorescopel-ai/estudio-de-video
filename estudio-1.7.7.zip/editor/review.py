"""Editor no navegador: servidor local que acompanha o vídeo do começo ao fim
(ajustar -> gerar -> assistir -> ajustar de novo -> concluir)."""
from __future__ import annotations

import json
import mimetypes
import os
import queue
import re
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote

from . import util
from .util import args_video, escolher_encoder, info, rodar_ffmpeg

MODELO = Path(__file__).with_name("editor.html")


def gerar_previa(video: Path, destino: Path, cfg: dict, iv: dict | None = None, forcar_cpu: bool = False) -> None:
    """Cópia leve (720p) só para assistir no editor — abre rápido em qualquer navegador.

    Formato escolhido para tocar em qualquer Edge/Chrome: H.264 perfil Main, 8 bits (yuv420p),
    quadros por segundo constantes, áudio AAC estéreo 48 kHz e índice no começo do arquivo."""
    if destino.exists() and destino.stat().st_size > 0:
        return
    tmp = destino.with_name("previa_tmp.mp4")
    enc = "cpu" if forcar_cpu else escolher_encoder(cfg)
    vf = "scale=-2:720" if not (iv and iv["vertical"]) else "scale=720:-2"
    if iv and iv.get("hdr"):
        from .render import TONEMAP
        vf = TONEMAP + "," + vf
    vf += ",format=yuv420p"
    if enc == "nvenc":
        cv = ["-c:v", "h264_nvenc", "-preset", "p4", "-rc", "vbr", "-cq", "25", "-b:v", "3M", "-maxrate", "5M",
              "-bufsize", "5M", "-profile:v", "main"]
    else:
        cv = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "24", "-profile:v", "main"]
    base = ["-i", str(video), "-map", "0:v:0", "-map", "0:a:0?", "-vf", vf, "-fps_mode", "cfr",
            "-g", "15", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k", "-ac", "2", "-ar", "48000",
            "-movflags", "+faststart", str(tmp)]
    try:
        rodar_ffmpeg(base[:6] + cv + base[6:])
    except Exception:  # noqa: BLE001
        if enc == "cpu":
            raise
        rodar_ffmpeg(base[:6] + ["-c:v", "libx264", "-preset", "veryfast", "-crf", "24", "-profile:v", "main"] + base[6:])
    tmp.replace(destino)


class Editor:
    def __init__(self, dados: dict, previa: Path, pasta_saida: Path, rastro: dict, cfg: dict,
                 arquivos_extras: dict[str, Path], pasta_midia: Path, ao_enviar=None, sugerir=None):
        self.dados = dados
        self.previa = previa
        self.pasta_saida = pasta_saida
        self.pasta_midia = pasta_midia
        self.rastro = rastro            # dict preenchido em segundo plano: {"r": [...]}
        self.extras = arquivos_extras   # /fontes/x.ttf, /logo, /musica/x.mp3 ...
        self.cfg = cfg
        self.ao_enviar = ao_enviar      # (tipo, arquivo) -> dict  (prepara a mídia recebida)
        self.sugerir = sugerir          # (corpo) -> list          (IA posiciona imagens de apoio)
        self.acoes: queue.Queue = queue.Queue()
        self.status = {"fase": "editando", "etapa": "", "rotulo": "", "frac": 0.0,
                       "arquivos": [], "erro": "", "pasta": "", "versao": 0}
        self.trava = threading.Lock()
        self.servidor = None
        self.url = ""

    def trocar_dados(self, dados: dict, previa: Path) -> None:
        """Depois de juntar partes da fala, o vídeo e a transcrição mudam: a página recarrega."""
        with self.trava:
            self.dados, self.previa = dados, previa
            self.status["versao"] += 1
            self.status.update(fase="editando", etapa="", rotulo="", frac=0.0)

    # --------------------------------------------------------- progresso
    def _ouvir(self, tipo, msg, frac):
        with self.trava:
            if tipo == "etapa":
                self.status.update(etapa=msg, frac=0.0, rotulo="")
            else:
                self.status.update(rotulo=msg, frac=frac)

    def fase(self, fase: str, **extra):
        with self.trava:
            self.status["fase"] = fase
            self.status.update(extra)

    # --------------------------------------------------------- ciclo
    def iniciar(self) -> str:
        ed = self

        def pagina() -> bytes:
            with ed.trava:
                d = dict(ed.dados, versao=ed.status["versao"])
            return MODELO.read_text(encoding="utf-8").replace(
                "/*__DADOS__*/null", json.dumps(d, ensure_ascii=False).replace("</", "<\\/")).encode("utf-8")

        class H(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *a):
                pass

            def do_PUT(self):
                """Recebe um arquivo enviado pelo editor (vídeo/foto extra, parte da fala, vinheta)."""
                from urllib.parse import parse_qs, urlparse
                q = parse_qs(urlparse(self.path).query)
                tipo = (q.get("tipo") or ["broll"])[0]
                from .media import nome_seguro_arquivo
                nome = nome_seguro_arquivo((q.get("nome") or ["arquivo"])[0])
                n = int(self.headers.get("Content-Length", 0))
                ed.pasta_midia.mkdir(parents=True, exist_ok=True)
                destino = ed.pasta_midia / nome
                with open(destino, "wb") as f:
                    resto = n
                    while resto > 0:
                        bloco = self.rfile.read(min(1 << 20, resto))
                        if not bloco:
                            break
                        f.write(bloco)
                        resto -= len(bloco)
                try:
                    res = ed.ao_enviar(tipo, destino) if ed.ao_enviar else {}
                    return self._json({"ok": True, **(res or {})})
                except BaseException as e:  # noqa: BLE001
                    return self._json({"ok": False, "erro": str(e)[:500]})

            def do_GET(self):
                caminho = unquote(self.path.split("?")[0])
                if caminho in ("/", "/index.html"):
                    return self._enviar(200, pagina(), "text/html; charset=utf-8")
                if caminho.startswith("/midia/"):
                    return self._arquivo(ed.pasta_midia / Path(caminho[7:]).name)
                if caminho == "/status":
                    with ed.trava:
                        return self._json(ed.status)
                if caminho == "/rosto":
                    return self._json(ed.rastro.get("r", []))
                if caminho == "/video":
                    return self._arquivo(ed.previa)
                if caminho.startswith("/saida/"):
                    return self._arquivo(ed.pasta_saida / Path(caminho[7:]).name)
                if caminho in ed.extras:
                    return self._arquivo(ed.extras[caminho])
                self._enviar(404, b"", "text/plain")

            def do_POST(self):
                n = int(self.headers.get("Content-Length", 0))
                corpo = json.loads((self.rfile.read(n) if n else b"{}").decode("utf-8") or "{}")
                rota = self.path.strip("/")
                if rota in ("gerar", "concluir", "cancelar", "partes"):
                    if rota == "gerar":
                        ed.fase("gerando", etapa="Começando…", frac=0.0, erro="")
                    if rota == "partes":
                        ed.fase("processando", etapa="Juntando as partes da fala…", frac=0.0, erro="")
                    ed.acoes.put((rota, corpo))
                    return self._json({"ok": True})
                if rota == "sugerir_broll" and ed.sugerir:
                    try:
                        return self._json({"ok": True, "itens": ed.sugerir(corpo)})
                    except Exception as e:  # noqa: BLE001
                        return self._json({"ok": False, "erro": str(e)[:300]})
                self._enviar(404, b"", "text/plain")

            def _json(self, obj):
                self._enviar(200, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                             "application/json; charset=utf-8")

            def _enviar(self, cod, corpo, tipo):
                self.send_response(cod)
                self.send_header("Content-Type", tipo)
                self.send_header("Content-Length", str(len(corpo)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(corpo)

            def _arquivo(self, p: Path):
                """Com suporte a Range: o navegador precisa disso para avançar/voltar no vídeo."""
                if not p or not p.is_file():
                    return self._enviar(404, b"", "text/plain")
                tam = p.stat().st_size
                ini, fim = 0, tam - 1
                m = re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range", ""))
                if m:
                    if m.group(1):
                        ini = int(m.group(1))
                        if m.group(2):
                            fim = min(int(m.group(2)), tam - 1)
                    elif m.group(2):
                        ini = max(0, tam - int(m.group(2)))
                    self.send_response(206)
                    self.send_header("Content-Range", f"bytes {ini}-{fim}/{tam}")
                else:
                    self.send_response(200)
                tipo = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
                self.send_header("Content-Type", tipo)
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Length", str(fim - ini + 1))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                try:
                    with open(p, "rb") as f:
                        f.seek(ini)
                        resto = fim - ini + 1
                        while resto > 0:
                            bloco = f.read(min(1 << 20, resto))
                            if not bloco:
                                break
                            self.wfile.write(bloco)
                            resto -= len(bloco)
                except (ConnectionResetError, BrokenPipeError, ConnectionAbortedError):
                    pass

        porta = int(self.cfg.get("revisao", {}).get("porta", 8765))
        for p in range(porta, porta + 30):
            try:
                self.servidor = ThreadingHTTPServer(("127.0.0.1", p), H)
                porta = p
                break
            except OSError:
                continue
        if self.servidor is None:
            raise SystemExit("Não consegui abrir o editor (portas ocupadas).")
        self.servidor.daemon_threads = True
        threading.Thread(target=self.servidor.serve_forever, daemon=True).start()
        util.OUVINTES.append(self._ouvir)
        self.url = f"http://127.0.0.1:{porta}/"
        info(f"Editor aberto no navegador: {self.url}")
        info("Ajuste o que quiser e clique em “Gerar vídeos”. (Se a aba fechar, abra o endereço acima.)")
        if not os.environ.get("EDITOR_SEM_NAVEGADOR"):
            webbrowser.open(self.url)
        return self.url

    def aguardar(self) -> tuple[str, dict]:
        while True:  # loop curto: deixa o Ctrl+C funcionar no Windows
            try:
                return self.acoes.get(timeout=0.5)
            except queue.Empty:
                continue

    def encerrar(self) -> None:
        if self._ouvir in util.OUVINTES:
            util.OUVINTES.remove(self._ouvir)
        if self.servidor:
            srv = self.servidor

            def fechar():  # espera a página ler o status final, depois libera a porta
                srv.shutdown()
                srv.server_close()
            threading.Timer(1.5, fechar).start()
