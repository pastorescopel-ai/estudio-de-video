"""Decide o que cortar: pausas, vícios de linguagem, gaguejos e tomadas repetidas."""
from __future__ import annotations

import difflib
import json
import os
import re
import subprocess
import unicodedata
from pathlib import Path

import numpy as np

from .util import aviso, info

SR = 16000
JANELA = 0.01  # 10 ms


# ======================================================== energia do áudio
def envelope_db(video: Path) -> np.ndarray:
    """Energia (dB) do áudio a cada 10 ms."""
    proc = subprocess.run(
        ["ffmpeg", "-v", "error", "-i", str(video), "-vn", "-ac", "1", "-ar", str(SR),
         "-f", "s16le", "-"], capture_output=True,
    )
    x = np.frombuffer(proc.stdout, dtype=np.int16).astype(np.float32) / 32768.0
    n = int(SR * JANELA)
    q = len(x) // n
    if q == 0:
        return np.full(1, -90.0)
    rms = np.sqrt(np.mean(x[: q * n].reshape(q, n) ** 2, axis=1) + 1e-12)
    return 20 * np.log10(rms + 1e-9)


def limiar_fala(env: np.ndarray) -> float:
    piso = float(np.percentile(env, 10))
    pico = float(np.percentile(env, 95))
    return max(piso + 0.35 * (pico - piso), piso + 8)


def refinar_palavras(palavras: list[dict], env: np.ndarray) -> None:
    """O Whisper costuma 'esticar' palavras por cima das pausas. Aqui encolhemos cada
    palavra até onde realmente há som, para os cortes de silêncio ficarem precisos."""
    lim = limiar_fala(env)
    for w in palavras:
        a, b = int(w["s"] / JANELA), int(w["e"] / JANELA)
        trecho = env[a: max(a + 1, b)]
        acima = np.nonzero(trecho > lim)[0]
        if len(acima) == 0:
            continue
        ns = (a + acima[0]) * JANELA - 0.03
        ne = (a + acima[-1] + 1) * JANELA + 0.03
        if ne - ns >= 0.06:
            w["s"], w["e"] = round(max(w["s"], ns), 3), round(min(w["e"], ne), 3)


# ======================================================== texto
def norm(t: str) -> str:
    t = t.lower().strip()
    t = re.sub(r"[^\wà-ú-]", "", t)
    return t


def sem_acento(t: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", t) if unicodedata.category(c) != "Mn")


# ======================================================== cortes
class Cortes:
    def __init__(self):
        self.itens: list[dict] = []
        self.ocupadas: set[int] = set()

    def palavras(self, idx: list[int], tipo: str, motivo: str, ativo: bool = True) -> None:
        idx = sorted(set(idx))
        if not idx:
            return
        novos = [i for i in idx if i not in self.ocupadas]
        if not novos:
            return
        self.ocupadas.update(novos if ativo else [])
        self.itens.append({"tipo": tipo, "palavras": novos, "ativo": ativo, "motivo": motivo})

    def pausa(self, depois_de: int, dur: float, tipo: str = "silencio") -> None:
        self.itens.append({"tipo": tipo, "pausa": depois_de, "ativo": True,
                           "motivo": f"pausa de {dur:.1f}s"})

    def finalizar(self) -> list[dict]:
        for k, c in enumerate(self.itens):
            c["id"] = k
        return self.itens


def analisar(palavras: list[dict], duracao: float, env: np.ndarray, cfg: dict) -> list[dict]:
    ccfg = cfg.get("cortes", {})
    cortes = Cortes()
    n = len(palavras)
    if n == 0:
        return []

    # ---------- 1) tomadas repetidas / falsos inícios / hesitações (IA)
    if ccfg.get("tomadas_repetidas", True):
        for c in cortes_ia(palavras, cfg):
            cortes.palavras(c["palavras"], c["tipo"], c["motivo"], c["ativo"])
    else:
        for c in repeticoes_offline(palavras):
            cortes.palavras(c["palavras"], "repeticao", c["motivo"])

    # ---------- 2) vícios de linguagem
    sempre = {norm(x) for x in ccfg.get("vicios_sempre", [])}
    ambiguos = {norm(x) for x in ccfg.get("vicios_ambiguos", [])}
    sugerir = {norm(x) for x in ccfg.get("vicios_sugerir", [])}
    for k, w in enumerate(palavras):
        t = norm(w["w"])
        if t in sempre or re.fullmatch(r"(é|e|h|ã|a|u|m)\1{2,}h?", t or "x"):
            cortes.palavras([k], "vicio", f"hesitação “{w['w']}”")
        elif t in ambiguos:
            gap_antes = w["s"] - (palavras[k - 1]["e"] if k else 0)
            gap_depois = (palavras[k + 1]["s"] if k + 1 < n else duracao) - w["e"]
            longo = (w["e"] - w["s"]) > 0.42
            reticencia = w["w"].endswith(("...", "…", ","))
            if longo or (gap_antes > 0.25 and gap_depois > 0.25) or (reticencia and gap_depois > 0.2):
                cortes.palavras([k], "vicio", f"hesitação “{w['w']}”")
        elif t in sugerir:
            cortes.palavras([k], "vicio", f"vício “{w['w']}” (sugestão)", ativo=False)

    # ---------- 3) gaguejos: "eu eu eu vou", "pro- professor"
    if ccfg.get("remover_gaguejos", True):
        for k in range(n - 1):
            a, b = norm(palavras[k]["w"]), norm(palavras[k + 1]["w"])
            if not a:
                continue
            if a == b and (palavras[k + 1]["s"] - palavras[k]["e"]) < 0.8:
                cortes.palavras([k], "gaguejo", f"repetiu “{palavras[k]['w']}”")
            elif a.endswith("-") and len(a) > 1 and b.startswith(a.rstrip("-")):
                cortes.palavras([k], "gaguejo", f"começo cortado “{palavras[k]['w']}”")

    # ---------- 4) pausas (inclusive início e fim do vídeo)
    minimo = float(ccfg.get("silencio_minimo", 0.55))
    if palavras[0]["s"] > 0.25:
        cortes.pausa(-1, palavras[0]["s"], "silencio")
    for k in range(n - 1):
        gap = palavras[k + 1]["s"] - palavras[k]["e"]
        if gap >= minimo:
            cortes.pausa(k, gap)
    if duracao - palavras[-1]["e"] > 0.3:
        cortes.pausa(n - 1, duracao - palavras[-1]["e"], "silencio")

    return cortes.finalizar()


# ======================================================== IA (Claude)
PROMPT_IA = """Você é um editor de vídeo profissional. Abaixo está a transcrição palavra a palavra de um vídeo CRU em português, gravado por uma pessoa falando para a câmera. Cada palavra tem um índice entre colchetes. Marcadores ⏸ indicam pausas (em segundos).

Sua tarefa: identificar trechos que um editor CORTARIA porque são erros de gravação:
1. "repeticao": a pessoa errou e REFEZ a frase/trecho. Corte a(s) tentativa(s) anteriores e mantenha só a ÚLTIMA versão completa e boa. Inclua no corte as palavras da tentativa ruim inteira (do início da tentativa até antes do recomeço).
2. "falso_inicio": começou uma frase, parou no meio e mudou de assunto/recomeçou.
3. "vicio": hesitações faladas (é..., hã, hum, ahn) QUANDO forem hesitação e não parte da frase. Atenção: "é" como verbo (ex.: "isso é importante") NÃO é vício.
4. "erro": frases dirigidas a quem grava ou fora do conteúdo ("espera, vou de novo", "corta", "deixa eu começar de novo", "errei").

Regras:
- Na dúvida, NÃO corte. Nunca corte conteúdo que não foi repetido nem é erro.
- Não marque pausas, elas já são tratadas.
- Responda SOMENTE com JSON válido, sem texto antes ou depois, neste formato:
{"cortes":[{"de":12,"ate":25,"tipo":"repeticao","motivo":"refez a frase sobre X"}]}
"de" e "ate" são índices de palavras, inclusive.

TRANSCRIÇÃO:
"""


def _texto_indexado(palavras: list[dict], a: int, b: int) -> str:
    partes = []
    for k in range(a, b):
        if k > a:
            gap = palavras[k]["s"] - palavras[k - 1]["e"]
            if gap >= 0.5:
                partes.append(f"⏸{gap:.1f}")
        partes.append(f"[{k}]{palavras[k]['w']}")
    return " ".join(partes)


def _repete_depois(palavras: list[dict], de: int, ate: int) -> bool:
    """Confere se o trecho marcado como 'refeito' realmente se repete logo depois
    (protege contra a IA local cortar conteúdo que não foi repetido)."""
    trecho = {sem_acento(norm(palavras[k]["w"])) for k in range(de, ate + 1)} - {""}
    depois = {sem_acento(norm(w["w"])) for w in palavras[ate + 1: ate + 1 + max(12, 2 * (ate - de + 1))]}
    return bool(trecho) and len(trecho & depois) / len(trecho) >= 0.4


def cortes_ia(palavras: list[dict], cfg: dict) -> list[dict]:
    from . import ia
    offline = [dict(c, tipo="repeticao", ativo=True) for c in repeticoes_offline(palavras)]
    if ia.provedor(cfg) is None:
        ia.avisar_sem_ia(cfg)
        return offline

    local = ia.provedor(cfg) == "local"
    n = len(palavras)
    BLOCO = ia.tamanho_bloco(cfg)
    SOBRA = min(150, BLOCO // 6)
    resultado: list[dict] = []
    vistos: set[tuple] = set()
    a = 0
    while a < n:
        b = min(n, a + BLOCO)
        info(f"Analisando erros e repetições com {ia.descricao(cfg)} (palavras {a}–{b - 1})...")
        try:
            dados = ia.perguntar_json(cfg, PROMPT_IA + _texto_indexado(palavras, a, b), max_tokens=4000)
        except Exception as e:  # noqa: BLE001
            aviso(f"Falha na IA ({str(e)[:120]}). Usando detecção offline neste trecho.")
            dados = {"cortes": [{"de": c["palavras"][0], "ate": c["palavras"][-1],
                                 "tipo": "repeticao", "motivo": c["motivo"]}
                                for c in repeticoes_offline(palavras[a:b], base=a)]}
        for c in dados.get("cortes", []):
            try:
                de, ate = int(c["de"]), int(c["ate"])
            except (KeyError, TypeError, ValueError):
                continue
            de, ate = max(a, de), min(b - 1, ate)
            if ate < de or (de, ate) in vistos:
                continue
            vistos.add((de, ate))
            tipo = c.get("tipo", "repeticao")
            if tipo not in ("repeticao", "falso_inicio", "vicio", "erro"):
                tipo = "repeticao"
            grande = (ate - de + 1) > (30 if local else 60)  # trecho muito grande: só sugere
            duvidoso = tipo != "vicio" and not _repete_depois(palavras, de, ate)
            nota = " (trecho grande — confira)" if grande else (" (confira)" if duvidoso else "")
            resultado.append({
                "palavras": list(range(de, ate + 1)), "tipo": tipo,
                "motivo": str(c.get("motivo") or tipo)[:140] + nota,
                "ativo": not grande and not duvidoso,
            })
        if b >= n:
            break
        a = b - SOBRA
    # o que a regra simples achou e a IA não marcou também entra
    marcadas = {i for c in resultado for i in c["palavras"]}
    resultado += [c for c in offline if not set(c["palavras"]) & marcadas]
    return limitar_cortes(resultado, n)


TIPOS_REPETICAO = ("repeticao", "falso_inicio", "erro", "gaguejo")


def manter_uma_ocorrencia(palavras: list[dict], cortes: list[dict]) -> list[dict]:
    """Numa repetição ("meninas esperta, meninas esperta") sai só a tomada extra: se todas as
    vezes que a frase foi dita estão marcadas para corte, a última volta para o vídeo."""
    n = len(palavras)
    if not n:
        return cortes
    tok = [sem_acento(norm(w["w"])) for w in palavras]
    removida = [False] * n
    for c in cortes:
        if c.get("ativo") and "palavras" in c:
            for i in c["palavras"]:
                if 0 <= i < n:
                    removida[i] = True

    def parecido(a: list[int], b: list[int]) -> bool:
        ta, tb = " ".join(tok[i] for i in a), " ".join(tok[i] for i in b)
        return bool(ta.strip()) and difflib.SequenceMatcher(None, ta, tb).ratio() >= 0.7

    restaurar: set[int] = set()
    for c in cortes:
        if not c.get("ativo") or c.get("tipo") not in TIPOS_REPETICAO or not c.get("palavras"):
            continue
        frase = [i for i in sorted(c["palavras"]) if 0 <= i < n and tok[i]]
        if not frase or len(frase) > 25:
            continue
        ultima = frase
        fim = frase[-1]
        for _ in range(6):   # segue a corrente de repetições: dita 2, 3, 4 vezes...
            achou = None
            for ini in range(fim + 1, min(n, fim + 4)):
                cand = list(range(ini, min(n, ini + len(frase))))
                if parecido(frase, cand):
                    achou = cand
                    break
            if not achou:
                break
            ultima, fim = achou, achou[-1]
        if ultima is not frase and all(removida[i] for i in ultima):
            restaurar.update(ultima)      # todas as vezes iam sair: a última fica
        elif ultima is frase and len(frase) >= 2:
            # a IA marcou a frase mas não há repetição logo depois: confira se não é a última de uma série
            ini_ant = max(0, frase[0] - len(frase) - 3)
            antes = [i for i in range(ini_ant, frase[0])]
            if antes and all(removida[i] for i in antes) and parecido(frase, antes[-len(frase):]):
                restaurar.update(frase)
    if not restaurar:
        return cortes
    out = []
    for c in cortes:
        if c.get("ativo") and "palavras" in c and c.get("tipo") in TIPOS_REPETICAO:
            resto = [i for i in c["palavras"] if i not in restaurar]
            if len(resto) != len(c["palavras"]):
                c = dict(c, palavras=resto, ativo=bool(resto),
                         motivo=str(c.get("motivo", "")) + " (uma das vezes foi mantida)")
        out.append(c)
    return [c for c in out if c.get("palavras") or "pausa" in c or not c.get("ativo")]


def limitar_cortes(cortes: list[dict], n: int, limite: float = 0.30) -> list[dict]:
    """Trava de segurança: se os cortes de repetição/erro tirariam mais de 30% da fala,
    algo deu errado (a IA local às vezes marca o vídeo quase inteiro). Nesse caso eles
    ficam só como sugestão, desligados, e você decide no editor."""
    if not n:
        return cortes
    ativos = {i for c in cortes if c.get("ativo") and c.get("tipo") != "vicio" and "palavras" in c for i in c["palavras"]}
    if len(ativos) / n <= limite:
        return cortes
    aviso(f"A IA marcou {len(ativos) * 100 // n}% da fala como repetição/erro — deixei esses cortes desligados para você conferir.")
    out = []
    for c in cortes:
        if c.get("ativo") and c.get("tipo") != "vicio" and len(c.get("palavras", [])) > 3:
            c = dict(c, ativo=False, motivo=str(c.get("motivo", "")) + " (desligado: cortaria demais — confira)")
        out.append(c)
    return out


def repeticoes_offline(palavras: list[dict], base: int = 0) -> list[dict]:
    """Sem IA: frases separadas por pausa; se uma frase é muito parecida com o
    começo da seguinte, a anterior foi uma tomada descartada."""
    frases: list[list[int]] = [[]]
    for k, w in enumerate(palavras):
        if frases[-1] and w["s"] - palavras[k - 1]["e"] > 0.7:
            frases.append([])
        frases[-1].append(k)
    saida = []
    for f1, f2 in zip(frases, frases[1:]):
        t1 = " ".join(sem_acento(norm(palavras[k]["w"])) for k in f1)
        t2 = " ".join(sem_acento(norm(palavras[k]["w"])) for k in f2[: len(f1) + 2])
        if len(f1) >= 2 and difflib.SequenceMatcher(None, t1, t2).ratio() > 0.62:
            saida.append({"palavras": [base + k for k in f1], "motivo": "frase refeita em seguida"})
    return saida
