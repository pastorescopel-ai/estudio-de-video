"""Editor automático de vídeos falados."""

VERSAO = "1.7.7"   # muda a cada atualização: o Estúdio antigo que estiver aberto é substituído sozinho
