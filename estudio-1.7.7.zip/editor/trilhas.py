"""Trilhas extras da linha do tempo (como no CapCut): vídeo, imagem/sticker, áudio e texto.

Cada item fica preso a uma palavra da fala (+ um deslocamento em segundos), então acompanha os
cortes. Na exportação vira: sobreposições do FFmpeg (vídeo/imagem/sticker), mistura de áudio
(sons) e eventos do .ass (textos)."""
from __future__ import annotations

from pathlib import Path

from .util import RAIZ

EXT_IMAGEM = (".png", ".jpg", ".jpeg", ".webp", ".bmp")
EXT_GIF = (".gif",)
PASTAS_LIVRES = ("stickers", "sons", "emojis")


def caminho(ref: str, pasta_midia: Path) -> Path | None:
    """Resolve o arquivo de um item. Aceita só arquivos do projeto ou das bibliotecas do Estúdio."""
    if not ref:
        return None
    ref = ref.replace("\\", "/").lstrip("/")
    partes = ref.split("/")
    if partes[0] in PASTAS_LIVRES and ".." not in partes:
        p = (RAIZ / ref).resolve()
        if str(p).startswith(str(RAIZ.resolve())) and p.is_file():
            return p
        return None
    p = pasta_midia / Path(ref).name
    return p if p.is_file() else None


def inicio_saida(item: dict, palavras: list[dict], mapa) -> float | None:
    """Momento (no vídeo final) em que o item começa."""
    if item.get("palavra") is None:
        return max(0.0, float(item.get("t", 0)))
    i = int(item["palavra"])
    for w in palavras[i:]:
        if not w.get("removida"):
            r = mapa.palavra(w)
            if r:
                return max(0.0, r[0] + float(item.get("desloc", 0)))
    return None


def resolver(aj: dict, palavras: list[dict], mapa, pasta_midia: Path) -> list[dict]:
    """Itens prontos para exportar, na ordem das camadas (primeira trilha = mais embaixo)."""
    out = []
    total = mapa.total
    for k, tr in enumerate(aj.get("trilhas") or []):
        if tr.get("oculta"):
            continue
        for it in tr.get("itens") or []:
            ini = inicio_saida(it, palavras, mapa)
            if ini is None or ini >= total - 0.05:
                continue
            dur = min(float(it.get("dur", 3)), total - ini)
            if dur < 0.1:
                continue
            r = {**it, "tipo": tr.get("tipo"), "camada": k, "ini": ini, "dur": dur, "mudo": bool(tr.get("muda"))}
            if tr.get("tipo") != "texto":
                r["arquivo"] = caminho(it.get("arquivo") or it.get("midia") or "", pasta_midia)
                if not r["arquivo"]:
                    continue
            out.append(r)
    return out


def _par(x: float) -> int:
    return max(2, int(round(x / 2)) * 2)


def filtros_visuais(itens: list[dict], Wt: int, Ht: int, fps: float, n_ent: int, rotulo: str):
    """Sobreposições de vídeo, imagem e sticker. Devolve (entradas, grafo, novo_rotulo, n_ent)."""
    entradas: list[str] = []
    grafo = ""
    for j, it in enumerate([x for x in itens if x["tipo"] in ("video", "imagem")]):
        arq: Path = it["arquivo"]
        dur, ini = it["dur"], it["ini"]
        ext = arq.suffix.lower()
        if ext in EXT_IMAGEM:
            entradas += ["-loop", "1", "-framerate", f"{fps:.6f}", "-t", f"{dur:.3f}", "-i", str(arq)]
        elif ext in EXT_GIF:
            entradas += ["-ignore_loop", "0", "-t", f"{dur:.3f}", "-i", str(arq)]
        else:
            entradas += ["-ss", f"{float(it.get('inicio', 0)):.3f}", "-t", f"{dur:.3f}", "-i", str(arq)]
        f = [f"fps={fps:.6f}", "setpts=PTS-STARTPTS"]
        if it.get("tela_cheia"):
            f += [f"scale={Wt}:{Ht}:force_original_aspect_ratio=increase:flags=lanczos", f"crop={Wt}:{Ht}"]
        else:
            larg = _par(Wt * max(0.03, min(3.0, float(it.get("escala", 0.4)))))
            f += [f"scale={larg}:-2:flags=lanczos"]
        if it.get("espelhar"):
            f.append("hflip")
        f.append("format=rgba")
        if it.get("chroma"):
            cor = str(it.get("cor_chroma") or "#00FF00").lstrip("#")
            f.append(f"colorkey=0x{cor}:{float(it.get('chroma_tol', 0.3)):.2f}:0.08")
        rot = float(it.get("rot", 0) or 0)
        if abs(rot) > 0.5:
            f.append(f"rotate={rot:.2f}*PI/180:c=none:ow=rotw({rot:.2f}*PI/180):oh=roth({rot:.2f}*PI/180)")
        op = float(it.get("opacidade", 1))
        if op < 0.99:
            f.append(f"colorchannelmixer=aa={op:.2f}")
        ent, sai = it.get("entrada", "fade"), it.get("saida", "fade")
        if ent in ("fade", "deslizar", "pop") and dur > 0.6:
            f.append("fade=t=in:st=0:d=0.25:alpha=1")
        if sai == "fade" and dur > 0.6:
            f.append(f"fade=t=out:st={max(0.0, dur - 0.25):.3f}:d=0.25:alpha=1")
        f.append(f"setpts=PTS+{ini:.3f}/TB")
        grafo += f"[{n_ent}:v]{','.join(f)}[tv{j}];"
        if it.get("tela_cheia"):
            xs, ys = "0", "0"
        else:
            cx, cy = float(it.get("x", 0.5)), float(it.get("y", 0.5))
            xs = f"main_w*{cx:.4f}-overlay_w/2"
            ys = f"main_h*{cy:.4f}-overlay_h/2"
            if ent == "deslizar":
                ys += f"+main_h*0.25*(1-min(1,(t-{ini:.3f})/0.3))"
        novo = f"to{j}"
        grafo += (f"[{rotulo}][tv{j}]overlay=x='{xs}':y='{ys}':eval=frame:eof_action=pass:"
                  f"enable='between(t,{ini:.3f},{ini + dur:.3f})'[{novo}];")
        rotulo = novo
        n_ent += 1
    return entradas, grafo, rotulo, n_ent


def tem_audio(arq: Path) -> bool:
    import subprocess
    try:
        r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a", "-show_entries", "stream=index",
                            "-of", "csv=p=0", str(arq)], capture_output=True, text=True, timeout=20)
        return bool(r.stdout.strip())
    except Exception:  # noqa: BLE001
        return False


def filtros_audio(itens: list[dict], n_ent: int, rotulo_audio: str):
    """Sons das trilhas de áudio (e o som de vídeos sobrepostos com volume > 0) misturados à fala."""
    entradas: list[str] = []
    grafo = ""
    sons = []
    for it in itens:
        if it.get("mudo"):
            continue
        vol = float(it.get("volume", 1 if it["tipo"] == "audio" else 0))
        if vol <= 0.001 or it["tipo"] not in ("audio", "video"):
            continue
        arq: Path = it["arquivo"]
        if it["tipo"] == "video" and arq.suffix.lower() in EXT_IMAGEM + EXT_GIF:
            continue
        if not tem_audio(arq):
            continue
        entradas += ["-ss", f"{float(it.get('inicio', 0)):.3f}", "-t", f"{it['dur']:.3f}", "-i", str(arq)]
        dur = it["dur"]
        fi, fo = float(it.get("fade_in", 0)), float(it.get("fade_out", 0.05))
        f = ["aresample=48000", "aformat=sample_fmts=fltp:channel_layouts=stereo", f"volume={vol:.3f}"]
        if fi > 0:
            f.append(f"afade=t=in:d={min(fi, dur):.3f}")
        if fo > 0:
            f.append(f"afade=t=out:st={max(0.0, dur - fo):.3f}:d={min(fo, dur):.3f}")
        ms = int(round(it["ini"] * 1000))
        f.append(f"adelay={ms}|{ms}")
        grafo += f"[{n_ent}:a]{','.join(f)}[sx{len(sons)}];"
        sons.append(f"[sx{len(sons)}]")
        n_ent += 1
    if not sons:
        return entradas, grafo, rotulo_audio, n_ent
    grafo += (f"[{rotulo_audio}]aformat=sample_fmts=fltp:channel_layouts=stereo[afala];[afala]{''.join(sons)}"
              f"amix=inputs={len(sons) + 1}:duration=first:normalize=0:dropout_transition=0,"
              f"alimiter=limit=0.97[amx];")
    return entradas, grafo, "amx", n_ent


# ============================================================ ajustes de imagem do vídeo principal
FILTROS_PRONTOS = {
    "nenhum": {},
    "vivo": {"saturacao": 1.35, "contraste": 1.08},
    "quente": {"temperatura": 5200, "saturacao": 1.1},
    "frio": {"temperatura": 8200},
    "cinema": {"contraste": 1.15, "saturacao": 0.85, "vinheta": 0.5},
    "retro": {"temperatura": 4800, "saturacao": 0.75, "contraste": 0.92, "brilho": 0.03},
    "pb": {"saturacao": 0.0, "contraste": 1.12},
    "suave": {"contraste": 0.92, "brilho": 0.04, "saturacao": 0.95},
}


def valores_cor(av: dict) -> dict:
    v = {"brilho": 0.0, "contraste": 1.0, "saturacao": 1.0, "temperatura": 6500, "vinheta": 0.0, "nitidez": 0.0}
    v.update(FILTROS_PRONTOS.get(av.get("filtro", "nenhum"), {}))
    for k in v:
        if av.get(k) is not None and av.get(k) != "":
            v[k] = float(av[k])
    return v


def filtro_cor(av: dict) -> str:
    """Cadeia de filtros de cor/espelho para o vídeo principal ('' = nada a fazer)."""
    if not av:
        return ""
    v = valores_cor(av)
    f = []
    if abs(v["brilho"]) > 0.005 or abs(v["contraste"] - 1) > 0.005 or abs(v["saturacao"] - 1) > 0.005:
        f.append(f"eq=brightness={v['brilho']:.3f}:contrast={v['contraste']:.3f}:saturation={v['saturacao']:.3f}")
    if abs(v["temperatura"] - 6500) > 50:
        f.append(f"colortemperature=temperature={int(v['temperatura'])}")
    if v["nitidez"] > 0.01:
        f.append(f"unsharp=5:5:{min(2.0, v['nitidez'] * 1.5):.2f}")
    if v["vinheta"] > 0.01:
        f.append(f"vignette=angle={0.15 + 0.55 * min(1.0, v['vinheta']):.3f}")
    if av.get("espelhar"):
        f.append("hflip")
    return ",".join(f)


EFEITOS_VOZ = {
    "normal": "",
    "grave": "aresample=48000,asetrate=40800,aresample=48000,atempo=1.1765",
    "aguda": "aresample=48000,asetrate=60000,aresample=48000,atempo=0.8",
    "esquilo": "aresample=48000,asetrate=72000,aresample=48000,atempo=0.6667",
    "robo": "afftfilt=real='hypot(re,im)*sin(0)':imag='hypot(re,im)*cos(0)':win_size=512:overlap=0.75",
    "eco": "aecho=0.8:0.85:280:0.35",
    "radio": "highpass=f=350,lowpass=f=3200,acompressor=threshold=-20dB:ratio=6",
    "caverna": "aecho=0.8:0.9:60|120:0.5|0.3",
}
