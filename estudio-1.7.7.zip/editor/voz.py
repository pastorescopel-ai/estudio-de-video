"""Tratamento da voz: limpeza de ruído (3 níveis) e efeitos de voz (no vídeo todo ou por personagem).
Usado na exportação e no áudio da prévia, para a prévia soar igual ao vídeo final."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from .trilhas import EFEITOS_VOZ
from .util import rodar_ffmpeg

LIMPEZA = {
    "nenhuma": ["highpass=f=60"],
    "equilibrada": ["highpass=f=75", "afftdn=nr=12:nf=-35:tn=1", "equalizer=f=3500:t=q:w=1.2:g=2.5",
                    "acompressor=threshold=-21dB:ratio=3:attack=5:release=150:makeup=2"],
    # isola a voz: corta graves/agudos fora da fala, tira ruído com força, silencia entre as falas
    "forte": ["highpass=f=95", "lowpass=f=8500", "afftdn=nr=25:nf=-28:tn=1", "afftdn=nr=10:nf=-40",
              "agate=threshold=0.025:ratio=6:attack=4:release=220:range=0.05",
              "equalizer=f=3200:t=q:w=1.2:g=3", "acompressor=threshold=-20dB:ratio=3.5:attack=5:release=150:makeup=2.5"],
}


def nivel(acfg: dict) -> str:
    n = acfg.get("limpeza")
    if n in LIMPEZA:
        return n
    return "equilibrada" if acfg.get("melhorar", True) else "nenhuma"


def cadeia_limpeza(acfg: dict) -> list[str]:
    out = list(LIMPEZA[nivel(acfg)])
    vv = float(acfg.get("volume_voz", 1.0) or 1.0)
    if abs(vv - 1) > 0.01:
        out.append(f"volume={vv:.2f}")
    return out


def _entre(trechos: list) -> str:
    return "+".join(f"between(t,{a:.3f},{b:.3f})" for a, b, _ in trechos) or "0"


def grafo_efeitos(entrada: str, saida: str, efeito_geral: str, trechos: list) -> str:
    """Aplica o efeito geral no vídeo todo e, por cima, efeitos só em trechos (personagens).
    trechos: [(início, fim, efeito)] no tempo do áudio que entra."""
    geral = EFEITOS_VOZ.get(efeito_geral or "normal", "")
    por_efeito: dict[str, list] = {}
    for a, b, e in trechos or []:
        if EFEITOS_VOZ.get(e, "") != geral:
            por_efeito.setdefault(e, []).append((a, b, e))
    if not por_efeito:
        return f"[{entrada}]{geral or 'anull'}[{saida}]"
    ramos = len(por_efeito) + 1
    g = f"[{entrada}]asplit={ramos}" + "".join(f"[r{k}]" for k in range(ramos)) + ";"
    todos = [t for ts in por_efeito.values() for t in ts]
    g += f"[r0]{geral + ',' if geral else ''}volume='1-min(1,{_entre(todos)})':eval=frame[s0];"
    for k, (e, ts) in enumerate(por_efeito.items(), 1):
        ef = EFEITOS_VOZ.get(e, "") or "anull"
        g += f"[r{k}]{ef},volume='min(1,{_entre(ts)})':eval=frame[s{k}];"
    g += "".join(f"[s{k}]" for k in range(ramos)) + f"amix=inputs={ramos}:normalize=0:duration=first[{saida}]"
    return g


def trechos_personagens(aj: dict, palavras: list[dict], tempo) -> list[tuple]:
    """Trechos (no tempo dado por `tempo(palavra) -> (s, e) | None`) em que cada personagem com voz
    diferente da normal fala."""
    pers = {int(p["id"]): p for p in (aj.get("personagens") or []) if p.get("voz") and p.get("voz") != "normal"}
    falas = aj.get("falas") or []
    if not pers or not falas:
        return []
    out: list[list] = []
    for i, w in enumerate(palavras):
        if i >= len(falas) or falas[i] is None or int(falas[i]) not in pers or w.get("removida"):
            continue
        r = tempo(w)
        if not r:
            continue
        ef = pers[int(falas[i])]["voz"]
        a, b = max(0.0, r[0] - 0.06), r[1] + 0.12
        if out and out[-1][2] == ef and a - out[-1][1] < 0.35:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b, ef])
    return [tuple(x) for x in out]


def audio_previa(fonte: Path, pasta: Path, acfg: dict, trechos: list) -> Path:
    """Áudio da prévia no tempo do vídeo original (toca junto com a prévia, no lugar do som dela)."""
    chave = hashlib.sha1(json.dumps([nivel(acfg), acfg.get("volume_voz"), acfg.get("efeito_voz"), trechos],
                                    sort_keys=True, default=str).encode()).hexdigest()[:12]
    destino = pasta / f"audio_previa_{chave}.webm"
    if destino.exists() and destino.stat().st_size > 0:
        return destino
    for velho in list(pasta.glob("audio_previa_*.m4a")) + list(pasta.glob("audio_previa_*.webm")):
        velho.unlink(missing_ok=True)
    limpa = ",".join(cadeia_limpeza(acfg))
    g = f"[0:a]aresample=48000,{limpa}[lv];" + grafo_efeitos("lv", "fx", acfg.get("efeito_voz", "normal"), trechos)
    tmp = destino.with_name("audio_previa_tmp.webm")
    # Opus em WebM: toca em qualquer Edge/Chrome/Firefox
    rodar_ffmpeg(["-i", str(fonte), "-filter_complex", g, "-map", "[fx]", "-ac", "2", "-c:a", "libopus", "-b:a", "128k",
                  str(tmp)])
    tmp.replace(destino)
    return destino
