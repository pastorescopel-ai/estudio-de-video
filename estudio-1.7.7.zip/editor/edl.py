"""Transforma (palavras + cortes aprovados) em trechos a manter, e mapeia tempos."""
from __future__ import annotations

import bisect


def trechos_mantidos(palavras: list[dict], cortes: list[dict], duracao: float, cfg: dict,
                     fps: float, folgas: dict | None = None) -> list[tuple[float, float]]:
    """folgas: ajuste fino das bordas feito no editor, por palavra:
    {"12": {"e": s, "d": s}} = segundos a mais (ou a menos, se negativo) antes/depois da palavra 12."""
    ccfg = cfg.get("cortes", {})
    pb = float(ccfg.get("respiro_antes", 0.10))
    pa = float(ccfg.get("respiro_depois", 0.16))
    n = len(palavras)
    if n == 0:
        return [(0.0, duracao)]

    removida = [False] * n
    pausa_cortada: set[int] = set()
    for c in cortes:
        if not c.get("ativo"):
            continue
        if "pausa" in c:
            pausa_cortada.add(int(c["pausa"]))
        for i in c.get("palavras", []):
            if 0 <= i < n:
                removida[i] = True

    mantidas = [k for k in range(n) if not removida[k]]
    if not mantidas:
        raise SystemExit("Todos os trechos foram marcados para corte — nada sobrou do vídeo.")

    fol = folgas or {}

    def fe(i: int) -> float:
        return float((fol.get(str(i)) or {}).get("e", 0) or 0)

    def fd(i: int) -> float:
        return float((fol.get(str(i)) or {}).get("d", 0) or 0)

    trechos: list[list[float]] = []
    primeira = mantidas[0]
    corta_inicio = -1 in pausa_cortada or primeira > 0
    ini = max(0.0, min(palavras[primeira]["s"], palavras[primeira]["s"] - pb - fe(primeira))) if corta_inicio else 0.0
    trechos.append([ini, None])

    for a, b in zip(mantidas, mantidas[1:]):
        wa, wb = palavras[a], palavras[b]
        algo_removido = (b - a > 1) or (a in pausa_cortada)
        if not algo_removido:
            continue
        cs, ce = wa["e"] + pa, wb["s"] - pb
        if fd(a) or fe(b):   # borda ajustada à mão: respeita exatamente
            cs = max(wa["s"] + 0.04, cs + fd(a))
            ce = min(wb["e"] - 0.04, ce - fe(b))
            if ce - cs < 0.04:
                continue
            trechos[-1][1] = cs
            trechos.append([ce, None])
            continue
        if ce - cs < 0.08:
            cs, ce = wa["e"] + 0.02, wb["s"] - 0.02
            if b - a > 1:  # palavras removidas no meio: corta exatamente nelas
                cs = max(cs, palavras[a + 1]["s"] - 0.01)
                ce = min(ce, palavras[b - 1]["e"] + 0.01)
        if ce - cs < 0.04:
            continue
        trechos[-1][1] = cs
        trechos.append([ce, None])

    ultima = mantidas[-1]
    fim_cortado = (n - 1) in pausa_cortada or ultima < n - 1
    trechos[-1][1] = (min(duracao, max(palavras[ultima]["s"] + 0.04, palavras[ultima]["e"] + pa + 0.25 + fd(ultima)))
                      if fim_cortado else duracao)

    # alinha à grade de quadros (evita dessincronizar áudio/vídeo ao somar centenas de cortes)
    q = 1.0 / fps
    saida: list[tuple[float, float]] = []
    for s, e in trechos:
        s, e = round(s / q) * q, round(e / q) * q
        if e - s >= 2 * q:
            if saida and s <= saida[-1][1]:
                saida[-1] = (saida[-1][0], max(saida[-1][1], e))
            else:
                saida.append((round(s, 6), round(e, 6)))
    return saida


class Mapa:
    """Converte tempo do vídeo original -> tempo do vídeo editado."""

    def __init__(self, trechos: list[tuple[float, float]]):
        self.trechos = trechos
        self.inicios = [s for s, _ in trechos]
        self.acum = []
        t = 0.0
        for s, e in trechos:
            self.acum.append(t)
            t += e - s
        self.total = t

    def indice(self, t: float) -> int | None:
        k = bisect.bisect_right(self.inicios, t) - 1
        if k < 0 or t > self.trechos[k][1]:
            return None
        return k

    def mapear(self, t: float) -> float | None:
        k = self.indice(t)
        if k is None:
            return None
        return self.acum[k] + (t - self.trechos[k][0])

    def palavra(self, w: dict) -> tuple[float, float] | None:
        """Tempo de saída de uma palavra (None se foi cortada)."""
        meio = (w["s"] + w["e"]) / 2
        k = self.indice(meio)
        if k is None:
            return None
        s, e = self.trechos[k]
        ws, we = max(w["s"], s), min(w["e"], e)
        return self.acum[k] + ws - s, self.acum[k] + we - s
