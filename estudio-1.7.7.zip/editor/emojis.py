"""Emojis da legenda: um conjunto escolhido (desenhos Twemoji, CC-BY 4.0) com palavras que os chamam.

Os PNGs ficam na pasta emojis/ (nome = código do emoji). A IA só escolhe desta lista; sem IA,
as palavras-chave abaixo bastam."""
from __future__ import annotations

import re
import unicodedata
from pathlib import Path

from .util import RAIZ

PASTA = RAIZ / "emojis"

# emoji: radicais de palavras (sem acento, minúsculas) que o chamam
LISTA: dict[str, list[str]] = {
    "💰": ["dinheir", "grana", "riqueza", "rico", "lucro", "salari", "renda", "fortuna"],
    "💸": ["gast", "divida", "prejuiz", "desperdic", "pagar", "pagamento", "conta"],
    "💳": ["cartao", "credito", "parcel"],
    "🏦": ["banco", "investiment", "poupanc", "aplicac"],
    "📈": ["cresc", "aument", "subi", "result", "melhor", "evolu", "lucr"],
    "📉": ["cai", "queda", "diminu", "pior", "perd"],
    "📊": ["dado", "numero", "porcent", "estatist", "pesquisa", "grafico", "metrica"],
    "💯": ["cem", "100", "total", "perfeit", "certeza", "absolut"],
    "💡": ["ideia", "dica", "solucao", "entend", "aprend", "descobr", "insight"],
    "🧠": ["mente", "cerebr", "pensar", "inteligen", "memori", "raciocin", "mental"],
    "🤔": ["pense", "pensa", "duvida", "sera", "por que", "porque", "pergunt"],
    "🤯": ["incrivel", "chocante", "absurd", "surpre", "inacredit"],
    "🔥": ["fogo", "quente", "top", "sucesso", "bomba", "viral", "imperdivel"],
    "🚀": ["rapid", "foguete", "decol", "crescer", "lanc", "acelera", "escal"],
    "⚡": ["energia", "rapido", "instant", "poder", "forca"],
    "✨": ["magic", "brilh", "especial", "lind", "nov"],
    "⭐": ["estrela", "destaque", "favorit", "qualidade", "excelen"],
    "🏆": ["vitori", "venc", "campe", "conquist", "premio", "ganh"],
    "🥇": ["primeir", "melhor", "ouro", "lider"],
    "🎯": ["objetiv", "meta", "foco", "alvo", "propos", "certeir"],
    "🧩": ["parte", "peca", "detalhe", "complet"],
    "✅": ["certo", "correto", "sim", "pronto", "feito", "aprov", "funcion", "verdade"],
    "❌": ["errad", "nao", "nunca", "jamais", "proib", "evite", "mentira"],
    "⚠️": ["atenc", "cuidado", "perigo", "alerta", "risco", "aviso"],
    "🛑": ["pare", "parar", "chega", "basta"],
    "🚫": ["proibido", "evit", "sem"],
    "❓": ["pergunta", "questao", "como", "qual", "o que"],
    "❗": ["important", "essencial", "urgente", "fundamental"],
    "👉": ["olha", "veja", "aqui", "segue", "proximo", "passo"],
    "👀": ["olho", "ver", "assist", "observ", "repar", "visao", "segredo"],
    "👂": ["ouvir", "escut", "ouca"],
    "🗣️": ["falar", "fala", "dizer", "conversa", "comunic"],
    "💬": ["comenta", "mensage", "convers", "palavra", "chat"],
    "📣": ["anunc", "divulg", "avis", "compartilh", "notic"],
    "🔔": ["notific", "lembr", "inscrev", "sino"],
    "👍": ["bom", "boa", "legal", "otimo", "gostei", "curt", "positiv"],
    "👎": ["ruim", "pessim", "negativ", "nao gost"],
    "👏": ["parabens", "aplaus", "bravo", "sucesso"],
    "🙌": ["gloria", "aleluia", "comemor", "conseg"],
    "👋": ["ola", "oi", "tchau", "bem-vind", "bem vind", "galera", "pessoal"],
    "🤝": ["parceri", "acordo", "negoci", "junt", "uniao", "cliente", "equipe"],
    "💪": ["forte", "forca", "muscul", "trein", "corag", "superar", "disciplin", "determin"],
    "🙏": ["deus", "ora", "fe", "gratid", "obrigad", "agradec", "benc", "senhor", "jesus"],
    "📖": ["biblia", "livro", "palavra de deus", "leitur", "versicul", "estud"],
    "⛪": ["igreja", "culto", "templo", "missa"],
    "🕊️": ["paz", "esperanc", "espirito", "perdao", "calma"],
    "❤️": ["amor", "amo", "coracao", "carinh", "paixao", "querid", "cuidar", "cuidado"],
    "💔": ["triste", "decepc", "separ", "termin", "dor"],
    "😊": ["feliz", "alegr", "sorri", "content", "satisf"],
    "😂": ["rir", "risada", "engracad", "piada", "kkk"],
    "😢": ["chor", "trist", "saudade", "lagrim"],
    "😡": ["raiva", "irrit", "brav", "odio", "estress"],
    "😎": ["estilo", "tranquil", "relax", "facil", "suave"],
    "😴": ["sono", "dormi", "cansa", "descans"],
    "😮": ["uau", "nossa", "caramba", "surpres"],
    "⏰": ["hora", "tempo", "prazo", "agora", "rotina", "manha", "acordar", "minuto"],
    "⏳": ["espera", "paciencia", "aguard", "demor", "logo"],
    "📅": ["dia", "data", "semana", "mes", "agenda", "calendari", "ano"],
    "📝": ["anot", "escrev", "lista", "plano", "planej", "resumo", "tarefa"],
    "📚": ["estud", "livros", "conhecim", "curso", "aula", "escola", "faculdade", "ler"],
    "🎓": ["formatur", "diploma", "universid", "graduac", "aluno", "professor"],
    "💼": ["trabalh", "emprego", "carreira", "negocio", "empres", "profission", "servic"],
    "🏢": ["empresa", "escritori", "corporat", "predio"],
    "🏠": ["casa", "lar", "famil", "morar", "imovel"],
    "👨‍👩‍👧": ["familia", "filhos", "pais", "mae", "pai"],
    "👶": ["bebe", "crianc", "nasc", "gravid"],
    "👴": ["idoso", "avo", "velh", "aposent"],
    "🏥": ["hospital", "saude", "clinica", "atendiment", "paciente", "medic"],
    "🩺": ["medico", "consulta", "exame", "diagnost", "enfermeir"],
    "💊": ["remedio", "medicament", "tratament", "comprimido"],
    "💉": ["vacina", "injec"],
    "🍎": ["aliment", "comida", "fruta", "saudavel", "nutri", "dieta", "comer"],
    "🥗": ["salada", "verdura", "vegetal", "legume", "vegan", "vegetarian"],
    "💧": ["agua", "hidrat", "beber"],
    "🏃": ["corr", "exercic", "ativ", "caminh", "movimento"],
    "🛌": ["dormir", "cama", "repous"],
    "☕": ["cafe", "pausa", "intervalo"],
    "🌎": ["mundo", "planeta", "global", "internac", "pais"],
    "🇧🇷": ["brasil", "brasileir"],
    "☀️": ["sol", "dia", "verao", "calor", "luz"],
    "🌙": ["noite", "lua", "madrugad"],
    "🌱": ["comec", "inicio", "semente", "plant", "natureza", "crescer"],
    "🌈": ["arco", "diversidad", "cores", "promessa"],
    "📱": ["celular", "telefone", "app", "aplicativ", "instagram", "whatsapp", "rede social", "redes"],
    "💻": ["computador", "internet", "online", "site", "digital", "tecnolog", "notebook"],
    "📧": ["email", "e-mail"],
    "🔗": ["link", "conexao", "bio"],
    "🔍": ["procur", "busca", "pesquis", "analis", "investig", "encontr"],
    "⚙️": ["process", "sistema", "configur", "funciona", "ajust", "automat"],
    "🛠️": ["ferrament", "consert", "constru", "fazer"],
    "🔑": ["chave", "segredo", "acesso", "solucao"],
    "🔒": ["seguranc", "protec", "senha", "privad", "bloque"],
    "🛡️": ["proteg", "defes", "seguro", "garant"],
    "💎": ["valor", "precios", "raro", "premium", "joia"],
    "👑": ["rei", "rainha", "reina", "lider", "dono"],
    "🎁": ["presente", "gratis", "bonus", "brinde", "surpresa", "oferta"],
    "🎉": ["festa", "comemor", "celebr", "aniversar", "parabens"],
    "🛒": ["compr", "mercado", "loja", "venda", "produto", "preco"],
    "🧾": ["nota", "recibo", "imposto", "conta"],
    "🚗": ["carro", "dirigir", "viagem", "transito"],
    "✈️": ["viaj", "aviao", "ferias", "destino"],
    "🎬": ["video", "filme", "gravar", "cena", "conteudo"],
    "📸": ["foto", "imagem", "camera"],
    "🎤": ["cantar", "palestra", "microfone", "podcast", "entrevista"],
    "🎵": ["musica", "cancao", "louvor", "som"],
    "🐶": ["cachorro", "cao", "pet"],
    "🐱": ["gato"],
}

_NORMAL = None


def _sem_acento(t: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", t.lower()) if unicodedata.category(c) != "Mn")


def codigo(e: str) -> str:
    """Nome do arquivo (igual ao do Twemoji): códigos em hexadecimal, sem o FE0F."""
    return "-".join(f"{ord(c):x}" for c in e if ord(c) != 0xFE0F)


def arquivo(e: str) -> Path | None:
    p = PASTA / f"{codigo(e)}.png"
    return p if p.is_file() else None


def disponiveis() -> list[str]:
    return [e for e in LISTA if arquivo(e)]


def sugerir_para(texto: str) -> str | None:
    """Emoji para um trecho de fala, só pelas palavras (sem IA)."""
    t = " " + re.sub(r"[^\w\s-]", " ", _sem_acento(texto)) + " "
    melhor, pos = None, 10 ** 9
    for e, radicais in LISTA.items():
        for r in radicais:
            k = t.find(" " + r)
            if k >= 0 and len(r) >= 3 and k < pos:
                melhor, pos = e, k
    return melhor
