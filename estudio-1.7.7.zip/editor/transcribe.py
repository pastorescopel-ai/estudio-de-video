"""Transcrição com timestamps por palavra (faster-whisper, GPU NVIDIA quando disponível)."""
from __future__ import annotations

import os
import site
import sys
from pathlib import Path

from .util import aviso, barra, info

# Frase-guia: faz o Whisper escrever as hesitações em vez de "limpar" a fala,
# senão não teríamos como cortá-las.
PROMPT_VERBATIM = ("Éé... então, hã, a gente vai, hum, falar sobre isso. Ahn, tipo, né? "
                   "Eu eu vou mostrar, éé, como funciona.")


def _registrar_dlls_cuda() -> None:
    """No Windows, as DLLs do CUDA instaladas via pip ficam em site-packages/nvidia/*/bin."""
    if sys.platform != "win32":
        return
    for base in site.getsitepackages() + [site.getusersitepackages()]:
        nv = Path(base) / "nvidia"
        if not nv.is_dir():
            continue
        for pasta in nv.glob("*/bin"):
            try:
                os.add_dll_directory(str(pasta))
            except OSError:
                pass
            os.environ["PATH"] = str(pasta) + os.pathsep + os.environ.get("PATH", "")


def _compat_av() -> None:
    """Versões novas da biblioteca PyAV não aceitam mais o parâmetro metadata_errors,
    que algumas versões do faster-whisper ainda passam. Remove o parâmetro se preciso."""
    try:
        import av
        original = av.open
        if getattr(original, "_estudio", False):
            return

        def aberto(*a, **k):
            try:
                return original(*a, **k)
            except TypeError as e:
                if "metadata_errors" in str(e):
                    k.pop("metadata_errors", None)
                    return original(*a, **k)
                raise
        aberto._estudio = True  # type: ignore[attr-defined]
        av.open = aberto
    except Exception:  # noqa: BLE001
        pass


def _carregar_modelo(nome: str, dispositivo: str):
    _compat_av()
    from faster_whisper import WhisperModel

    if dispositivo in ("auto", "cuda"):
        _registrar_dlls_cuda()
        try:
            m = WhisperModel(nome, device="cuda", compute_type="float16")
            info(f"Transcrevendo na placa de vídeo (modelo {nome}).")
            return m
        except Exception as e:  # noqa: BLE001
            if dispositivo == "cuda":
                raise
            aviso(f"GPU indisponível para transcrição ({str(e).splitlines()[0][:90]}). Usando o processador.")
    info(f"Transcrevendo no processador (modelo {nome}) — pode demorar.")
    return WhisperModel(nome, device="cpu", compute_type="int8")


def _audio_16k(video: Path):
    """Decodifica o áudio com o nosso FFmpeg (16 kHz, mono, float32).

    Não usamos o leitor interno do faster-whisper (biblioteca PyAV): versões novas
    dela mudaram a função open() e quebram com "unexpected keyword argument
    'metadata_errors'". Com o FFmpeg funciona com qualquer versão."""
    import subprocess
    import numpy as np
    r = subprocess.run(["ffmpeg", "-v", "error", "-nostdin", "-i", str(video), "-vn", "-map", "0:a:0?",
                        "-ac", "1", "-ar", "16000", "-f", "f32le", "-"],
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if r.returncode != 0:
        raise RuntimeError("não consegui ler o áudio do vídeo: " + r.stderr.decode("utf-8", "replace")[-300:])
    audio = np.frombuffer(r.stdout, dtype=np.float32)
    if audio.size == 0:
        raise RuntimeError("o vídeo não tem áudio para transcrever")
    return audio


def transcrever(video: Path, cfg: dict, duracao: float) -> list[dict]:
    """Retorna lista de palavras: {i, w, s, e, p} (texto, início, fim, confiança)."""
    tcfg = cfg.get("transcricao", {})
    modelo = _carregar_modelo(tcfg.get("modelo", "large-v3"), tcfg.get("dispositivo", "auto"))
    segmentos, _ = modelo.transcribe(
        _audio_16k(video),
        language=cfg.get("idioma", "pt"),
        word_timestamps=True,
        initial_prompt=PROMPT_VERBATIM,
        condition_on_previous_text=False,   # evita "loops" de alucinação
        vad_filter=False,                  # queremos ver as pausas nós mesmos
        beam_size=5,
        temperature=[0.0, 0.2, 0.4],
    )
    palavras: list[dict] = []
    for seg in segmentos:
        for w in seg.words or []:
            texto = w.word.strip()
            if not texto:
                continue
            palavras.append({"w": texto, "s": round(w.start, 3), "e": round(w.end, 3),
                             "p": round(w.probability, 3), "seg": seg.id})
        if duracao:
            barra(seg.end / duracao, sufixo="transcrição")
    barra(1.0, sufixo="transcrição")
    del segmentos, modelo   # libera a memória da placa de vídeo para a IA local e a exportação
    import gc
    gc.collect()
    return normalizar(palavras)


def normalizar(palavras: list[dict]) -> list[dict]:
    """Ordena, numera e garante tempos coerentes (sem sobreposição, duração mínima)."""
    palavras = sorted(palavras, key=lambda x: x["s"])
    for k, w in enumerate(palavras):
        w["i"] = k
        if w["e"] < w["s"] + 0.04:
            w["e"] = w["s"] + 0.04
        if k and w["s"] < palavras[k - 1]["e"]:
            palavras[k - 1]["e"] = max(palavras[k - 1]["s"] + 0.02, w["s"])
    return palavras
