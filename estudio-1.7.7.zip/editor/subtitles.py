"""Legendas: dinâmicas palavra a palavra (ASS, queimadas no vídeo) e .srt."""
from __future__ import annotations

import re
from pathlib import Path

from .edl import Mapa


def _cor_ass(hexcor: str, alfa: int = 0) -> str:
    h = hexcor.lstrip("#")
    r, g, b = h[0:2], h[2:4], h[4:6]
    return f"&H{alfa:02X}{b}{g}{r}".upper()


def _t(seg: float) -> str:
    seg = max(0.0, seg)
    cs = int(round(seg * 100))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def palavras_saida(palavras: list[dict], mapa: Mapa) -> list[dict]:
    """Palavras que sobreviveram aos cortes, com tempos do vídeo final."""
    saida = []
    for idx, w in enumerate(palavras):
        if w.get("removida"):
            continue
        r = mapa.palavra(w)
        if r is None or r[1] - r[0] < 0.02:
            continue
        txt = w.get("txt", w["w"]).strip()
        if txt:
            saida.append({"w": txt, "s": r[0], "e": r[1], "q": bool(w.get("quebra")), "i": w.get("i", idx)})
    return saida


def agrupar(pal: list[dict], max_palavras: int, max_chars: int) -> list[list[dict]]:
    """Mesma regra usada na tela do editor (editor.html: agrupar)."""
    grupos: list[list[dict]] = []
    atual: list[dict] = []
    for k, w in enumerate(pal):
        if atual:
            chars = sum(len(x["w"]) + 1 for x in atual) + len(w["w"])
            pausa = w["s"] - atual[-1]["e"] > 0.45
            if len(atual) >= max_palavras or chars > max_chars or pausa or w.get("q"):
                grupos.append(atual)
                atual = []
        atual.append(w)
        if re.search(r"[.!?…]$", w["w"]):  # fim de frase fecha o grupo
            grupos.append(atual)
            atual = []
    if atual:
        grupos.append(atual)
    return grupos


# ============================================================ estilos
PADRAO = {
    "ativar": True, "modo": "karaoke", "fonte": "Montserrat ExtraBold",
    "cor": "#FFFFFF", "destaque": "#FFD60A", "contorno": "#000000", "texto_caixa": "#000000",
    "maiusculas": True, "tamanho": 100, "espessura_contorno": 100,
    "max_palavras": 3, "max_caracteres": 20,
    "posicao_vertical": 0.68, "posicao_horizontal": 0.90, "pos_x": 0.5,
    "animacao": "saltar", "fundo": "sombra", "cor_fundo": "#000000",
    "chave": False, "cor_chave": "#3CFF8F", "emojis": False,
}
MODOS = ("karaoke", "caixa", "palavra", "classica")
ANIMACOES = ("nenhuma", "saltar", "deslizar", "surgir", "maquina")
FUNDOS = ("nenhum", "sombra", "neon", "tarja")
ESCALA_MODO = {"palavra": 1.4, "classica": 0.75}


def estilo_global(lc: dict) -> dict:
    """Estilo do vídeo, com valores padrão e compatível com as versões antigas (animacao true/false)."""
    e = {**PADRAO, **{k: v for k, v in (lc or {}).items() if v is not None}}
    if e["animacao"] is True:
        e["animacao"] = "saltar"
    elif e["animacao"] is False or e["animacao"] not in ANIMACOES:
        e["animacao"] = "nenhuma" if e["animacao"] is False else "saltar"
    if e["modo"] not in MODOS:
        e["modo"] = "karaoke"
    if e["fundo"] not in FUNDOS:
        e["fundo"] = "sombra"
    return e


def estilo_do_grupo(base: dict, trechos: list[dict], g: list[dict], enfases: list[dict] | None = None) -> dict:
    """Estilo de um grupo: o do vídeo + o que foi mudado só naquele trecho (o último vale).
    Grupos dentro de um momento de ênfase ficam 25% maiores e com animação."""
    e = dict(base)
    i0 = g[0].get("i", -1)
    i1 = g[-1].get("i", -1)
    for t in trechos or []:
        if int(t.get("i0", -9)) <= i0 <= int(t.get("i1", -9)):
            e.update({k: v for k, v in (t.get("estilo") or {}).items() if v is not None})
    e = estilo_global(e)
    for m in enfases or []:
        if m.get("legenda", True) and int(m.get("de", -9)) <= i1 and i0 <= int(m.get("ate", -9)):
            e["tamanho"] = float(e["tamanho"]) * 1.25
            if e["animacao"] == "nenhuma":
                e["animacao"] = "saltar"
            e["enfase"] = True
            break
    return e


# ============================================================ fontes e medidas
class Metrica:
    """Medidas de uma fonte do jeito que o libass (o desenhista da legenda) usa:
    o tamanho \\fs corresponde a winAscent + winDescent."""

    def __init__(self, arq: Path | None):
        self.adv: dict[int, int] = {}
        self.altura, self.asc, self.cap, self.upem = 1000, 800, 700, 1000
        if not arq:
            return
        try:
            from fontTools.ttLib import TTFont
            f = TTFont(str(arq), lazy=True, fontNumber=0)
            os2 = f["OS/2"]
            self.upem = f["head"].unitsPerEm
            wa, wd = int(os2.usWinAscent), int(os2.usWinDescent)
            if wa + wd <= 0:
                wa, wd = f["hhea"].ascent, -f["hhea"].descent
            self.altura, self.asc = wa + wd, wa
            self.cap = int(getattr(os2, "sCapHeight", 0) or wa * 0.7)
            cmap = f.getBestCmap() or {}
            hmtx = f["hmtx"].metrics
            self.adv = {cp: hmtx[g][0] for cp, g in cmap.items() if g in hmtx}
            self._media = sum(self.adv.values()) / max(1, len(self.adv))
        except Exception:  # noqa: BLE001
            self.adv = {}

    def largura(self, texto: str, fs: float) -> float:
        media = getattr(self, "_media", self.upem * 0.6)
        return sum(self.adv.get(ord(c), media) for c in texto) * fs / self.altura

    def k_css(self) -> float:   # font-size do navegador = fs * k
        return self.upem / self.altura


def catalogo_fontes() -> list[dict]:
    """Fontes da pasta fontes/: nome de família (o que o libass procura) e medidas para a prévia."""
    from .render import _familia_da_fonte, arquivos_de_fonte
    out, vistos = [], set()
    for f in arquivos_de_fonte():
        fam = _familia_da_fonte(f) or f.stem
        if fam.lower() in vistos:
            continue
        vistos.add(fam.lower())
        m = Metrica(f)
        out.append({"familia": fam, "arquivo": f.name, "url": f"/fontes/{f.name}",
                    "k": round(m.k_css(), 4), "asc": round(m.asc / m.altura, 4), "cap": round(m.cap / m.altura, 4)})
    return sorted(out, key=lambda x: x["familia"].lower())


def _arquivo_da_fonte(familia: str) -> Path | None:
    from .render import RAIZ
    for x in catalogo_fontes():
        if x["familia"].lower() == familia.lower():
            return RAIZ / "fontes" / x["arquivo"]
    return None


_METRICAS: dict[str, Metrica] = {}


def metrica(familia: str) -> Metrica:
    if familia not in _METRICAS:
        _METRICAS[familia] = Metrica(_arquivo_da_fonte(familia) or _arquivo_da_fonte("Montserrat ExtraBold"))
    return _METRICAS[familia]


def geometria(W: int, H: int, formato: str, lc: dict) -> tuple[int, int, int]:
    """Tamanho da fonte, margem inferior e contorno (a tela do editor usa a mesma conta)."""
    horizontal = W > H
    base = H * 0.068 if horizontal else W * (0.085 if formato != "quadrado" else 0.075)
    tam = int(base * float(lc.get("tamanho", 100)) / 100 * ESCALA_MODO.get(lc.get("modo", ""), 1.0))
    chave = "posicao_horizontal" if horizontal else "posicao_vertical"
    pos = float(lc.get(chave, 0.90 if horizontal else 0.68))
    margem_v = int(H * (1 - pos))
    borda = max(0, int(tam * 0.09 * float(lc.get("espessura_contorno", 100)) / 100))
    return tam, margem_v, borda


def _limpar(t: str, maiusc: bool) -> str:
    t = t.replace("{", "(").replace("}", ")").replace("\\", "/")
    t = re.sub(r"[,;]+$", "", t)
    t = re.sub(r"\.$", "", t)  # ponto final não fica bonito na legenda dinâmica
    return t.upper() if maiusc else t


def _ret_arredondado(w: float, h: float, r: float) -> str:
    """Retângulo de cantos redondos em desenho ASS (\\p1), com origem no canto superior esquerdo."""
    r = max(0.0, min(r, w / 2, h / 2))
    c = r * 0.45
    f = lambda v: f"{v:.1f}"  # noqa: E731
    return (f"m {f(r)} 0 l {f(w - r)} 0 b {f(w - c)} 0 {f(w)} {f(c)} {f(w)} {f(r)} "
            f"l {f(w)} {f(h - r)} b {f(w)} {f(h - c)} {f(w - c)} {f(h)} {f(w - r)} {f(h)} "
            f"l {f(r)} {f(h)} b {f(c)} {f(h)} 0 {f(h - c)} 0 {f(h - r)} "
            f"l 0 {f(r)} b 0 {f(c)} {f(c)} 0 {f(r)} 0")


def tempos_grupos(grupos: list[list[dict]], leg_tempo: dict | None = None) -> list[tuple]:
    """Início, fim e deslocamento de cada legenda. leg_tempo = {primeira palavra: {m, a, b}}:
    m = legenda arrastada inteira, a/b = borda esquerda/direita puxada (em segundos do vídeo final)."""
    lt = {str(k): v for k, v in (leg_tempo or {}).items() if isinstance(v, dict)}
    brutos = []
    for k, g in enumerate(grupos):
        ini, fim = g[0]["s"], g[-1]["e"] + 0.25
        if k + 1 < len(grupos):
            fim = min(fim, grupos[k + 1][0]["s"])
        o = lt.get(str(g[0].get("i")), {})
        m = float(o.get("m", 0) or 0)
        ini = max(0.0, ini + m + float(o.get("a", 0) or 0))
        fim = fim + m + float(o.get("b", 0) or 0)
        brutos.append([ini, fim, m])
    out, ant = [], 0.0
    for k, (ini, fim, m) in enumerate(brutos):
        ini = max(ini, ant)
        if k + 1 < len(brutos):
            fim = min(fim, brutos[k + 1][0])
        out.append((ini, fim, m))
        ant = max(ant, fim)
    return out


def gerar_ass(pal: list[dict], destino: Path, W: int, H: int, formato: str, cfg: dict,
              fonte: str = "", negrito: bool = False, trechos: list[dict] | None = None,
              chaves: list[int] | None = None, emojis: dict | None = None,
              enfases: list[dict] | None = None, gancho: dict | None = None,
              textos_livres: list[dict] | None = None, leg_tempo: dict | None = None) -> list[dict]:
    """Escreve o .ass e devolve onde entram os emojis: [{emoji, ini, fim, x, y, tam}].

    Cada palavra vira um evento próprio, posicionado por nós (medindo a fonte). Assim dá para ter
    caixa atrás da palavra falada, uma palavra por vez, animações por palavra e estilo por trecho."""
    base = estilo_global(cfg.get("legenda", {}))
    vazio = "[Script Info]\nScriptType: v4.00+\n\n[Events]\n"
    if not base["ativar"]:
        destino.write_text(vazio, encoding="utf-8")
        return []
    chaves_set = {int(x) for x in (chaves or [])}
    emo = {int(k): v for k, v in (emojis or {}).items()}
    horizontal = W > H

    cab = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Leg,{base['fonte']},60,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,3,0,5,0,0,0,1
Style: Caixa,{base['fonte']},60,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,0,0,5,0,0,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    linhas: list[str] = []
    saida_emojis: list[dict] = []
    grupos = agrupar(pal, 1 if base["modo"] == "palavra" else int(base["max_palavras"]),
                     int(base["max_caracteres"]))
    ms = lambda a: max(0, int(round(a * 1000)))  # noqa: E731
    tempos = tempos_grupos(grupos, leg_tempo)

    for g_i, g in enumerate(grupos):
        st = estilo_do_grupo(base, trechos or [], g, enfases)
        fs, _, borda = geometria(W, H, formato, st)
        fs = max(8, fs)
        met = metrica(st["fonte"])
        maiusc = bool(st["maiusculas"])
        g0, fim_grupo, desl = tempos[g_i]
        if fim_grupo - g0 < 0.05:
            continue
        textos = [_limpar(w["w"], maiusc) for w in g]
        eh_chave = [st["chave"] and w.get("i") in chaves_set for w in g]
        esc = [1.15 if c else 1.0 for c in eh_chave]
        larg = [met.largura(t, fs) * e for t, e in zip(textos, esc)]
        modo = st["modo"]
        espaco = met.largura(" ", fs) * (1.6 if modo == "caixa" else 1.1)

        # ---- quebra em linhas (no máximo 86% da largura)
        maxw = W * 0.86
        linhas_idx: list[list[int]] = [[]]
        if modo == "palavra":
            linhas_idx = [[j] for j in range(len(g))]   # cada palavra sozinha, no mesmo lugar
        else:
            atual_w = 0.0
            for j, lw in enumerate(larg):
                novo = lw if not linhas_idx[-1] else atual_w + espaco + lw
                if linhas_idx[-1] and novo > maxw:
                    linhas_idx.append([j])
                    atual_w = lw
                else:
                    linhas_idx[-1].append(j)
                    atual_w = novo
        alt_linha = fs * 1.12
        n_l = 1 if modo == "palavra" else len(linhas_idx)
        pos = float(st["posicao_horizontal" if horizontal else "posicao_vertical"])
        fundo_bloco = H * pos                         # base da última linha
        topo_bloco = fundo_bloco - n_l * alt_linha
        largura_bloco = max(sum(larg[j] for j in li) + espaco * (len(li) - 1) for li in linhas_idx)
        cx = W * float(st["pos_x"])
        cx = min(max(cx, largura_bloco / 2 + W * 0.03), W - largura_bloco / 2 - W * 0.03)
        topo_bloco = min(max(topo_bloco, H * 0.03), H * 0.97 - n_l * alt_linha)

        centros: dict[int, tuple[float, float]] = {}
        for li_k, li in enumerate(linhas_idx):
            yc = topo_bloco + (0 if modo == "palavra" else li_k) * alt_linha + alt_linha / 2
            lw = sum(larg[j] for j in li) + espaco * (len(li) - 1)
            x = cx - lw / 2
            for j in li:
                centros[j] = (x + larg[j] / 2, yc)
                x += larg[j] + espaco

        # ---- cores e contorno
        cor, dest, cont = _cor_ass(st["cor"]), _cor_ass(st["destaque"]), _cor_ass(st["contorno"])
        cchave, ctexto_caixa = _cor_ass(st["cor_chave"]), _cor_ass(st["texto_caixa"])
        fundo = st["fundo"]
        sombra = f"\\shad{max(1, borda * 0.6):.1f}\\4c&H000000&\\4a&H60&" if fundo == "sombra" else "\\shad0"
        blur = f"\\blur{max(2, borda * 0.9):.1f}" if fundo == "neon" else ""
        bord = max(borda, 3) if fundo == "neon" else borda
        comum = f"\\fn{st['fonte']}\\fs{fs}\\b0\\3c{cont}\\bord{bord}{sombra}{blur}"

        # ---- tempos de cada palavra (ativa de a até b)
        atv = []
        for j, w in enumerate(g):
            a = g0 if j == 0 else min(max(w["s"] + desl, g0), fim_grupo - 0.03)
            b = min(max(g[j + 1]["s"] + desl, g0), fim_grupo) if j + 1 < len(g) else fim_grupo
            atv.append((a, max(a + 0.03, b)))
        anim = st["animacao"]

        # ---- tarja atrás do bloco inteiro
        if fundo == "tarja":
            pad = fs * 0.28
            if modo == "palavra":
                for j in range(len(g)):
                    a, b = atv[j]
                    bw, bh = larg[j] + 2 * pad, alt_linha + pad * 0.6
                    x0, y0 = centros[j][0] - bw / 2, centros[j][1] - bh / 2
                    linhas.append(f"Dialogue: 0,{_t(a)},{_t(b)},Caixa,,0,0,0,,{{\\an7\\pos({x0:.1f},{y0:.1f})"
                                  f"\\1c{_cor_ass(st['cor_fundo'])}\\1a&H50&\\p1}}{_ret_arredondado(bw, bh, fs * 0.25)}{{\\p0}}")
            else:
                for li in linhas_idx:
                    lw = sum(larg[j] for j in li) + espaco * (len(li) - 1)
                    bw, bh = lw + 2 * pad, alt_linha + pad * 0.3
                    x0 = centros[li[0]][0] - larg[li[0]] / 2 - pad
                    y0 = centros[li[0]][1] - bh / 2
                    linhas.append(f"Dialogue: 0,{_t(g0)},{_t(fim_grupo)},Caixa,,0,0,0,,{{\\an7\\pos({x0:.1f},{y0:.1f})"
                                  f"\\1c{_cor_ass(st['cor_fundo'])}\\1a&H50&\\p1}}{_ret_arredondado(bw, bh, fs * 0.25)}{{\\p0}}")

        # ---- clássica: uma linha de texto por evento, sem destaque palavra a palavra
        if modo == "classica":
            for li in linhas_idx:
                partes = []
                for j in li:
                    t = textos[j]
                    partes.append(f"{{\\c{cchave}}}{t}{{\\c{cor}}}" if eh_chave[j] else t)
                lw = sum(larg[j] for j in li) + espaco * (len(li) - 1)
                x, y = cx, centros[li[0]][1]
                ent = _entrada(anim, x, y, fs, 0, (fim_grupo - g0), x - lw / 2 - bord, x + lw / 2 + bord, H)
                linhas.append(f"Dialogue: 1,{_t(g0)},{_t(fim_grupo)},Leg,,0,0,0,,{{\\an5{ent}{comum}\\c{cor}}}"
                              + " ".join(partes))
        else:
            for j, w in enumerate(g):
                a, b = atv[j]
                x, y = centros[j]
                base_c = cchave if eh_chave[j] else cor
                e_esc = int(round(100 * esc[j]))
                if modo == "palavra":
                    ini, fim = a, b
                elif anim in ("surgir", "maquina"):
                    ini, fim = a, fim_grupo
                else:
                    ini, fim = g0, fim_grupo
                ta, tb = ms(a - ini), ms(b - ini)
                tags = f"\\an5{comum}\\c{base_c}\\fscx{e_esc}\\fscy{e_esc}"
                tags += _entrada(anim, x, y, fs, 0 if modo != "palavra" else 0, fim - ini,
                                 x - larg[j] / 2 - bord, x + larg[j] / 2 + bord, H,
                                 primeira=(ini == g0 or modo == "palavra" or anim in ("surgir", "maquina")))
                if modo in ("karaoke", "caixa"):
                    if modo == "caixa":   # dentro da caixa: sem contorno nem sombra
                        tags += f"\\t({ta},{ta + 1},\\c{ctexto_caixa}\\3c{dest}\\bord0\\shad0\\blur0)"
                        if j + 1 < len(g):
                            sh = max(1, borda * 0.6) if fundo == "sombra" else 0
                            tags += f"\\t({tb},{tb + 1},\\c{base_c}\\3c{cont}\\bord{bord}\\shad{sh:.1f})"
                    else:
                        tags += f"\\t({ta},{ta + 1},\\c{dest})"
                        if j + 1 < len(g):
                            tags += f"\\t({tb},{tb + 1},\\c{base_c})"
                    if anim == "saltar":
                        p1, p2 = int(e_esc * 1.12), int(e_esc * 1.04)
                        tags += (f"\\t({ta},{ta + 80},\\fscx{p1}\\fscy{p1})\\t({ta + 80},{ta + 160},\\fscx{p2}\\fscy{p2})")
                        if j + 1 < len(g):
                            tags += f"\\t({tb},{tb + 60},\\fscx{e_esc}\\fscy{e_esc})"
                linhas.append(f"Dialogue: 2,{_t(ini)},{_t(fim)},Leg,,0,0,0,,{{{tags}}}{textos[j]}")

                # caixa colorida atrás da palavra falada
                if modo == "caixa":
                    pad = fs * 0.16
                    bw = larg[j] + 2 * pad
                    asc = met.asc * fs / met.altura
                    capp = met.cap * fs / met.altura * esc[j]
                    base_y = y - fs / 2 + asc
                    topo = base_y - capp - pad * 1.1
                    baixo = base_y + pad * (1.1 if maiusc else 2.4)
                    bh = baixo - topo
                    by = (topo + baixo) / 2
                    ptags = (f"\\an5\\pos({x:.1f},{by:.1f})\\1c{dest}\\bord0\\shad0\\fscx100\\fscy100")
                    if anim == "saltar":
                        ptags += "\\fscx90\\fscy90\\t(0,90,\\fscx106\\fscy106)\\t(90,160,\\fscx100\\fscy100)"
                    linhas.append(f"Dialogue: 1,{_t(a)},{_t(b)},Caixa,,0,0,0,,{{{ptags}\\p1}}"
                                  f"{_ret_arredondado(bw, bh, fs * 0.22)}{{\\p0}}")

        # ---- emoji do trecho (acima da legenda)
        if st["emojis"]:
            e = next((emo[w["i"]] for w in g if w.get("i") in emo), None)
            if e:
                tam = int(fs * 1.5)
                yt = topo_bloco - tam - fs * 0.15
                if yt < H * 0.02:
                    yt = topo_bloco + n_l * alt_linha + fs * 0.15
                saida_emojis.append({"emoji": e, "ini": round(g0, 3), "fim": round(fim_grupo, 3),
                                     "x": int(cx - tam / 2), "y": int(yt), "tam": tam})
    linhas += _gancho_ass(gancho, base, W, H, formato)
    linhas += textos_ass(textos_livres or [], base, W, H, formato)
    destino.write_text(cab + "\n".join(linhas) + "\n", encoding="utf-8")
    return saida_emojis


def textos_ass(itens: list[dict], base: dict, W: int, H: int, formato: str) -> list[str]:
    """Textos livres da trilha de texto: posição, fonte, cores, caixa e animação de entrada."""
    out = []
    for it in itens:
        texto = str(it.get("texto", "")).strip()
        if not texto:
            continue
        st = estilo_global({**base, "fonte": it.get("fonte") or base["fonte"], "tamanho": float(it.get("tamanho", 100)),
                            "modo": "karaoke", "espessura_contorno": float(it.get("contorno_esp", 80))})
        fs, _, borda = geometria(W, H, formato, st)
        met = metrica(st["fonte"])
        maiusc = bool(it.get("maiusculas", False))
        linhas_txt = []
        for par in texto.split("\n"):
            atual = ""
            for w in par.split():
                cand = (atual + " " + w).strip()
                if atual and met.largura(_limpar(cand, maiusc), fs) > W * 0.86:
                    linhas_txt.append(atual)
                    atual = w
                else:
                    atual = cand
            linhas_txt.append(atual)
        x, y = W * float(it.get("x", 0.5)), H * float(it.get("y", 0.3))
        alt = fs * 1.2
        ini, fim = float(it["ini"]), float(it["ini"]) + float(it["dur"])
        cor = _cor_ass(it.get("cor") or "#FFFFFF")
        cont = _cor_ass(it.get("cor_contorno") or "#000000")
        caixa = it.get("caixa") or ""
        ent = it.get("entrada", "pop")
        y0 = y - alt * len(linhas_txt) / 2
        for k, ln in enumerate(linhas_txt):
            ln = _limpar(ln, maiusc)
            if not ln:
                continue
            yc = y0 + alt * k + alt / 2
            anim = "\\fad(150,150)"
            if ent == "pop":
                anim = "\\fscx70\\fscy70\\t(0,160,\\fscx106\\fscy106)\\t(160,240,\\fscx100\\fscy100)\\fad(80,150)"
            pos = f"\\pos({x:.1f},{yc:.1f})"
            if ent == "deslizar":
                pos = f"\\move({x:.1f},{yc + fs * 0.8:.1f},{x:.1f},{yc:.1f},0,220)"
            if ent == "maquina":
                lw = met.largura(ln, fs)
                rev = int(min(900, max(200, len(ln) * 45)))
                anim = (f"\\clip({x - lw / 2 - borda:.0f},0,{x - lw / 2 - borda + 1:.0f},{H})"
                        f"\\t(0,{rev},\\clip({x - lw / 2 - borda:.0f},0,{x + lw / 2 + borda:.0f},{H}))\\fad(0,150)")
            if caixa:
                lw = met.largura(ln, fs)
                pad = fs * 0.3
                ret = _ret_arredondado(lw + 2 * pad, fs * 1.15, fs * 0.22)
                out.append(f"Dialogue: 5,{_t(ini)},{_t(fim)},Caixa,,0,0,0,,{{\\an5{pos}\\1c{_cor_ass(caixa)}"
                           f"\\bord0\\shad0{anim}\\p1}}{ret}{{\\p0}}")
            sombra = "\\shad2\\4a&H70&" if it.get("sombra", True) and not caixa else "\\shad0"
            out.append(f"Dialogue: 6,{_t(ini)},{_t(fim)},Leg,,0,0,0,,{{\\an5{pos}\\fn{st['fonte']}\\fs{fs}"
                       f"\\c{cor}\\3c{cont}\\bord{0 if caixa else borda}{sombra}{anim}}}{ln}")
    return out


def _gancho_ass(gancho: dict | None, base: dict, W: int, H: int, formato: str) -> list[str]:
    """Texto do gancho de abertura: grande, em caixa colorida, no alto da tela nos primeiros segundos."""
    if not gancho or not gancho.get("ativar") or not str(gancho.get("texto", "")).strip():
        return []
    st = estilo_global({**base, "tamanho": float(gancho.get("tamanho", 100)), "modo": "karaoke"})
    fs, _, _ = geometria(W, H, formato, st)
    fs = int(fs * 1.05)
    met = metrica(st["fonte"])
    texto = _limpar(str(gancho["texto"]).strip(), bool(gancho.get("maiusculas", True)))
    texto = texto.replace("\n", " ")
    dur = max(1.0, min(8.0, float(gancho.get("dur", 3.0))))
    # quebra em linhas que caibam em 84% da largura
    palavras, linhas_txt, atual = texto.split(), [], ""
    for w in palavras:
        cand = (atual + " " + w).strip()
        if atual and met.largura(cand, fs) > W * 0.84:
            linhas_txt.append(atual)
            atual = w
        else:
            atual = cand
    if atual:
        linhas_txt.append(atual)
    alt = fs * 1.32
    y0 = H * float(gancho.get("posicao", 0.2)) - alt * len(linhas_txt) / 2
    caixa = _cor_ass(gancho.get("cor_caixa") or st["destaque"])
    cor = _cor_ass(gancho.get("cor_texto") or "#000000")
    out = []
    for k, ln in enumerate(linhas_txt):
        lw = met.largura(ln, fs)
        yc = y0 + alt * k + alt / 2
        pad = fs * 0.3
        bw, bh = lw + 2 * pad, fs * 1.18
        atraso = k * 90
        pop = (f"\\fscx80\\fscy80\\alpha&HFF&\\t({atraso},{atraso + 140},\\fscx106\\fscy106\\alpha&H00&)"
               f"\\t({atraso + 140},{atraso + 220},\\fscx100\\fscy100)\\fad(0,200)")
        out.append(f"Dialogue: 3,{_t(0)},{_t(dur)},Caixa,,0,0,0,,{{\\an5\\pos({W / 2:.1f},{yc:.1f})\\1c{caixa}\\bord0\\shad0"
                   f"{pop}\\p1}}{_ret_arredondado(bw, bh, fs * 0.25)}{{\\p0}}")
        out.append(f"Dialogue: 4,{_t(0)},{_t(dur)},Leg,,0,0,0,,{{\\an5\\pos({W / 2:.1f},{yc + fs * 0.02:.1f})"
                   f"\\fn{st['fonte']}\\fs{fs}\\c{cor}\\bord0\\shad0{pop}}}{ln}")
    return out


def _entrada(anim: str, x: float, y: float, fs: float, _t0: int, dur: float,
             x0: float, x1: float, H: int, primeira: bool = True) -> str:
    """Tags de entrada de um evento. Devolve também a posição (\\pos ou \\move)."""
    if not primeira or anim in ("nenhuma", "saltar"):
        return f"\\pos({x:.1f},{y:.1f})" + ("\\fad(60,0)" if primeira and anim == "saltar" else "")
    if anim == "deslizar":
        d = fs * 0.55
        return f"\\move({x:.1f},{y + d:.1f},{x:.1f},{y:.1f},0,180)\\fad(150,0)"
    if anim == "surgir":
        return f"\\pos({x:.1f},{y:.1f})\\fad(90,0)\\fscx70\\fscy70\\t(0,150,\\fscx100\\fscy100)"
    if anim == "maquina":
        rev = int(min(450, max(120, dur * 1000 * 0.6)))
        return (f"\\pos({x:.1f},{y:.1f})\\clip({x0:.0f},0,{x0 + 1:.0f},{H})"
                f"\\t(0,{rev},\\clip({x0:.0f},0,{x1:.0f},{H}))")
    return f"\\pos({x:.1f},{y:.1f})"


def gerar_srt(pal: list[dict], destino: Path, deslocamento: float = 0.0) -> None:
    """SRT em frases (até ~42 caracteres por linha), útil para subir no YouTube.
    deslocamento: segundos de abertura antes da fala."""
    if deslocamento:
        pal = [dict(w, s=w["s"] + deslocamento, e=w["e"] + deslocamento) for w in pal]
    blocos, atual = [], []
    for w in pal:
        if atual and (sum(len(x["w"]) + 1 for x in atual) + len(w["w"]) > 42
                      or w["s"] - atual[-1]["e"] > 0.8):
            blocos.append(atual)
            atual = []
        atual.append(w)
        if re.search(r"[.!?…]$", w["w"]):
            blocos.append(atual)
            atual = []
    if atual:
        blocos.append(atual)

    def t(s):
        ms = int(round(s * 1000))
        h, ms = divmod(ms, 3600000)
        m, ms = divmod(ms, 60000)
        s_, ms = divmod(ms, 1000)
        return f"{h:02d}:{m:02d}:{s_:02d},{ms:03d}"

    out = []
    for k, b in enumerate(blocos, 1):
        fim = b[-1]["e"] + 0.2
        if k < len(blocos):
            fim = min(fim, blocos[k][0]["s"] - 0.001)
        out.append(f"{k}\n{t(b[0]['s'])} --> {t(fim)}\n{' '.join(x['w'] for x in b)}\n")
    destino.write_text("\n".join(out), encoding="utf-8")
