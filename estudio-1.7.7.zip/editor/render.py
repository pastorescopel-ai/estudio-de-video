"""Renderização em alta qualidade: cortes (+zoom), áudio e música, formatos finais com legenda e logo."""
from __future__ import annotations

import hashlib
import json
import random
import shutil
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from .edl import Mapa
from .framing import posicao_media
from .util import (RAIZ, args_video, aviso, barra, caminho_cfg, escolher_encoder, info,
                   rodar_ffmpeg, salvar_json)

FORMATOS = {
    #  nome        largura altura  rótulo                      qualidade
    "vertical":   (1080, 1920, "Reels-TikTok-Shorts 9x16", "final"),
    "horizontal": (1920, 1080, "YouTube 16x9", "final"),
    "quadrado":   (1080, 1080, "LinkedIn-Facebook 1x1", "final"),
    "whatsapp":   (720, 1280, "WhatsApp", "leve"),
}
EXT_MUSICA = (".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac")

# HDR (HLG/PQ do celular) -> SDR bt709 com mapeamento de tons: sem isso as cores saem "lavadas"
TONEMAP = ("zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,"
           "tonemap=tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,format=yuv420p")


def _par(x: float) -> int:
    return max(2, int(round(x / 2)) * 2)


def _chave(*partes) -> str:
    return hashlib.sha1(json.dumps(partes, sort_keys=True, default=str).encode()).hexdigest()[:16]


def dimensoes(nome: str, iv: dict, cfg: dict) -> tuple[int, int]:
    """Resolução de saída. Fonte 4K -> sai em 4K (exceto WhatsApp). Nunca abaixo de 1080p."""
    W, H = FORMATOS[nome][:2]
    res = str(cfg.get("qualidade", {}).get("resolucao", "auto")).lower()
    fonte_4k = min(iv["largura"], iv["altura"]) >= 2000
    if nome != "whatsapp" and (res == "4k" or (res == "auto" and fonte_4k)):
        W, H = W * 2, H * 2
    return W, H


def _override(cfg: dict, t0: float, t1: float) -> dict | None:
    meio = (t0 + t1) / 2
    for o in cfg.get("enquadramento", []) or []:
        if o["s"] <= meio <= o["e"]:
            return o
    return None


def _centro(rastro, cfg, t0, t1) -> tuple[float, float]:
    o = _override(cfg, t0, t1)
    cx, cy = posicao_media(rastro, t0, t1)
    if o:
        cx = o.get("cx", cx)
        cy = o.get("cy", cy)
    return cx, cy


# ============================================================ 1) cortes
def renderizar_cortes(video: Path, trechos: list[tuple[float, float]], iv: dict,
                      rastro: list, cfg: dict, trab: Path) -> tuple[Path, list[dict]]:
    """Gera master.mkv (sem perdas) só com os trechos mantidos. Reaproveita se nada mudou."""
    zcfg = cfg.get("zoom", {})
    chave = _chave("v3", [list(t) for t in trechos], zcfg, cfg.get("enquadramento"), len(rastro))
    master = trab / "master.mkv"
    arq_chave, arq_zoom = trab / "master.chave", trab / "zooms.json"
    if master.exists() and arq_chave.exists() and arq_chave.read_text() == chave and arq_zoom.exists():
        info("Cortes iguais aos da última geração — reaproveitando.")
        return master, json.loads(arq_zoom.read_text())

    enc = escolher_encoder(cfg)
    W, H, fps = _par(iv["largura"]), _par(iv["altura"]), iv["fps"]
    usar_zoom = bool(zcfg.get("ativar", True)) and len(trechos) > 1
    z = float(zcfg.get("fator", 1.10))
    pasta = trab / "segmentos"
    if pasta.exists():
        shutil.rmtree(pasta)
    pasta.mkdir(parents=True)

    zooms: list[dict] = []
    tarefas = []
    for k, (s, e) in enumerate(trechos):
        dur = e - s
        vf = [TONEMAP] if iv.get("hdr") else []
        zinfo = {"z": 1.0, "x0": 0.0, "y0": 0.0}
        if usar_zoom and k % 2 == 1:
            cx, cy = _centro(rastro, cfg, s, e)
            cw, ch = _par(W / z), _par(H / z)
            x0 = min(max(cx * W - cw / 2, 0), W - cw)
            y0 = min(max(cy * H - ch / 2 + ch * 0.06, 0), H - ch)  # rosto um pouco acima do centro
            vf.append(f"crop={cw}:{ch}:{int(x0)}:{int(y0)}")
            zinfo = {"z": W / cw, "x0": x0 / W, "y0": y0 / H}
        vf += [f"scale={W}:{H}:flags=lanczos", "setsar=1", f"fps={fps:.6f}", "format=yuv420p"]
        fade = min(0.012, dur / 4)
        af = (f"aresample=48000,afade=t=in:d={fade:.3f},"
              f"afade=t=out:st={max(0, dur - fade):.3f}:d={fade:.3f}")
        saida = pasta / f"seg_{k:05d}.mkv"
        args = ["-ss", f"{s:.4f}", "-i", str(video), "-t", f"{dur:.4f}",
                "-vf", ",".join(vf), "-af", af, "-ac", "2",
                *args_video(enc, "intermediario"), "-c:a", "pcm_s24le", str(saida)]
        tarefas.append(args)
        zooms.append(zinfo)

    paralelo = 3 if enc == "nvenc" else 2
    feitos = 0
    with ThreadPoolExecutor(paralelo) as ex:
        futuros = [ex.submit(rodar_ffmpeg, a) for a in tarefas]
        for f in as_completed(futuros):
            f.result()
            feitos += 1
            barra(feitos / len(tarefas), sufixo=f"trechos {feitos}/{len(tarefas)}")

    lista = trab / "segmentos.txt"
    lista.write_text("".join(f"file 'segmentos/seg_{k:05d}.mkv'\n" for k in range(len(trechos))),
                     encoding="utf-8")
    rodar_ffmpeg(["-f", "concat", "-safe", "0", "-i", lista.name, "-c", "copy", master.name], cwd=trab)
    shutil.rmtree(pasta, ignore_errors=True)
    salvar_json(arq_zoom, zooms)
    arq_chave.write_text(chave)
    (trab / "master_final.chave").unlink(missing_ok=True)
    return master, zooms


# ============================================================ 2) áudio
def listar_musicas() -> list[Path]:
    p = RAIZ / "musica"
    return sorted(f for f in p.iterdir() if f.suffix.lower() in EXT_MUSICA) if p.is_dir() else []


def escolher_musica(cfg: dict, semente: str = "") -> Path | None:
    """musica.arquivo: '' = sem música · nome de arquivo · pasta (sorteia, sempre a mesma por vídeo)."""
    mc = cfg.get("musica", {})
    if mc.get("ativar") is False:
        return None
    valor = mc.get("arquivo")
    p = caminho_cfg(valor)
    if p and not p.exists():
        p = RAIZ / "musica" / str(valor)
    if not p or not p.exists():
        return None
    if p.is_dir():
        opcoes = sorted(f for f in p.iterdir() if f.suffix.lower() in EXT_MUSICA)
        return random.Random(semente).choice(opcoes) if opcoes else None
    return p


def tratar_audio(master: Path, total: float, cfg: dict, trab: Path, semente: str = "") -> Path:
    acfg, mcfg = cfg.get("audio", {}), cfg.get("musica", {})
    musica = escolher_musica(cfg, semente)
    saida = trab / "master_final.mkv"
    chave = _chave((trab / "master.chave").read_text() if (trab / "master.chave").exists() else "",
                   acfg, mcfg, str(musica))
    arq_chave = trab / "master_final.chave"
    if saida.exists() and arq_chave.exists() and arq_chave.read_text() == chave:
        info("Áudio igual ao da última geração — reaproveitando.")
        return saida

    from . import voz as voz_mod
    voz = voz_mod.cadeia_limpeza(acfg)
    trechos_fx = [tuple(x) for x in (acfg.get("efeitos_trechos") or [])]
    lufs = float(acfg.get("loudness", -14))
    final = f"loudnorm=I={lufs}:TP=-1.5:LRA=11,aresample=48000"
    entradas = ["-i", master.name]
    if musica:
        info(f"Música: {musica.name}")
        entradas += ["-stream_loop", "-1", "-i", str(musica)]
        vol = float(mcfg.get("volume", 0.12))
        # janela da música no vídeo final (arrastada/aparada na linha do tempo)
        m_ini = min(max(0.0, float(mcfg.get("inicio") or 0)), max(0.0, total - 0.5))
        m_fim = float(mcfg.get("fim") or 0) or total
        m_fim = min(max(m_ini + 0.5, m_fim), total)
        desde = max(0.0, float(mcfg.get("desde") or 0))
        m_dur = m_fim - m_ini
        f_in, f_out = min(1.0, m_dur / 4), min(2.5, m_dur / 3)
        atraso = int(round(m_ini * 1000))
        grafo = (f"[0:a]{','.join(voz)}[vozl];"
                 + voz_mod.grafo_efeitos("vozl", "voz", acfg.get("efeito_voz", "normal"), trechos_fx) + ";"
                 f"[1:a]aresample=48000,aformat=channel_layouts=stereo,volume={vol},"
                 f"atrim=start={desde:.3f}:duration={m_dur:.3f},asetpts=PTS-STARTPTS,"
                 f"afade=t=in:d={f_in:.3f},afade=t=out:st={m_dur - f_out:.3f}:d={f_out:.3f},"
                 f"adelay={atraso}|{atraso},apad=whole_dur={total:.3f}[mus];")
        if mcfg.get("abaixar_quando_fala", True):
            grafo += ("[voz]asplit=2[v1][sc];"
                      "[mus][sc]sidechaincompress=threshold=0.02:ratio=8:attack=20:release=400[duck];"
                      "[v1][duck]amix=inputs=2:duration=first:normalize=0")
        else:
            grafo += "[voz][mus]amix=inputs=2:duration=first:normalize=0"
        grafo += f",{final}[aout]"
    else:
        grafo = (f"[0:a]{','.join(voz)}[vozl];"
                 + voz_mod.grafo_efeitos("vozl", "vozf", acfg.get("efeito_voz", "normal"), trechos_fx)
                 + f";[vozf]{final}[aout]")
    rodar_ffmpeg([*entradas, "-filter_complex", grafo, "-map", "0:v", "-map", "[aout]",
                  "-c:v", "copy", "-c:a", "flac", saida.name], duracao=total, rotulo="áudio", cwd=trab)
    arq_chave.write_text(chave)
    return saida


# ============================================================ 3) formatos finais
def _cameras(trechos, mapa: Mapa, rastro, zooms, cfg, eixo: str, src_px: int, janela_px: int):
    """Posições da 'câmera virtual' (recorte) ao longo do vídeo final.
    Só muda de posição nos cortes ou quando a pessoa se desloca bastante.
    Ajustes manuais feitos no editor têm prioridade."""
    pos: list[tuple[float, int]] = []
    atual = None
    for k, (s, e) in enumerate(trechos):
        zi = zooms[k] if k < len(zooms) else {"z": 1.0, "x0": 0.0, "y0": 0.0}
        manual = _override(cfg, s, e)
        passo = (e - s) if manual else 4.0
        t = s
        while t < e - 0.05:
            t2 = min(e, t + passo)
            cx, cy = _centro(rastro, cfg, t, t2)
            c = cx if eixo == "x" else cy
            off = zi["x0"] if eixo == "x" else zi["y0"]
            c = (c - off) * zi["z"]                       # posição dentro do quadro com zoom
            if eixo == "y" and not manual:
                c += 0.12                                 # deixa espaço acima da cabeça
            px = int(min(max(c * src_px - janela_px / 2, 0), src_px - janela_px))
            limiar = 0.0 if manual else (0.02 if t == s else 0.08)
            if atual is None or abs(px - atual) > limiar * src_px:
                pos.append((mapa.acum[k] + (t - s), px))
                atual = px
            t = t2
    return pos or [(0.0, (src_px - janela_px) // 2)]


def _escala(Wt: int, Ht: int, altura_origem: int) -> str:
    """Redimensiona com lanczos; se precisar ampliar, aplica uma nitidez leve para não ficar 'mole'."""
    f = f"scale={Wt}:{Ht}:flags=lanczos"
    if Ht / max(1, altura_origem) > 1.15:
        f += ",unsharp=5:5:0.45:5:5:0"
    return f + ",setsar=1"


def _filtro_enquadramento(iv, Wt, Ht, trechos, mapa, rastro, zooms, cfg, trab: Path, nome: str) -> str:
    W0, H0 = _par(iv["largura"]), _par(iv["altura"])
    ar0, art = W0 / H0, Wt / Ht
    if abs(ar0 - art) < 0.02:
        return f"[0:v]{_escala(Wt, Ht, H0)}"
    if art > ar0 and art > 1.2:  # vertical -> horizontal: fundo desfocado
        return (f"[0:v]split=2[bga][fga];"
                f"[bga]scale={Wt // 4}:{Ht // 4},boxblur=12:3,scale={Wt}:{Ht}:flags=bicubic,"
                f"eq=brightness=-0.07:saturation=1.1[bg];"
                f"[fga]scale=-2:{Ht}:flags=lanczos[fg];"
                f"[bg][fg]overlay=(W-w)/2:0,setsar=1")
    if art < ar0:   # recorta largura, segue o rosto na horizontal
        eixo, jan, src = "x", _par(H0 * art), W0
        crop = f"crop@cam={jan}:{H0}:{{p}}:0"
        alt = H0
    else:           # recorta altura, segue o rosto na vertical
        eixo, jan, src = "y", _par(W0 / art), H0
        crop = f"crop@cam={W0}:{jan}:0:{{p}}"
        alt = jan
    cams = _cameras(trechos, mapa, rastro, zooms, cfg, eixo, src, jan)
    base = crop.format(p=cams[0][1])
    sendcmd = ""
    if len(cams) > 1:
        cmd = trab / f"camera_{nome}.txt"
        cmd.write_text("".join(f"{t:.3f} crop@cam {eixo} {p};\n" for t, p in cams[1:]), encoding="utf-8")
        sendcmd = f"sendcmd=f={cmd.name},"
    return f"[0:v]{sendcmd}{base},{_escala(Wt, Ht, alt)}"


def _posicao_logo(pos: str, margem: int) -> str:
    m = margem
    return {
        "superior_esquerdo": f"{m}:{m}",
        "inferior_direito": f"W-w-{m}:H-h-{m}",
        "inferior_esquerdo": f"{m}:H-h-{m}",
    }.get(pos, f"W-w-{m}:{m}")


TRANSICAO = 0.5   # segundos de fusão entre abertura/vídeo/encerramento
FADE_BROLL = 0.25


def _cobrir(Wt: int, Ht: int) -> str:
    return f"scale={Wt}:{Ht}:force_original_aspect_ratio=increase:flags=lanczos,crop={Wt}:{Ht}"


def _filtro_broll(k: int, b: dict, Wt: int, Ht: int, fps: float) -> str:
    """Imagem de apoio: preenche a tela, cor harmonizada, entra e sai com fusão suave.
    Fotos ganham um movimento lento (efeito Ken Burns), alternando zoom e deslize."""
    d = b["dur"]
    if b["foto"]:
        Wz, Hz = _par(Wt * 1.12), _par(Ht * 1.12)
        if k % 2 == 0:   # desliza na horizontal
            mov = f"crop={Wt}:{Ht}:x='(iw-ow)*t/{d:.3f}':y='(ih-oh)/2'"
        else:            # aproxima devagar
            n = max(1, int(d * fps))
            mov = (f"zoompan=z='1+0.10*on/{n}':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
                   f"d=1:s={Wt}x{Ht}:fps={fps:.6f}")
        base = f"[{b['entrada']}:v]{_cobrir(Wz, Hz)},fps={fps:.6f},{mov}"
    else:
        base = f"[{b['entrada']}:v]fps={fps:.6f},{_cobrir(Wt, Ht)}"
    if b.get("cor"):
        base += "," + b["cor"]
    f = min(FADE_BROLL, d / 4)
    return (f"{base},setsar=1,format=yuva420p,fade=t=in:st=0:d={f:.3f}:alpha=1,"
            f"fade=t=out:st={d - f:.3f}:d={f:.3f}:alpha=1,setpts=PTS-STARTPTS+{b['ini']:.3f}/TB[b{k}]")


def _filtro_vinheta(rot: str, v: dict, entrada: int, Wt: int, Ht: int, fps: float, lufs: float) -> str:
    d = v["duracao"]
    vid = (f"[{entrada}:v]{_cobrir(Wt, Ht)},fps={fps:.6f},setsar=1,format=yuv420p,"
           f"trim=0:{d:.3f},setpts=PTS-STARTPTS,settb=AVTB[{rot}v];")
    if v.get("audio"):
        aud = (f"[{entrada}:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,"
               f"loudnorm=I={lufs}:TP=-1.5,aresample=48000,atrim=0:{d:.3f},apad=whole_dur={d:.3f}[{rot}a];")
    else:
        aud = f"anullsrc=r=48000:cl=stereo,atrim=0:{d:.3f},aformat=sample_fmts=fltp[{rot}a];"
    return vid + aud


def renderizar_formato(nome: str, master_final: Path, iv: dict, trechos, mapa: Mapa, rastro, zooms,
                       ass: Path, saida: Path, cfg: dict, trab: Path, brolls: list[dict] | None = None,
                       vinhetas: dict | None = None, emojis: list[dict] | None = None,
                       punch: list[tuple] | None = None, extras: list[dict] | None = None,
                       ajustes_video: dict | None = None, cortes_t: list[float] | None = None) -> Path:
    from . import trilhas
    av = ajustes_video or {}
    Wt, Ht = dimensoes(nome, iv, cfg)
    qual = FORMATOS[nome][3]
    fps = iv["fps"]
    entradas = ["-i", master_final.name]
    n_ent = 1
    grafo = _filtro_enquadramento(iv, Wt, Ht, trechos, mapa, rastro, zooms, cfg, trab, nome) + "[base];"
    atual = "base"
    cor = trilhas.filtro_cor(av)          # filtro de cor, nitidez, vinheta, espelhar
    if cor:
        grafo += f"[base]{cor}[basec];"
        atual = "basec"
    # ênfase: zoom rápido de 15% (corte seco para mais perto, como um "punch-in" de câmera)
    if punch:
        zw, zh = _par(Wt / 1.15), _par(Ht / 1.15)
        quando = "+".join(f"between(t,{a:.3f},{b:.3f})" for a, b in punch)
        grafo += (f"[{atual}]split[pa][pb];[pb]crop={zw}:{zh}:{(Wt - zw) // 2}:{int((Ht - zh) * 0.4)},"
                  f"scale={Wt}:{Ht}:flags=lanczos,setsar=1[pz];[pa][pz]overlay=0:0:enable='{quando}'[basez];")
        atual = "basez"
    # transição nos cortes: flash branco ou piscada preta bem curtos
    if av.get("transicao") in ("flash", "piscar") and cortes_t:
        cor_t = "white@0.55" if av["transicao"] == "flash" else "black@0.7"
        quando = "+".join(f"between(t,{c - 0.04:.3f},{c + 0.06:.3f})" for c in cortes_t[:400])
        grafo += f"[{atual}]drawbox=x=0:y=0:w=iw:h=ih:color={cor_t}:t=fill:enable='{quando}'[baset];"
        atual = "baset"

    # imagens de apoio por cima da fala (a legenda continua por cima delas)
    for k, b in enumerate(brolls or []):
        if b["foto"]:
            entradas += ["-loop", "1", "-framerate", f"{fps:.6f}", "-t", f"{b['dur']:.3f}", "-i", str(b["arquivo"])]
        else:
            entradas += ["-ss", f"{b['inicio']:.3f}", "-t", f"{b['dur']:.3f}", "-i", str(b["arquivo"])]
        b = dict(b, entrada=n_ent)
        n_ent += 1
        grafo += _filtro_broll(k, b, Wt, Ht, fps) + ";"
        grafo += (f"[{atual}][b{k}]overlay=eof_action=pass:enable='between(t,{b['ini']:.3f},"
                  f"{b['ini'] + b['dur']:.3f})'[o{k}];")
        atual = f"o{k}"

    if extras:
        e2, g2, atual, n_ent = trilhas.filtros_visuais(extras, Wt, Ht, fps, n_ent, atual)
        entradas += e2
        grafo += g2
    grafo += f"[{atual}]ass={ass.name}:fontsdir=fontes[sub];"
    # emojis da legenda (imagens PNG; um por emoji/tamanho, ligado só nos intervalos dele)
    from . import emojis as emo_mod
    juntos: dict[tuple, list[dict]] = {}
    for e in emojis or []:
        if emo_mod.arquivo(e["emoji"]):
            juntos.setdefault((e["emoji"], e["tam"]), []).append(e)
    rot = "sub"
    for k, ((e, tam), lista) in enumerate(juntos.items()):
        entradas += ["-loop", "1", "-framerate", f"{fps:.6f}", "-i", str(emo_mod.arquivo(e))]
        intervalo = lambda x: f"between(t,{x['ini']:.3f},{x['fim'] - 0.002:.3f})"  # noqa: E731
        quando = "+".join(intervalo(x) for x in lista)
        xs = "+".join(f"{intervalo(x)}*{x['x']}" for x in lista)
        ys = "+".join(f"{intervalo(x)}*{x['y']}" for x in lista)
        grafo += (f"[{n_ent}:v]scale={tam}:{tam}:flags=lanczos,format=rgba[em{k}];"
                  f"[{rot}][em{k}]overlay=x='{xs}':y='{ys}':eval=frame:shortest=1:enable='{quando}'[se{k}];")
        rot = f"se{k}"
        n_ent += 1
    grafo += f"[{rot}]null[v0];"
    lcfg = cfg.get("logo", {})
    logo = caminho_cfg(lcfg.get("arquivo"))
    if lcfg.get("ativar", True) and logo and logo.is_file():
        lw = _par(Wt * float(lcfg.get("largura", 0.14)))
        op = float(lcfg.get("opacidade", 0.85))
        entradas += ["-i", str(logo)]
        grafo += (f"[{n_ent}:v]scale={lw}:-1:flags=lanczos,format=rgba,colorchannelmixer=aa={op}[lg];"
                  f"[v0][lg]overlay={_posicao_logo(lcfg.get('posicao', ''), int(Wt * 0.04))}:format=auto,"
                  f"format=yuv420p[vprin]")
        n_ent += 1
    else:
        grafo += "[v0]format=yuv420p[vprin]"

    # sons das trilhas de áudio misturados à fala; velocidade do vídeo
    vlab, aud = "vprin", "0:a"
    if extras:
        e3, g3, aud, n_ent = trilhas.filtros_audio(extras, n_ent, "0:a")
        entradas += e3
        if g3:
            grafo += ";" + g3.rstrip(";")
    vel = max(0.5, min(2.0, float(av.get("velocidade", 1) or 1)))
    total = mapa.total
    if abs(vel - 1) > 0.01:
        grafo += f";[vprin]setpts=PTS/{vel:.4f}[vpv];[{aud}]atempo={vel:.4f}[apv]"
        vlab, aud = "vpv", "apv"
        total = mapa.total / vel

    # abertura e encerramento com fusão suave de imagem e som
    vin = {k: v for k, v in (vinhetas or {}).items() if v}
    if vin:
        lufs = float(cfg.get("audio", {}).get("loudness", -14))
        grafo += f";[{vlab}]fps={fps:.6f},settb=AVTB[mv];[{aud}]aformat=sample_fmts=fltp:channel_layouts=stereo[ma];"
        partes_v, partes_a = [], []
        for rot in ("abertura", "encerramento"):
            v = vin.get(rot)
            if not v:
                continue
            if v["foto"]:
                entradas += ["-loop", "1", "-framerate", f"{fps:.6f}", "-t", f"{v['duracao']:.3f}", "-i", str(v["arquivo"])]
            else:
                entradas += ["-i", str(v["arquivo"])]
            grafo += _filtro_vinheta(rot, v, n_ent, Wt, Ht, fps, lufs)
            n_ent += 1
        seq = ([("abertura", vin["abertura"]["duracao"])] if "abertura" in vin else []) + [("m", total)] + \
              ([("encerramento", vin["encerramento"]["duracao"])] if "encerramento" in vin else [])
        rv = {"m": "mv"}
        ra = {"m": "ma"}
        cv, ca, acum = (rv.get(seq[0][0], seq[0][0] + "v"), ra.get(seq[0][0], seq[0][0] + "a"), seq[0][1])
        for j, (rot, d) in enumerate(seq[1:], 1):
            nv, na = rv.get(rot, rot + "v"), ra.get(rot, rot + "a")
            off = acum - TRANSICAO
            grafo += (f"[{cv}][{nv}]xfade=transition=fade:duration={TRANSICAO}:offset={off:.3f}[xv{j}];"
                      f"[{ca}][{na}]acrossfade=d={TRANSICAO}[xa{j}];")
            cv, ca, acum = f"xv{j}", f"xa{j}", acum + d - TRANSICAO
        grafo += f"[{cv}]format=yuv420p[vout];[{ca}]anull[aout]"
        total = acum
        mapa_audio = "[aout]"
    else:
        grafo += f";[{vlab}]null[vout]"
        mapa_audio = "0:a" if aud == "0:a" else f"[{aud}]"

    abr = "128k" if qual == "leve" else "320k"
    tmp = saida.with_name(saida.stem + ".parcial.mp4")
    (trab / f"grafo_{nome}.txt").write_text(grafo, encoding="utf-8")

    def rodar(enc):
        rodar_ffmpeg([*entradas, "-filter_complex", grafo, "-map", "[vout]", "-map", mapa_audio,
                      *args_video(enc, qual, max(Wt, Ht) if qual != "leve" else Ht, fps),
                      "-c:a", "aac", "-b:a", abr, "-ar", "48000",
                      "-movflags", "+faststart", str(tmp)],
                     duracao=total, rotulo=nome, cwd=trab)

    enc = escolher_encoder(cfg)
    try:
        rodar(enc)
    except RuntimeError as e:
        if enc == "cpu":
            raise
        aviso(f"A placa de vídeo recusou algum ajuste ({str(e).splitlines()[1][:80]}…). Refazendo no processador.")
        rodar("cpu")
    saida.parent.mkdir(parents=True, exist_ok=True)
    tmp.replace(saida)
    return saida


# ============================================================ fontes
def _familia_da_fonte(arq: Path) -> str | None:
    """Lê o nome de família (nameID 1) da tabela 'name' de um .ttf/.otf."""
    import struct
    try:
        d = arq.read_bytes()
        n = struct.unpack(">H", d[4:6])[0]
        for k in range(n):
            tag, _, off, _ = struct.unpack(">4sIII", d[12 + 16 * k: 28 + 16 * k])
            if tag != b"name":
                continue
            _, cont, base = struct.unpack(">HHH", d[off: off + 6])
            achados = {}
            for j in range(cont):
                plat, _, lang, nid, tam, o = struct.unpack(">HHHHHH", d[off + 6 + 12 * j: off + 18 + 12 * j])
                if nid == 1 and plat == 3:
                    bruto = d[off + base + o: off + base + o + tam]
                    achados[lang] = bruto.decode("utf-16-be", "ignore")
            return achados.get(0x409) or next(iter(achados.values()), None)
    except Exception:  # noqa: BLE001
        return None
    return None


def arquivos_de_fonte() -> list[Path]:
    origem = RAIZ / "fontes"
    if not origem.exists():
        return []
    return sorted(list(origem.glob("*.ttf")) + list(origem.glob("*.otf")))


def preparar_fontes(trab: Path, cfg: dict) -> tuple[str, bool]:
    """Copia as fontes para a pasta de trabalho e decide o nome da fonte da legenda."""
    dest = trab / "fontes"
    dest.mkdir(parents=True, exist_ok=True)
    arquivos = arquivos_de_fonte()
    for f in arquivos:
        shutil.copy2(f, dest / f.name)
    fonte = cfg.get("legenda", {}).get("fonte", "Montserrat ExtraBold")
    primeira_palavra = fonte.split()[0].lower()
    candidatos = [f for f in arquivos if primeira_palavra in f.name.lower()
                  or primeira_palavra in (_familia_da_fonte(f) or "").lower()]
    if not candidatos:
        aviso(f"Fonte '{fonte}' não está em fontes/ — usando Arial Black.")
        fonte = "Arial Black"
    else:  # usa o nome de família gravado dentro do arquivo (é o que o renderizador procura)
        exato = [f for f in candidatos if (_familia_da_fonte(f) or "").lower() == fonte.lower()]
        fonte = _familia_da_fonte((exato or candidatos)[0]) or fonte
    negrito_sintetico = not any(x in fonte.lower() for x in ("bold", "black", "heavy"))
    return fonte, negrito_sintetico
