"""Ganchos e sugestões de imagem.

- Gancho de abertura: frases curtas para aparecer na tela nos primeiros segundos.
- Momentos de ênfase: trechos fortes da fala (ganham zoom rápido, legenda maior e emoji).
- Imagens sugeridas: onde caberia uma imagem ou vídeo de apoio, o que mostrar e palavras para buscar.
- Busca de imagens/vídeos gratuitos: Openverse (fotos) e Wikimedia Commons (vídeos), sem cadastro;
  com chave grátis em .env: Pixabay (PIXABAY_API_KEY) e Pexels (PEXELS_API_KEY)."""
from __future__ import annotations

import json
import os
import re
import unicodedata
import urllib.parse
import urllib.request
from pathlib import Path

from . import emojis, ia
from .util import aviso

AGENTE = "EstudioDeVideo/1.4 (editor de video local)"
OPENVERSE = os.environ.get("EDITOR_OPENVERSE_URL", "https://api.openverse.org")
PEXELS = os.environ.get("EDITOR_PEXELS_URL", "https://api.pexels.com")
PIXABAY = os.environ.get("EDITOR_PIXABAY_URL", "https://pixabay.com")
WIKIMEDIA = os.environ.get("EDITOR_WIKIMEDIA_URL", "https://commons.wikimedia.org")


def _sem_acento(t: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", t.lower()) if unicodedata.category(c) != "Mn")


# ============================================================ sugestões (IA ou regras)
PROMPT = """Você é editor de vídeos curtos (Reels/TikTok/Shorts) em português e especialista em retenção.
Título: {titulo}
Tema: {tema}
Fala do vídeo, palavra a palavra, no formato i:palavra (i é o número da palavra; t= tempo em segundos):
{texto}

Responda só com JSON neste formato:
{{
 "abertura": ["5 frases de GANCHO para aparecer escritas na tela nos 3 primeiros segundos: curtas (até 7 palavras), fiéis ao conteúdo, que despertem curiosidade; sem emojis"],
 "momentos": [{{"de": i, "ate": i, "motivo": "por que é forte", "emoji": "um emoji da lista ou vazio"}}],
 "imagens": [{{"palavra": i, "duracao": segundos (2 a 5), "tipo": "imagem" ou "video",
              "descricao": "o que mostrar, em português, bem concreto",
              "busca": "2 a 4 palavras EM INGLÊS para buscar em banco de imagens"}}]
}}
Regras: 2 a 5 "momentos" (frases de impacto, números, revelações, perguntas, viradas; de/ate cobrindo 2 a 12 palavras).
3 a 6 "imagens", espalhadas pelo vídeo, nunca nos 2 primeiros segundos, só onde uma imagem ajuda a entender
(objetos, lugares, ações, dados concretos). Emojis permitidos: {lista}"""


def sugerir(falas: list[dict], titulo: str, tema: str, cfg: dict) -> dict:
    """falas: [{i, w, t}] (só o que fica no vídeo). Devolve abertura, momentos e imagens."""
    if not falas:
        return {"abertura": [], "momentos": [], "imagens": [], "fonte": "regras"}
    validos = {f["i"] for f in falas}
    if ia.provedor(cfg) is not None:
        try:
            texto = " ".join(f"{f['i']}:{f['w']}" + (f"(t={f['t']:.0f})" if k % 15 == 0 else "")
                             for k, f in enumerate(falas[:1500]))
            d = ia.perguntar_json(cfg, PROMPT.format(titulo=titulo or "-", tema=tema or "-", texto=texto,
                                                     lista=" ".join(emojis.disponiveis())), max_tokens=2500)
            ab = [re.sub(r"\s+", " ", str(x)).strip().strip('"')[:70] for x in d.get("abertura", []) if str(x).strip()][:6]
            mom = []
            for m in d.get("momentos", []):
                try:
                    de, ate = int(m["de"]), int(m["ate"])
                except (KeyError, TypeError, ValueError):
                    continue
                if de in validos and ate in validos and 0 <= ate - de <= 25:
                    e = str(m.get("emoji") or "").strip()
                    mom.append({"de": de, "ate": ate, "motivo": str(m.get("motivo", ""))[:120],
                                "emoji": e if e in emojis.LISTA and emojis.arquivo(e) else ""})
            ims = []
            for m in d.get("imagens", []):
                try:
                    p = int(m["palavra"])
                except (KeyError, TypeError, ValueError):
                    continue
                if p in validos:
                    ims.append({"palavra": p, "dur": max(2.0, min(6.0, float(m.get("duracao") or 3.5))),
                                "tipo": "video" if str(m.get("tipo", "")).startswith("v") else "imagem",
                                "descricao": str(m.get("descricao", ""))[:140],
                                "busca": str(m.get("busca", ""))[:60]})
            if ab or mom or ims:
                return {"abertura": ab or _aberturas_regras(falas, titulo, tema), "momentos": mom[:6],
                        "imagens": ims[:8], "fonte": "ia"}
        except Exception as e:  # noqa: BLE001
            aviso(f"IA não sugeriu ganchos ({str(e)[:120]}); usando regras simples.")
    return {"abertura": _aberturas_regras(falas, titulo, tema), "momentos": _momentos_regras(falas),
            "imagens": _imagens_regras(falas), "fonte": "regras"}


def _frases(falas: list[dict]) -> list[list[dict]]:
    out, atual = [], []
    for k, f in enumerate(falas):
        if atual and (f["t"] - falas[k - 1]["t"] > 0.9 or len(atual) >= 14):
            out.append(atual)
            atual = []
        atual.append(f)
        if re.search(r"[.!?…]$", f["w"]):
            out.append(atual)
            atual = []
    if atual:
        out.append(atual)
    return out


FORTES = ("segredo", "erro", "nunca", "ninguem", "verdade", "pare", "cuidado", "atencao", "importante", "dinheiro",
          "simples", "facil", "rapido", "gratis", "melhor", "pior", "voce sabia", "descobri", "mudou", "mudar")


def _nota(fr: list[dict]) -> float:
    t = _sem_acento(" ".join(f["w"] for f in fr))
    n = sum(3 for x in FORTES if x in t) + (4 if re.search(r"\d", t) else 0) + (3 if "?" in t else 0)
    return n + min(len(fr), 10) * 0.2


def _momentos_regras(falas):
    fr = sorted(_frases(falas), key=_nota, reverse=True)[:3]
    out = []
    for f in sorted(fr, key=lambda x: x[0]["t"]):
        if _nota(f) < 3:
            continue
        e = emojis.sugerir_para(" ".join(x["w"] for x in f)) or ""
        out.append({"de": f[0]["i"], "ate": f[-1]["i"], "motivo": "frase forte", "emoji": e if emojis.arquivo(e) else ""})
    return out


def _aberturas_regras(falas, titulo, tema):
    base = titulo or " ".join(f["w"] for f in falas[:7])
    t = (tema or "isso").lower()
    melhor = max(_frases(falas), key=_nota, default=[])
    frase = " ".join(x["w"] for x in melhor[:7]).strip(" ,.")
    return [x for x in [base, f"Ninguém te conta isso sobre {t}", f"Pare de errar em {t}",
                        frase.capitalize() if frase else "", f"Você precisa saber disso"] if x][:5]


def _imagens_regras(falas):
    """Sem IA: substantivos 'concretos' que costumam render imagem."""
    out, ultimo = [], -99.0
    for f in falas:
        if f["t"] < 2 or f["t"] - ultimo < 6:
            continue
        e = emojis.sugerir_para(f["w"])
        if e:
            out.append({"palavra": f["i"], "dur": 3.5, "tipo": "imagem",
                        "descricao": f"Algo que mostre “{f['w']}”", "busca": ""})
            ultimo = f["t"]
        if len(out) >= 5:
            break
    return out


# ============================================================ busca de imagens e vídeos gratuitos
def _get(url: str, headers: dict | None = None, tempo: int = 20) -> dict:
    req = urllib.request.Request(url, headers={"User-Agent": AGENTE, **(headers or {})})
    with urllib.request.urlopen(req, timeout=tempo) as r:
        return json.load(r)


def traduzir_busca(texto: str, cfg: dict) -> str:
    """Bancos de imagens funcionam melhor em inglês: pede à IA (se houver) para traduzir."""
    if not texto or re.fullmatch(r"[a-zA-Z0-9 \-]+", texto) or ia.provedor(cfg) is None:
        return texto
    try:
        d = ia.perguntar_json(cfg, f'Traduza para 2 a 4 palavras-chave em inglês, para busca em banco de imagens: "{texto}". '
                                   'Responda só JSON: {"busca": "..."}', max_tokens=60)
        return str(d.get("busca") or texto)[:60]
    except Exception:  # noqa: BLE001
        return texto


def _pixabay(consulta: str, tipo: str, chave: str) -> list[dict]:
    if tipo == "video":
        d = _get(f"{PIXABAY}/api/videos/?" + urllib.parse.urlencode({"key": chave, "q": consulta, "per_page": 20, "safesearch": "true"}))
        out = []
        for h in d.get("hits", []):
            vs = h.get("videos", {})
            v = next((vs[k] for k in ("medium", "large", "small") if vs.get(k, {}).get("url")), None)
            if v:
                out.append({"thumb": v.get("thumbnail") or vs.get("tiny", {}).get("thumbnail"), "url": v["url"],
                            "w": v.get("width"), "h": v.get("height"), "tipo": "video", "duracao": h.get("duration"),
                            "credito": f"Vídeo de {h.get('user', '?')} no Pixabay", "licenca": "Licença Pixabay (uso livre)",
                            "pagina": h.get("pageURL"), "fonte": "Pixabay"})
        return out
    d = _get(f"{PIXABAY}/api/?" + urllib.parse.urlencode({"key": chave, "q": consulta, "per_page": 24,
                                                           "image_type": "photo", "safesearch": "true"}))
    return [{"thumb": h.get("webformatURL") or h.get("previewURL"), "url": h.get("largeImageURL") or h.get("webformatURL"),
             "w": h.get("imageWidth"), "h": h.get("imageHeight"), "tipo": "imagem",
             "credito": f"Imagem de {h.get('user', '?')} no Pixabay", "licenca": "Licença Pixabay (uso livre)",
             "pagina": h.get("pageURL"), "fonte": "Pixabay"} for h in d.get("hits", []) if h.get("webformatURL")]


def _wikimedia_videos(consulta: str) -> list[dict]:
    """Vídeos com licença livre do Wikimedia Commons (sem cadastro)."""
    d = _get(f"{WIKIMEDIA}/w/api.php?" + urllib.parse.urlencode({
        "action": "query", "format": "json", "generator": "search", "gsrnamespace": 6, "gsrlimit": 20,
        "gsrsearch": f"filetype:video {consulta}", "prop": "imageinfo", "iiprop": "url|size|extmetadata",
        "iiurlwidth": 320}))
    out = []
    for p in (d.get("query", {}).get("pages", {}) or {}).values():
        ii = (p.get("imageinfo") or [{}])[0]
        if not ii.get("url"):
            continue
        meta = ii.get("extmetadata", {})
        lic = re.sub("<[^>]+>", "", meta.get("LicenseShortName", {}).get("value", "")) or "Licença livre"
        autor = re.sub("<[^>]+>", "", meta.get("Artist", {}).get("value", "")).strip()[:80] or "?"
        out.append({"thumb": ii.get("thumburl"), "url": ii["url"], "w": ii.get("width"), "h": ii.get("height"),
                    "tipo": "video", "duracao": round(float(ii.get("duration", 0) or 0), 1),
                    "credito": f"{p.get('title', '').replace('File:', '')} — {autor} (Wikimedia Commons)",
                    "licenca": lic, "pagina": ii.get("descriptionurl"), "fonte": "Wikimedia Commons"})
    return out


def _openverse_imagens(consulta: str) -> list[dict]:
    d = _get(f"{OPENVERSE}/v1/images/?" + urllib.parse.urlencode(
        {"q": consulta, "license_type": "commercial,modification", "page_size": 20, "mature": "false"}))
    out = []
    for r in d.get("results", []):
        if not r.get("url"):
            continue
        lic = f"CC {str(r.get('license', '')).upper()} {r.get('license_version', '')}".strip()
        if str(r.get("license", "")).lower() in ("cc0", "pdm"):
            lic = "Domínio público"
        out.append({"thumb": r.get("thumbnail") or r.get("url"), "url": r["url"], "w": r.get("width"),
                    "h": r.get("height"), "tipo": "imagem",
                    "credito": (r.get("attribution") or f"{r.get('title', '')} por {r.get('creator', '?')}")[:300],
                    "licenca": lic, "pagina": r.get("foreign_landing_url"), "fonte": "Openverse"})
    return out


def buscar(consulta: str, tipo: str, cfg: dict) -> dict:
    """Imagens e vídeos grátis. Sem cadastro: Openverse (fotos) e Wikimedia Commons (vídeos).
    Com chave grátis em .env: Pixabay (PIXABAY_API_KEY) e Pexels (PEXELS_API_KEY), que têm mais vídeos."""
    from .util import carregar_env
    carregar_env()
    consulta = traduzir_busca(consulta.strip(), cfg)
    itens, avisos = [], []
    fontes = []
    if os.environ.get("PIXABAY_API_KEY", "").strip():
        fontes.append(("Pixabay", lambda: _pixabay(consulta, tipo, os.environ["PIXABAY_API_KEY"].strip())))
    if os.environ.get("PEXELS_API_KEY", "").strip():
        fontes.append(("Pexels", lambda: _pexels(consulta, tipo, os.environ["PEXELS_API_KEY"].strip())))
    if tipo == "video":
        fontes.append(("Wikimedia Commons", lambda: _wikimedia_videos(consulta)))
    else:
        fontes.append(("Openverse", lambda: _openverse_imagens(consulta)))
    for nome, f in fontes:
        try:
            itens += f()
        except Exception as e:  # noqa: BLE001
            avisos.append(f"{nome} não respondeu ({str(e)[:80]})")
    if tipo == "video" and not os.environ.get("PIXABAY_API_KEY", "").strip():
        avisos.append("Dica: para muito mais vídeos, crie uma conta grátis em pixabay.com, copie sua chave em "
                      "pixabay.com/api/docs e coloque PIXABAY_API_KEY=sua_chave no arquivo .env.")
    return {"itens": itens[:30], "avisos": avisos, "consulta": consulta}


def _pexels(consulta: str, tipo: str, chave: str) -> list[dict]:
    out = []
    if tipo == "video":
        d = _get(f"{PEXELS}/videos/search?" + urllib.parse.urlencode({"query": consulta, "per_page": 15}),
                 {"Authorization": chave})
        for v in d.get("videos", []):
            arqs = sorted([f for f in v.get("video_files", []) if f.get("link") and (f.get("height") or 0) <= 1920],
                          key=lambda f: (f.get("height") or 0), reverse=True)
            if arqs:
                out.append({"thumb": v.get("image"), "url": arqs[0]["link"], "w": arqs[0].get("width"),
                            "h": arqs[0].get("height"), "tipo": "video", "duracao": v.get("duration"),
                            "credito": f"Vídeo de {v.get('user', {}).get('name', '?')} no Pexels",
                            "licenca": "Licença Pexels (uso livre)", "pagina": v.get("url"), "fonte": "Pexels"})
        return out
    d = _get(f"{PEXELS}/v1/search?" + urllib.parse.urlencode({"query": consulta, "per_page": 20}),
             {"Authorization": chave})
    for p in d.get("photos", []):
        src = p.get("src", {})
        out.append({"thumb": src.get("medium"), "url": src.get("large2x") or src.get("original"),
                    "w": p.get("width"), "h": p.get("height"), "tipo": "imagem",
                    "credito": f"Foto de {p.get('photographer', '?')} no Pexels",
                    "licenca": "Licença Pexels (uso livre)", "pagina": p.get("url"), "fonte": "Pexels"})
    return out


def baixar(url: str, pasta: Path, nome_base: str) -> Path:
    """Baixa a imagem/vídeo escolhido para a pasta de mídias do projeto."""
    if not url.startswith(("https://", "http://")):
        raise RuntimeError("endereço inválido")
    req = urllib.request.Request(url, headers={"User-Agent": AGENTE})
    with urllib.request.urlopen(req, timeout=60) as r:
        tipo = (r.headers.get("Content-Type") or "").lower()
        ext = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp", "video/mp4": ".mp4",
               "video/quicktime": ".mov", "video/webm": ".webm", "video/ogg": ".ogv"}.get(tipo.split(";")[0].strip())
        if not ext:
            ext = Path(urllib.parse.urlparse(url).path).suffix.lower()
            if ext not in (".jpg", ".jpeg", ".png", ".webp", ".mp4", ".mov", ".gif", ".webm", ".ogv"):
                raise RuntimeError(f"tipo de arquivo não suportado ({tipo or ext or '?'})")
        nome = re.sub(r"[^\w\- ]", "", nome_base)[:40].strip() or "sugestao"
        destino = pasta / f"{nome}{ext}"
        k = 2
        while destino.exists():
            destino = pasta / f"{nome} ({k}){ext}"
            k += 1
        pasta.mkdir(parents=True, exist_ok=True)
        lido = 0
        with open(destino, "wb") as f:
            while True:
                b = r.read(1 << 20)
                if not b:
                    break
                lido += len(b)
                if lido > 400 * 1024 * 1024:
                    raise RuntimeError("arquivo grande demais")
                f.write(b)
    if destino.suffix in (".webm", ".ogv"):   # vídeos do Wikimedia: converte para mp4 (prévia no navegador e exportação)
        from .util import rodar_ffmpeg
        novo = destino.with_suffix(".mp4")
        rodar_ffmpeg(["-i", str(destino), "-t", "60", "-vf", "scale='min(1920,iw)':-2", "-c:v", "libx264", "-preset", "veryfast",
                      "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", str(novo)])
        destino.unlink(missing_ok=True)
        destino = novo
    if destino.suffix == ".webp" or destino.suffix == ".gif":   # converte para jpg/mp4 (o FFmpeg lê, mas fica mais simples)
        from .util import rodar_ffmpeg
        novo = destino.with_suffix(".jpg" if destino.suffix == ".webp" else ".mp4")
        rodar_ffmpeg(["-i", str(destino), *(["-frames:v", "1"] if novo.suffix == ".jpg" else
                                            ["-pix_fmt", "yuv420p", "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2"]), str(novo)])
        destino.unlink(missing_ok=True)
        destino = novo
    return destino
