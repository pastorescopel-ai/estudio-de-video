"""Foto de cada personagem: pega momentos em que ele fala, acha os rostos no quadro e escolhe
o rosto que mais mexe a boca (quem está falando). Sem rosto detectável (ex.: boneco), usa o quadro."""
from __future__ import annotations

import subprocess
from pathlib import Path

import numpy as np


def _quadro(video: Path, t: float, largura: int = 640):
    import cv2
    r = subprocess.run(["ffmpeg", "-v", "error", "-nostdin", "-ss", f"{max(0.0, t):.3f}", "-i", str(video),
                        "-frames:v", "1", "-vf", f"scale={largura}:-2", "-f", "image2pipe", "-vcodec", "png", "-"],
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if not r.stdout:
        return None
    return cv2.imdecode(np.frombuffer(r.stdout, np.uint8), cv2.IMREAD_COLOR)


def _rostos(img, det):
    import cv2
    cinza = cv2.equalizeHist(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))
    achados = []
    for d in det:
        for (x, y, w, h) in d.detectMultiScale(cinza, scaleFactor=1.1, minNeighbors=5, minSize=(40, 40)):
            if not any(abs(x - a) < w * 0.5 and abs(y - b) < h * 0.5 for a, b, _, _ in achados):
                achados.append((int(x), int(y), int(w), int(h)))
    return achados


def _recorte(img, caixa, lado: int = 256):
    import cv2
    H, W = img.shape[:2]
    if caixa is None:   # sem rosto: centro do quadro
        s = min(W, H)
        x0, y0 = (W - s) // 2, max(0, (H - s) // 3)
        return cv2.resize(img[y0:y0 + s, x0:x0 + s], (lado, lado), interpolation=cv2.INTER_AREA)
    x, y, w, h = caixa
    m = int(max(w, h) * 0.55)
    cx, cy = x + w // 2, y + h // 2
    s = min(max(w, h) + 2 * m, W, H)
    x0 = min(max(0, cx - s // 2), W - s)
    y0 = min(max(0, cy - s // 2), H - s)
    return cv2.resize(img[y0:y0 + s, x0:x0 + s], (lado, lado), interpolation=cv2.INTER_AREA)


def fotos(video: Path, palavras: list[dict], falas: list, n: int, pasta: Path) -> dict:
    """Salva personagem_<k>.jpg em `pasta` e devolve {k: {"rosto": bool, "t": tempo usado}}."""
    import cv2
    det = []
    try:
        det = [cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml"),
               cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_profileface.xml")]
    except Exception:  # noqa: BLE001
        det = []
    out: dict = {}
    for p in range(n):
        # trechos em que esse personagem fala, do mais longo para o mais curto
        trechos, atual = [], []
        for i, w in enumerate(palavras):
            if i < len(falas) and falas[i] == p:
                if atual and w["s"] - palavras[atual[-1]]["e"] > 0.4:
                    trechos.append(atual)
                    atual = []
                atual.append(i)
            elif atual:
                trechos.append(atual)
                atual = []
        if atual:
            trechos.append(atual)
        trechos.sort(key=lambda t: palavras[t[-1]]["e"] - palavras[t[0]]["s"], reverse=True)
        melhor, melhor_mov, melhor_img, t_usado = None, -1.0, None, None
        for t in trechos[:3]:
            meio = (palavras[t[0]]["s"] + palavras[t[-1]]["e"]) / 2
            a, b = _quadro(video, meio), _quadro(video, meio + 0.22)
            if a is None:
                continue
            if melhor_img is None:
                melhor_img, t_usado = a, meio
            for caixa in (_rostos(a, det) if det else []):
                x, y, w, h = caixa
                mov = 0.0
                if b is not None and b.shape == a.shape:
                    boca_a = a[y + h * 6 // 10: y + h, x + w // 5: x + w * 4 // 5].astype(np.float32)
                    boca_b = b[y + h * 6 // 10: y + h, x + w // 5: x + w * 4 // 5].astype(np.float32)
                    mov = float(np.abs(boca_a - boca_b).mean()) if boca_a.size else 0.0
                mov += w * 0.01   # empate: rosto maior
                if mov > melhor_mov:
                    melhor, melhor_mov, melhor_img, t_usado = caixa, mov, a, meio
        if melhor_img is None:
            continue
        cv2.imwrite(str(pasta / f"personagem_{p}.jpg"), _recorte(melhor_img, melhor), [cv2.IMWRITE_JPEG_QUALITY, 88])
        out[p] = {"rosto": melhor is not None, "t": round(t_usado or 0, 2)}
    return out
