"""Vídeos e fotos extras: imagens de apoio (B-roll), outras partes da fala, abertura/encerramento.
Tudo é 'harmonizado' com o vídeo principal: mesma resolução, fluidez, cor, brilho e volume."""
from __future__ import annotations

import base64
import json
import os
import re
import subprocess
from pathlib import Path

import numpy as np

from .util import RAIZ, args_video, aviso, escolher_encoder, info, rodar_ffmpeg, sondar

EXT_FOTO = {".jpg", ".jpeg", ".png", ".webp", ".heic", ".bmp"}
EXT_VIDEO = {".mp4", ".mov", ".mkv", ".avi", ".m4v", ".webm", ".mts", ".3gp"}
PASTA_VINHETAS = RAIZ / "vinhetas"
DUR_FOTO = 4.0
DUR_VINHETA_FOTO = 3.0


def eh_foto(p: Path) -> bool:
    return p.suffix.lower() in EXT_FOTO


def nome_seguro_arquivo(nome: str) -> str:
    base = Path(nome).name
    base = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", base).strip(" .") or "arquivo"
    return base[-120:]


# ============================================================ cor
def estatisticas_cor(arq: Path, amostras: int = 8, dur: float | None = None, hdr: bool = False) -> dict:
    """Média de brilho, contraste, saturação e cor de algumas imagens do vídeo/foto."""
    from .render import TONEMAP
    pre = (TONEMAP + ",") if hdr else ""
    if eh_foto(arq):
        cmd = ["ffmpeg", "-v", "error", "-i", str(arq), "-vf", f"{pre}scale=160:-2,format=rgb24",
               "-frames:v", "1", "-f", "rawvideo", "-"]
    else:
        dur = dur or 10.0
        fps = max(0.05, amostras / max(dur, 0.5))
        cmd = ["ffmpeg", "-v", "error", "-i", str(arq), "-an", "-vf",
               f"{pre}fps={fps:.4f},scale=160:90,format=rgb24", "-frames:v", str(amostras),
               "-f", "rawvideo", "-"]
    bruto = subprocess.run(cmd, capture_output=True).stdout
    px = np.frombuffer(bruto, np.uint8).reshape(-1, 3).astype(np.float32) / 255.0
    if len(px) == 0:
        return {"y": 0.45, "ys": 0.22, "sat": 0.25, "r": 1.0, "g": 1.0, "b": 1.0}
    y = 0.2126 * px[:, 0] + 0.7152 * px[:, 1] + 0.0722 * px[:, 2]
    mx, mn = px.max(1), px.min(1)
    sat = np.where(mx > 0, (mx - mn) / np.maximum(mx, 1e-6), 0)
    med = px.mean(0)
    cinza = med.mean() or 1e-6
    return {"y": float(y.mean()), "ys": float(y.std()), "sat": float(sat.mean()),
            "r": float(med[0] / cinza), "g": float(med[1] / cinza), "b": float(med[2] / cinza)}


def filtro_harmonizar(ref: dict, clip: dict, forca: float = 0.8) -> str:
    """Filtro ffmpeg que aproxima a cor/brilho do clipe ao vídeo principal (sem exagero)."""
    lim = lambda v, a, b: max(a, min(b, v))  # noqa: E731
    k = lim(1 + forca * ((ref["ys"] / max(clip["ys"], 1e-3)) - 1), 0.82, 1.22)
    novo_y = (clip["y"] - 0.5) * k + 0.5
    b = lim(forca * (ref["y"] - novo_y), -0.12, 0.12)
    s = lim(1 + forca * ((ref["sat"] / max(clip["sat"], 1e-3)) - 1), 0.75, 1.3)
    ganhos = [lim(1 + forca * (ref[c] / max(clip[c], 1e-3) - 1), 0.92, 1.08) for c in "rgb"]
    return (f"colorchannelmixer=rr={ganhos[0]:.3f}:gg={ganhos[1]:.3f}:bb={ganhos[2]:.3f},"
            f"eq=contrast={k:.3f}:brightness={b:.3f}:saturation={s:.3f}")


# ============================================================ registro de mídias
def preparar_midia(arq: Path, pasta: Path, cfg: dict) -> dict:
    """Miniatura + cópia leve para a prévia no navegador + medidas + cor."""
    pasta.mkdir(parents=True, exist_ok=True)
    foto = eh_foto(arq)
    thumb = pasta / f"{arq.name}.thumb.jpg"
    if foto:
        rodar_ffmpeg(["-i", str(arq), "-vf", "scale=480:-2", "-frames:v", "1", str(thumb)])
        out = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                              "stream=width,height", "-of", "json", str(arq)], capture_output=True, text=True)
        s = json.loads(out.stdout or "{}").get("streams", [{}])[0]
        info_m = {"largura": s.get("width", 1920), "altura": s.get("height", 1080), "duracao": DUR_FOTO * 3,
                  "hdr": False, "fps": 30}
        previa = None
    else:
        info_m = sondar(arq, exigir_audio=False)
        meio = min(1.0, info_m["duracao"] / 2)
        rodar_ffmpeg(["-ss", f"{meio:.2f}", "-i", str(arq), "-vf", "scale=480:-2", "-frames:v", "1", str(thumb)])
        previa = pasta / f"{arq.name}.previa.mp4"
        vf = "scale='min(854,iw)':-2"
        if info_m.get("hdr"):
            from .render import TONEMAP
            vf = TONEMAP + "," + vf
        rodar_ffmpeg(["-i", str(arq), "-vf", vf, "-an", *args_video(escolher_encoder(cfg), "leve", 480),
                      "-g", "15", "-movflags", "+faststart", str(previa)])
    cor = estatisticas_cor(arq, dur=info_m["duracao"], hdr=info_m.get("hdr", False))
    return {"nome": arq.name, "tipo": "foto" if foto else "video", "duracao": round(info_m["duracao"], 3),
            "largura": info_m["largura"], "altura": info_m["altura"], "hdr": info_m.get("hdr", False),
            "thumb": f"/midia/{thumb.name}", "previa": f"/midia/{previa.name}" if previa else f"/midia/{arq.name}",
            "cor": cor}


# ============================================================ IA: onde encaixar o B-roll
PROMPT_BROLL = """Você é um editor de vídeo. Um vídeo de uma pessoa falando vai receber IMAGENS DE APOIO (B-roll): cenas que aparecem por cima enquanto ela continua falando.

Abaixo: a fala (palavras com índice entre colchetes, já sem os erros) e, depois, as mídias disponíveis, cada uma com a descrição do que mostra.

Para CADA mídia, escolha o momento da fala em que ela mais combina com o que está sendo dito, e por quanto tempo aparece.
Regras:
- "palavra": índice da palavra onde a imagem ENTRA (comece no início da ideia relacionada).
- "duracao": entre 2.5 e 6 segundos (fotos: 3 a 5). Não ultrapasse a duração do vídeo da mídia.
- Não coloque nada nos primeiros 3 segundos (o rosto da pessoa precisa aparecer no começo) nem duas mídias ao mesmo tempo.
- Se uma mídia não combinar com nada, use o trecho mais neutro possível.

Responda SOMENTE com JSON: {"itens":[{"midia":"M1","palavra":42,"duracao":4.0,"motivo":"fala sobre o aplicativo"}]}

FALA:
"""


def _jpeg_b64(arq: Path, seg: float | None = None) -> str | None:
    args = ["ffmpeg", "-v", "error"]
    if seg is not None:
        args += ["-ss", f"{seg:.2f}"]
    args += ["-i", str(arq), "-vf", "scale=512:-2", "-frames:v", "1", "-f", "image2", "-c:v", "mjpeg", "-q:v", "5", "-"]
    dados = subprocess.run(args, capture_output=True).stdout
    return base64.b64encode(dados).decode() if dados else None


def descrever_midia(arq: Path, m: dict, cfg: dict) -> str:
    """Uma frase dizendo o que aparece na imagem/vídeo (a IA olha 1 a 3 quadros)."""
    from . import ia
    if not ia.enxerga_imagens(cfg):
        return Path(m["nome"]).stem.replace("_", " ").replace("-", " ")
    tempos = [None] if m["tipo"] == "foto" else [m["duracao"] * f for f in (0.2, 0.5, 0.8)]
    imgs = [b for b in (_jpeg_b64(arq, t) for t in tempos) if b]
    try:
        d = ia.perguntar_json(cfg, "Descreva em português, em uma frase curta, o que aparece nesta(s) imagem(ns) "
                                   "(são quadros do mesmo vídeo/foto). Responda SOMENTE com JSON: "
                                   '{"descricao": "..."}', imgs, max_tokens=120)
        return str(d.get("descricao", ""))[:160]
    except Exception:  # noqa: BLE001
        return Path(m["nome"]).stem


def sugerir_broll(midias: list[dict], pasta: Path, falas: list[dict], ocupados: list[dict],
                  cfg: dict) -> list[dict]:
    """falas: palavras mantidas [{i, w, t}] com t = tempo no vídeo final.
    Retorna [{midia, palavra, dur, inicio}]."""
    if not midias or not falas:
        return []
    from . import ia
    res: list[dict] = []
    if ia.provedor(cfg):
        try:
            # 1º: a IA descreve cada imagem (uma por vez — funciona bem até com modelos locais pequenos)
            linhas = []
            for k, m in enumerate(midias, 1):
                desc = m.get("descricao") or descrever_midia(pasta / m["nome"], m, cfg)
                m["descricao"] = desc
                linhas.append(f"M{k}: {m['tipo']}" + (f" de {m['duracao']:.1f}s" if m["tipo"] == "video" else "")
                              + f" — mostra: {desc or m['nome']}")
            # 2º: com as descrições em texto, escolhe onde cada uma entra na fala
            texto = (PROMPT_BROLL + " ".join(f"[{w['i']}]{w['w']}" for w in falas) + "\n\nMÍDIAS:\n" + "\n".join(linhas))
            if ocupados:
                texto += "\nJá ocupados (não use): " + ", ".join(f"palavras {o['de']}–{o['ate']}" for o in ocupados)
            dados = ia.perguntar_json(cfg, texto, max_tokens=1500)
            validos = {w["i"] for w in falas}
            for it in dados.get("itens", []):
                k = int(str(it.get("midia", "M0")).lstrip("Mm") or 0) - 1
                if not 0 <= k < len(midias):
                    continue
                pal = int(it.get("palavra", -1))
                if pal not in validos:
                    pal = min(validos, key=lambda v: abs(v - pal))
                m = midias[k]
                dur = float(it.get("duracao", 4.0))
                dur = min(max(2.0, dur), 6.0 if m["tipo"] == "video" else 5.0)
                if m["tipo"] == "video":
                    dur = min(dur, max(1.0, m["duracao"] - 0.1))
                res.append({"midia": m["nome"], "palavra": pal, "dur": round(dur, 2), "inicio": 0.0,
                            "motivo": str(it.get("motivo", ""))[:120]})
        except Exception as e:  # noqa: BLE001
            aviso(f"IA não conseguiu posicionar as imagens de apoio ({str(e)[:100]}). Distribuindo igualmente.")
            res = []
    faltam = [m for m in midias if m["nome"] not in {r["midia"] for r in res}]
    if faltam:  # sem IA: espalha ao longo da fala, longe do começo
        total = falas[-1]["t"]
        candidatos = [w for w in falas if w["t"] > 3.0] or falas
        for j, m in enumerate(faltam):
            alvo = 3.0 + (total - 3.0) * (j + 1) / (len(faltam) + 1)
            w = min(candidatos, key=lambda x: abs(x["t"] - alvo))
            dur = 4.0 if m["tipo"] == "foto" else min(4.0, max(1.0, m["duracao"] - 0.1))
            res.append({"midia": m["nome"], "palavra": w["i"], "dur": dur, "inicio": 0.0, "motivo": "posição automática"})
    return res


# ============================================================ partes da fala (sequência)
def normalizar_parte(arq: Path, destino: Path, ref: dict, cor_ref: dict | None, cfg: dict,
                     eh_principal: bool) -> dict:
    """Converte uma parte da fala para o mesmo formato do vídeo principal (tamanho, fluidez, cor, volume)."""
    from .render import TONEMAP, _par
    iv = sondar(arq)
    W, H = _par(ref["largura"]), _par(ref["altura"])
    vf = [TONEMAP] if iv.get("hdr") else []
    ar_dif = abs(iv["proporcao"] - W / H) / (W / H)
    if ar_dif < 0.12:
        vf.append(f"scale={W}:{H}:force_original_aspect_ratio=increase:flags=lanczos,crop={W}:{H}")
        grafo = None
    else:  # proporção muito diferente: imagem inteira com fundo desfocado
        grafo = (f"[0:v]{(TONEMAP + ',') if iv.get('hdr') else ''}split=2[a][b];"
                 f"[a]scale={W // 4}:{H // 4}:force_original_aspect_ratio=increase,crop={W // 4}:{H // 4},"
                 f"boxblur=10:2,scale={W}:{H}[bg];[b]scale={W}:{H}:force_original_aspect_ratio=decrease:flags=lanczos[fg];"
                 f"[bg][fg]overlay=(W-w)/2:(H-h)/2")
    harmonia = ""
    if cor_ref and not eh_principal:
        harmonia = filtro_harmonizar(cor_ref, estatisticas_cor(arq, dur=iv["duracao"], hdr=iv.get("hdr", False)))
    fim = [f"fps={ref['fps']:.6f}", "setsar=1", "format=yuv420p"]
    if harmonia:
        fim.insert(0, harmonia)
    af = "aresample=48000,loudnorm=I=-16:TP=-1.5:LRA=11,aresample=48000"
    enc = escolher_encoder(cfg)
    q = (["-c:v", "h264_nvenc", "-preset", "p5", "-rc", "constqp", "-qp", "10"] if enc == "nvenc"
         else ["-c:v", "libx264", "-preset", "veryfast", "-crf", "10"])
    if grafo:
        args = ["-i", str(arq), "-filter_complex", grafo + "," + ",".join(fim) + "[v]",
                "-map", "[v]", "-map", "0:a"]
    else:
        args = ["-i", str(arq), "-vf", ",".join(vf + fim)]
    rodar_ffmpeg([*args, "-af", af, "-ac", "2", *q, "-pix_fmt", "yuv420p", "-c:a", "pcm_s16le",
                  str(destino)], duracao=iv["duracao"], rotulo=f"preparando {arq.name[:30]}")
    return sondar(destino)


def juntar_partes(arquivos: list[Path], destino: Path) -> None:
    lista = destino.with_suffix(".txt")
    lista.write_text("".join(f"file '{a.as_posix()}'\n" for a in arquivos), encoding="utf-8")
    rodar_ffmpeg(["-f", "concat", "-safe", "0", "-i", str(lista), "-c", "copy", str(destino)])


# ============================================================ abertura / encerramento
def vinheta(tipo: str) -> Path | None:
    if not PASTA_VINHETAS.is_dir():
        return None
    for f in sorted(PASTA_VINHETAS.iterdir()):
        if f.stem.lower() == tipo and (f.suffix.lower() in EXT_VIDEO or f.suffix.lower() in EXT_FOTO):
            return f
    return None


def info_vinheta(tipo: str) -> dict | None:
    f = vinheta(tipo)
    if not f:
        return None
    if eh_foto(f):
        return {"arquivo": f, "nome": f.name, "duracao": DUR_VINHETA_FOTO, "foto": True, "audio": False}
    iv = sondar(f, exigir_audio=False)
    return {"arquivo": f, "nome": f.name, "duracao": iv["duracao"], "foto": False, "audio": iv.get("tem_audio", False)}


def previa_vinheta(tipo: str, pasta: Path, cfg: dict) -> Path | None:
    f = vinheta(tipo)
    if not f:
        return None
    pasta.mkdir(parents=True, exist_ok=True)
    alvo = pasta / f"vinheta_{tipo}_{int(f.stat().st_mtime)}.{'jpg' if eh_foto(f) else 'mp4'}"
    if not alvo.exists():
        if eh_foto(f):
            rodar_ffmpeg(["-i", str(f), "-vf", "scale=640:-2", "-frames:v", "1", str(alvo)])
        else:
            rodar_ffmpeg(["-i", str(f), "-vf", "scale='min(854,iw)':-2", *args_video(escolher_encoder(cfg), "leve", 480),
                          "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(alvo)])
    return alvo
