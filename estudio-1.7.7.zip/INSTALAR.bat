@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Instalador - Editor Automatico
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
echo.
pause
