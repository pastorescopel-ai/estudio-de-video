@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Estudio de Video
REM Abre o Estudio mostrando a janela de registro (util para ver detalhes se algo der errado).
REM No dia a dia, use o icone "Estudio de Video" da area de trabalho ou do menu Iniciar.
if not exist ".venv\Scripts\python.exe" (
  echo Rode primeiro o INSTALAR.bat
  pause & exit /b
)
".venv\Scripts\python.exe" -m editor %*
pause
