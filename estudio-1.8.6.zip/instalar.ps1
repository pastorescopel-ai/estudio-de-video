﻿# =====================================================================
#  Estúdio de Vídeo — instalação completa, de uma vez só.
#  - Chamado pelo instalador .exe em modo oculto (-Silencioso -Status arquivo):
#    o progresso vai para a janela do instalador, sem janela do PowerShell.
#  - Também roda sozinho (INSTALAR.bat), fazendo as perguntas no começo.
#  Mais rápido: Python e bibliotecas pelo "uv" (downloads em paralelo) e os
#  arquivos grandes (FFmpeg, IA, modelo de fala) baixando ao mesmo tempo.
#  Pode rodar de novo quando quiser: o que já está instalado é pulado.
# =====================================================================
param(
    [switch]$Silencioso,
    [string]$Entrada = '',
    [string]$Destino = '',
    [int]$IA = 1,
    [int]$Barra = 1,
    [int]$IniciarWindows = 1,
    [int]$AbrirAgora = 0,
    [string]$Status = '',   # arquivo onde o instalador .exe lê o progresso
    [switch]$Janela
)
$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
$Raiz = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Raiz

$UTF8 = New-Object System.Text.UTF8Encoding($false)
$UTF16 = New-Object System.Text.UnicodeEncoding($false, $false)   # o instalador .exe lê assim
$Problemas = New-Object System.Collections.ArrayList
$LOG = Join-Path $Raiz 'instalacao.log'

# ------------------------------------------------------------------ mensagens (tela + registro + instalador .exe)
function Registrar($t) {
    try { [IO.File]::AppendAllText($LOG, "$(Get-Date -Format 'HH:mm:ss') $t`r`n", $UTF8) } catch {}
    if ($Status) { try { [IO.File]::AppendAllText($Status, "$t`r`n", $UTF16) } catch {} }
}
function Progresso([int]$pct) { if ($Status) { try { [IO.File]::AppendAllText($Status, "@@PCT $pct`r`n", $UTF16) } catch {} } }
function Etapa($pct, $t) { Write-Host ''; Write-Host "» $t" -ForegroundColor Cyan; Registrar "» $t"; Progresso $pct }
function Ok($t) { Write-Host "    OK  $t" -ForegroundColor Green; Registrar "    ✓ $t" }
function Info($t) { Write-Host "        $t"; Registrar "        $t" }
function Aviso($t) { Write-Host "    !   $t" -ForegroundColor Yellow; Registrar "    ! $t" }
function Falha($t) { Write-Host "    X   $t" -ForegroundColor Red; Registrar "    ✗ $t"; [void]$Problemas.Add($t) }

function Perguntar-SimNao($texto, $padrao) {
    $sufixo = if ($padrao) { '[S/n]' } else { '[s/N]' }
    $r = Read-Host "  $texto $sufixo"
    if ([string]::IsNullOrWhiteSpace($r)) { return $padrao }
    return ($r.Trim().ToLower().StartsWith('s'))
}
function Ler-Texto($arq) { return [IO.File]::ReadAllText($arq, $UTF8) }
function Gravar-Texto($arq, $txt) { [IO.File]::WriteAllText($arq, $txt, $UTF8) }
function MB($bytes) { return [math]::Round($bytes / 1MB) }

# ------------------------------------------------------------------ downloads em segundo plano (vários ao mesmo tempo)
$temCurl = [bool](Get-Command curl.exe -ErrorAction SilentlyContinue)
function Iniciar-Download($nome, $urls, $destino) {
    $d = [pscustomobject]@{ Nome = $nome; Urls = @($urls); Destino = $destino; Proc = $null }
    if (Test-Path $destino) { Remove-Item $destino -Force -ErrorAction SilentlyContinue }
    if ($temCurl) {
        $d.Proc = Start-Process -FilePath 'curl.exe' -WindowStyle Hidden -PassThru `
            -ArgumentList @('-L', '--fail', '--silent', '--retry', '3', '--retry-delay', '2', '-o', "`"$destino`"", "`"$($d.Urls[0])`"")
    }
    return $d
}
function Esperar-Download($d) {
    if ($d.Proc) {
        $ultimo = Get-Date
        while (-not $d.Proc.HasExited) {
            Start-Sleep -Milliseconds 700
            if (((Get-Date) - $ultimo).TotalSeconds -ge 5 -and (Test-Path $d.Destino)) {
                Info "baixando $($d.Nome)... $(MB (Get-Item $d.Destino).Length) MB"; $ultimo = Get-Date
            }
        }
    }
    if ((Test-Path $d.Destino) -and (Get-Item $d.Destino).Length -gt 20000) { return $true }
    $resto = if ($d.Proc) { $d.Urls | Select-Object -Skip 1 } else { $d.Urls }
    foreach ($u in $resto) {   # endereço reserva
        Info "tentando outro endereço para $($d.Nome)..."
        try {
            if ($temCurl) { & curl.exe -L --fail --silent --retry 3 -o $d.Destino $u } else { Invoke-WebRequest -Uri $u -OutFile $d.Destino -UseBasicParsing }
        } catch {}
        if ((Test-Path $d.Destino) -and (Get-Item $d.Destino).Length -gt 20000) { return $true }
    }
    return $false
}

function Atalho($caminho, $alvo, $minimizado, $argumentos = '', $icone = '') {
    try {
        $s = (New-Object -ComObject WScript.Shell).CreateShortcut($caminho)
        $s.TargetPath = $alvo
        $s.WorkingDirectory = $Raiz
        if ($argumentos) { $s.Arguments = $argumentos }
        if ($icone -and (Test-Path $icone)) { $s.IconLocation = "$icone,0" }
        $s.Description = 'Estúdio de Vídeo — edição automática'
        if ($minimizado) { $s.WindowStyle = 7 }
        $s.Save()
        return $true
    } catch { return $false }
}

function Achar-Python {
    $cands = New-Object System.Collections.ArrayList
    if (Get-Command py -ErrorAction SilentlyContinue) {
        $p = & py -3.12 -c "import sys; print(sys.executable)" 2>$null
        if ($LASTEXITCODE -eq 0 -and $p) { [void]$cands.Add(($p | Select-Object -First 1).Trim()) }
    }
    [void]$cands.Add("$env:LOCALAPPDATA\Programs\Python\Python312\python.exe")
    foreach ($c in $cands) { if ($c -and (Test-Path $c)) { return $c } }
    return $null
}

function Rodar-Mostrando($exe, [string[]]$argumentos) {
    # roda um programa e manda as linhas de saída para o registro (útil para entender erros)
    & $exe @argumentos 2>&1 | ForEach-Object { $l = "$_".Trim(); if ($l) { Registrar "        $l" } }
    return $LASTEXITCODE
}

# ==================================================================== perguntas (só no modo manual)
if ($Status) { Registrar "@@PID $PID" }
$cfgArq = Join-Path $Raiz 'config.yaml'
$cfg = Ler-Texto $cfgArq
$VALOR = '("[^"]*"|\S+)'
$entradaAtual = ([regex]::Match($cfg, "(?m)^\s*entrada:\s*$VALOR")).Groups[1].Value.Trim('"')
$destinoAtual = ([regex]::Match($cfg, "(?m)^\s*destino:\s*$VALOR")).Groups[1].Value.Trim('"')
$videos = [Environment]::GetFolderPath('MyVideos')
if ([string]::IsNullOrWhiteSpace($videos)) { $videos = Join-Path $env:USERPROFILE 'Videos' }
$sugEntrada = if ($entradaAtual -and $entradaAtual -notlike '~*') { $entradaAtual } else { Join-Path $videos 'ENTRADA' }
$sugDestino = if ($destinoAtual -and $destinoAtual -notlike '~*') { $destinoAtual } else { Join-Path $videos 'Biblioteca' }

if ($Silencioso) {
    $entrada = if ($Entrada) { $Entrada } else { $sugEntrada }
    $destino = if ($Destino) { $Destino } else { $sugDestino }
    $querIA = [bool]$IA; $fixarBarra = [bool]$Barra; $iniciarWindows = [bool]$IniciarWindows; $abrirAgora = [bool]$AbrirAgora
} else {
    Clear-Host
    Write-Host '  ESTÚDIO DE VÍDEO — INSTALAÇÃO' -ForegroundColor Yellow
    Write-Host "  Vídeos crus em:   $sugEntrada"
    Write-Host "  Biblioteca em:    $sugDestino"
    $r = Read-Host '  Enter para usar essas pastas, ou digite outra pasta para os vídeos crus'
    $entrada = if ([string]::IsNullOrWhiteSpace($r)) { $sugEntrada } else { $r.Trim('" ') }
    $r = Read-Host '  Enter para manter a biblioteca acima, ou digite outra pasta'
    $destino = if ([string]::IsNullOrWhiteSpace($r)) { $sugDestino } else { $r.Trim('" ') }
    $querIA = Perguntar-SimNao 'Instalar a IA local gratuita? (recomendado)' $true
    $fixarBarra = Perguntar-SimNao 'Fixar o Estúdio na barra de tarefas?' $true
    $iniciarWindows = Perguntar-SimNao 'Ligar o Estúdio junto com o Windows?' $true
    $abrirAgora = Perguntar-SimNao 'Abrir o Estúdio ao terminar?' $true
}
$inicio = Get-Date
Registrar "===== instalação iniciada $(Get-Date -Format 'yyyy-MM-dd HH:mm') ====="

$venvPy = Join-Path $Raiz '.venv\Scripts\python.exe'
$pyw = Join-Path $Raiz '.venv\Scripts\pythonw.exe'
$ffBin = Join-Path $Raiz 'ffmpeg\bin'
$ffExe = Join-Path $ffBin 'ffmpeg.exe'
$uv = Join-Path $Raiz 'tools\uv.exe'
$ollama = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'
if (-not (Test-Path $ollama)) { $c = Get-Command ollama -ErrorAction SilentlyContinue; if ($c) { $ollama = $c.Source } }
$tmp = Join-Path $env:TEMP 'estudio-instalacao'
New-Item -ItemType Directory -Force -Path $tmp | Out-Null

# ==================================================================== 1. placa de vídeo
Etapa 2 'Verificando a placa de vídeo'
$smi = Get-Command nvidia-smi -ErrorAction SilentlyContinue
if (-not $smi -and (Test-Path "$env:SystemRoot\System32\nvidia-smi.exe")) { $smi = "$env:SystemRoot\System32\nvidia-smi.exe" }
$gpu = $false; $vramGB = 0
if ($smi) {
    $linhaGpu = & $smi --query-gpu=name,memory.total --format=csv,noheader,nounits 2>$null | Select-Object -First 1
    if ($LASTEXITCODE -eq 0 -and $linhaGpu) {
        $gpu = $true
        $partes = $linhaGpu -split ','
        try { $vramGB = [math]::Round([double]($partes[-1].Trim()) / 1024, 1) } catch { $vramGB = 0 }
        Ok "NVIDIA $($partes[0].Trim()) ($vramGB GB)"
    }
}
$placas = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | ForEach-Object { $_.Name }) -join ', '
if (-not $gpu) {
    if ($placas -match 'AMD|Radeon') { Ok "placa AMD ($placas): exportação acelerada pela placa; a transcrição usa o processador" }
    elseif ($placas -match 'Intel') { Ok "vídeo Intel ($placas): exportação acelerada; a transcrição usa o processador" }
    else { Aviso 'sem placa de vídeo dedicada: vai funcionar no processador (mais devagar)' }
}

# ==================================================================== 2. downloads grandes começam JÁ, em paralelo
Etapa 5 'Começando os downloads em paralelo (FFmpeg, IA e fonte)'
$dFF = $null; $dOllama = $null; $dFonte = $null
if (-not (Test-Path $ffExe)) {
    $dFF = Iniciar-Download 'FFmpeg' @('https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip',
                                       'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip') (Join-Path $tmp 'ffmpeg.zip')
}
if ($querIA -and -not (Test-Path $ollama)) {
    $dOllama = Iniciar-Download 'Ollama' @('https://ollama.com/download/OllamaSetup.exe') (Join-Path $tmp 'OllamaSetup.exe')
}
$fonte = Join-Path $Raiz 'fontes\Montserrat-ExtraBold.ttf'
if (-not (Test-Path $fonte)) {
    $dFonte = Iniciar-Download 'fonte' @('https://github.com/JulietaUla/Montserrat/raw/master/fonts/ttf/Montserrat-ExtraBold.ttf',
                                         'https://cdn.jsdelivr.net/fontsource/fonts/montserrat@latest/latin-800-normal.ttf') $fonte
}
Ok 'downloads iniciados'

# ==================================================================== 3. Python (pelo uv: sem instalador, sem winget)
Etapa 10 'Python'
$env:UV_PYTHON_INSTALL_DIR = Join-Path $Raiz 'python'
$env:UV_CACHE_DIR = Join-Path $Raiz '.cache\uv'
$env:UV_LINK_MODE = 'copy'
$env:UV_NO_PROGRESS = '1'
if (Test-Path $venvPy) {
    # o Python existe mas funciona? (antivírus às vezes põe o python.exe/pythonw.exe em quarentena)
    $saude = 1
    try { & $venvPy -c "import sys" 2>$null; $saude = $LASTEXITCODE } catch { $saude = 1 }
    # o pythonw.exe do .venv só "aponta" para o Python base (linha home= do pyvenv.cfg): ele precisa existir
    $pywOk = (Test-Path $pyw)
    try {
        $cfgVenv = Join-Path $Raiz '.venv\pyvenv.cfg'
        $pyBase = ((Get-Content $cfgVenv | Where-Object { $_ -match '^\s*home\s*=' }) -replace '^\s*home\s*=\s*', '').Trim()
        if ($pyBase -and -not ((Test-Path (Join-Path $pyBase 'python.exe')) -and (Test-Path (Join-Path $pyBase 'pythonw.exe')))) { $pywOk = $false }
    } catch { }
    if ($saude -eq 0 -and $pywOk) { Ok 'já instalado' }
    else {
        Aviso 'o Python do Estúdio estava quebrado (talvez o antivírus tenha removido algum arquivo) — reinstalando'
        Remove-Item -Recurse -Force (Join-Path $Raiz '.venv') -ErrorAction SilentlyContinue
        Remove-Item -Recurse -Force (Join-Path $Raiz 'python') -ErrorAction SilentlyContinue
    }
}
if (Test-Path $venvPy) { }
else {
    if (Test-Path $uv) {
        $r = Rodar-Mostrando $uv @('venv', (Join-Path $Raiz '.venv'), '--python', '3.12', '--python-preference', 'only-managed')
        if ((Test-Path $venvPy)) { Ok 'Python 3.12 pronto' } else { Aviso "uv não conseguiu (código $r); usando o jeito tradicional" }
    }
    if (-not (Test-Path $venvPy)) {   # reserva: Python oficial
        $py = Achar-Python
        if (-not $py) {
            Info 'baixando o Python oficial...'
            $dPy = Iniciar-Download 'Python' @('https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe') (Join-Path $tmp 'python.exe')
            if (Esperar-Download $dPy) {
                Start-Process -FilePath (Join-Path $tmp 'python.exe') -ArgumentList '/quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_test=0' -Wait -WindowStyle Hidden
                $py = Achar-Python
            }
        }
        if ($py) { & $py -m venv (Join-Path $Raiz '.venv') }
        if (Test-Path $venvPy) { Ok 'Python pronto' } else { Falha 'Não consegui instalar o Python.' }
    }
}

# ==================================================================== 4. bibliotecas
Etapa 20 'Bibliotecas do editor (baixando várias ao mesmo tempo)'
if (Test-Path $venvPy) {
    $reqs = @('-r', (Join-Path $Raiz 'requirements.txt'))
    if ($gpu) { $reqs += @('-r', (Join-Path $Raiz 'requirements-nvidia.txt')) }
    $ok = $false
    if (Test-Path $uv) {
        $r = Rodar-Mostrando $uv (@('pip', 'install', '--python', $venvPy) + $reqs)
        $ok = ($r -eq 0)
    }
    if (-not $ok) {   # reserva: pip
        Info 'usando o pip (mais lento)...'
        [void](Rodar-Mostrando $venvPy @('-m', 'ensurepip', '--upgrade'))
        $r = Rodar-Mostrando $venvPy (@('-m', 'pip', 'install', '--disable-pip-version-check') + $reqs)
        $ok = ($r -eq 0)
    }
    if ($ok) { Ok 'bibliotecas instaladas' } else { Falha 'Erro ao instalar as bibliotecas (detalhes em instalacao.log).' }
}

# ==================================================================== 5. modelo de fala: baixa em segundo plano
$modeloFala = if ($gpu) { 'large-v3-turbo' } else { 'medium' }   # turbo: metade do tamanho e muito mais rápido
$pFala = $null
if (Test-Path $venvPy) {
    Etapa 40 "Modelo de transcrição de fala ($modeloFala) — baixando em segundo plano"
    $env:HF_HUB_DISABLE_SYMLINKS_WARNING = '1'
    $env:HF_HUB_DISABLE_PROGRESS_BARS = '1'
    $pFala = Start-Process -FilePath $venvPy -WindowStyle Hidden -PassThru `
        -RedirectStandardError (Join-Path $tmp 'modelo_fala.log') `
        -ArgumentList "-c `"from faster_whisper import download_model; download_model('$modeloFala')`""
}

# ==================================================================== 6. FFmpeg
Etapa 45 'FFmpeg (motor de vídeo, aceleração NVIDIA e legendas)'
if (Test-Path $ffExe) { Ok 'já instalado' }
elseif ($dFF -and (Esperar-Download $dFF)) {
    $pasta = Join-Path $tmp 'ffmpeg'
    if (Test-Path $pasta) { Remove-Item $pasta -Recurse -Force }
    try { Expand-Archive -Path $dFF.Destino -DestinationPath $pasta -Force } catch {}
    $achado = Get-ChildItem -Path $pasta -Recurse -Filter 'ffmpeg.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($achado) {
        New-Item -ItemType Directory -Force -Path $ffBin | Out-Null
        Copy-Item -Path (Join-Path $achado.DirectoryName '*') -Destination $ffBin -Force
        Ok 'FFmpeg instalado'
    } else { Falha 'O pacote do FFmpeg veio incompleto.' }
    Remove-Item $dFF.Destino, $pasta -Recurse -Force -ErrorAction SilentlyContinue
} else { Falha 'Não consegui baixar o FFmpeg.' }

function Fechar-AppOllama {
    # O Ollama novo abre uma janela de bate-papo pedindo para entrar numa conta. A conta NÃO é
    # necessária para a IA local: fechamos essa janela e o próprio Estúdio liga o Ollama escondido.
    Start-Sleep -Seconds 2
    Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ProcessName -match '^(ollama app|Ollama)$' -or ($_.Path -and $_.Path -match 'Ollama\\(ollama app|Ollama)\.exe$')
    } | Stop-Process -Force -ErrorAction SilentlyContinue
    $atalho = Join-Path ([Environment]::GetFolderPath('Startup')) 'Ollama.lnk'
    if (Test-Path $atalho) { Remove-Item $atalho -Force -ErrorAction SilentlyContinue }
}

# ==================================================================== 7. IA local: instala e começa a baixar o modelo em segundo plano
$pIA = $null; $modeloIA = $null; $logIA = Join-Path $tmp 'ollama_pull.log'
if ($querIA) {
    Etapa 55 'IA local gratuita (Ollama + Gemma)'
    if (-not (Test-Path $ollama) -and $dOllama -and (Esperar-Download $dOllama)) {
        Info 'instalando o Ollama...'
        # Sem -Wait: no PowerShell ele espera também o aplicativo do Ollama que abre no fim
        # (a janela que pede para entrar na conta), e a instalação ficava parada ali.
        $pInst = Start-Process -FilePath $dOllama.Destino -ArgumentList '/VERYSILENT /NORESTART /SUPPRESSMSGBOXES /NOCANCEL' -WindowStyle Hidden -PassThru
        $pInst.WaitForExit(900000) | Out-Null
        $ollama = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'
    }
    Fechar-AppOllama
    if (Test-Path $ollama) {
        Ok 'Ollama instalado'
        $noAr = $false
        for ($i = 0; $i -lt 40 -and -not $noAr; $i++) {
            try { Invoke-WebRequest -Uri 'http://127.0.0.1:11434/api/tags' -UseBasicParsing -TimeoutSec 2 | Out-Null; $noAr = $true }
            catch { if ($i -eq 0) { Fechar-AppOllama; Start-Process -FilePath $ollama -ArgumentList 'serve' -WindowStyle Hidden }; Start-Sleep -Seconds 1 }
        }
        $modeloIA = if ($vramGB -ge 10) { 'gemma3:12b' } else { 'gemma3:4b' }
        $jaTem = & $ollama list 2>$null | Select-String -SimpleMatch $modeloIA
        if ($jaTem) { Ok "modelo $modeloIA já baixado" }
        else {
            Info "baixando o modelo $modeloIA em segundo plano..."
            $pIA = Start-Process -FilePath $ollama -ArgumentList "pull $modeloIA" -WindowStyle Hidden -PassThru `
                -RedirectStandardError $logIA -RedirectStandardOutput (Join-Path $tmp 'ollama_pull_out.log')
        }
    } else { Falha 'Não consegui instalar o Ollama (rode o instalador de novo mais tarde).' }
}

# ==================================================================== 8. configuração e atalhos (enquanto os modelos baixam)
Etapa 62 'Configuração e atalhos'
$cfg = Ler-Texto $cfgArq
$cfg = [regex]::Replace($cfg, "(?m)^(\s*entrada:\s*)$VALOR", ('${1}"' + ($entrada -replace '\\', '/') + '"'))
$cfg = [regex]::Replace($cfg, "(?m)^(\s*destino:\s*)$VALOR", ('${1}"' + ($destino -replace '\\', '/') + '"'))
$cfg = [regex]::Replace($cfg, '(?m)^(\s*modelo:\s*)(large-v3\S*|medium|small)', ('${1}' + $modeloFala))
if (-not $querIA) { $cfg = [regex]::Replace($cfg, '(?m)^(\s*provedor:\s*)\S+', '${1}nenhum') }
Gravar-Texto $cfgArq $cfg
$envArq = Join-Path $Raiz '.env'
if (-not (Test-Path $envArq)) { Gravar-Texto $envArq "# Opcional: chave da Claude API (só se em config.yaml ia: provedor for api/auto)`r`n# ANTHROPIC_API_KEY=`r`n" }
New-Item -ItemType Directory -Force -Path $entrada, $destino | Out-Null
Ok "pastas: $entrada  ->  $destino"

if ($dFonte) { if (Esperar-Download $dFonte) { Ok 'fonte da legenda (Montserrat)' } else { Aviso 'sem a fonte Montserrat: a legenda usará Arial Black' } }

$icone = Join-Path $Raiz 'estudio.ico'
$desk = [Environment]::GetFolderPath('Desktop')
$menu = Join-Path ([Environment]::GetFolderPath('Programs')) 'Estúdio de Vídeo.lnk'
$atalhoDesk = Join-Path $desk 'Estúdio de Vídeo.lnk'
foreach ($lnk in @($atalhoDesk, $menu)) { [void](Atalho $lnk $pyw $false '-m editor' $icone) }
if ((Test-Path $atalhoDesk) -and (Test-Path $menu)) { Ok 'ícone na área de trabalho e no menu Iniciar' }
[void](Atalho (Join-Path $desk 'Videos para editar.lnk') $entrada $false)
$startup = Join-Path ([Environment]::GetFolderPath('Startup')) 'Estúdio de Vídeo.lnk'
foreach ($velho in @((Join-Path ([Environment]::GetFolderPath('Startup')) 'Vigia de Videos.lnk'), (Join-Path $desk 'Vigia de videos.lnk'), (Join-Path $desk 'Editar um video.lnk'))) {
    if (Test-Path $velho) { Remove-Item $velho -Force }
}
if ($iniciarWindows) { if (Atalho $startup $pyw $false '-m editor --sem-janela' $icone) { Ok 'liga junto com o Windows' } }
elseif (Test-Path $startup) { Remove-Item $startup -Force }
$fixouBarra = $false
if ($fixarBarra -and (Test-Path $menu)) {
    try {
        $sh = New-Object -ComObject Shell.Application
        $item = $sh.Namespace((Split-Path $menu)).ParseName((Split-Path $menu -Leaf))
        $verbo = $item.Verbs() | Where-Object { ($_.Name -replace '&', '') -match 'barra de tarefas|taskbar' } | Select-Object -First 1
        if ($verbo -and ($verbo.Name -replace '&', '') -notmatch 'Desafixar|Unpin') { $verbo.DoIt(); $fixouBarra = $true; Ok 'fixado na barra de tarefas' }
    } catch { }
    if (-not $fixouBarra) { Info 'para fixar na barra: menu Iniciar > Estúdio de Vídeo > botão direito > Fixar na barra de tarefas' }
}

# ==================================================================== 9. esperando os modelos terminarem (com progresso)
Etapa 70 'Terminando os downloads dos modelos'
$ultimo = Get-Date
$hf = Join-Path $env:USERPROFILE '.cache\huggingface'
while (($pFala -and -not $pFala.HasExited) -or ($pIA -and -not $pIA.HasExited)) {
    Start-Sleep -Seconds 1
    if (((Get-Date) - $ultimo).TotalSeconds -ge 6) {
        $ultimo = Get-Date
        $partes = @()
        if ($pIA -and -not $pIA.HasExited -and (Test-Path $logIA)) {
            $txt = [IO.File]::ReadAllText($logIA) -replace "`r", "`n"
            $m = [regex]::Matches($txt, '(\d{1,3})%')
            $pct = if ($m.Count) { [int]$m[$m.Count - 1].Groups[1].Value } else { 0 }
            $partes += "IA $pct%"
            Progresso ([math]::Min(94, 70 + [int]($pct * 0.24)))
        }
        if ($pFala -and -not $pFala.HasExited -and (Test-Path $hf)) {
            $tam = (Get-ChildItem $hf -Recurse -File -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
            $partes += "modelo de fala $(MB $tam) MB"
        }
        if ($partes.Count) { Info ("baixando: " + ($partes -join ' · ')) }
    }
}
if ($pFala) { if ($pFala.ExitCode -eq 0) { Ok "modelo de fala pronto ($modeloFala)" } else { Aviso 'o modelo de fala será baixado no primeiro vídeo' } }
if ($querIA -and $modeloIA) {
    $jaTem = & $ollama list 2>$null | Select-String -SimpleMatch $modeloIA
    if ($jaTem) {
        $cfg = Ler-Texto $cfgArq
        $cfg = [regex]::Replace($cfg, '(?m)^(\s*modelo_local:\s*)\S+', ('${1}' + $modeloIA))
        $cfg = [regex]::Replace($cfg, '(?m)^(\s*provedor:\s*)\S+', '${1}local')
        Gravar-Texto $cfgArq $cfg
        Ok "IA local pronta ($modeloIA)"
    } else { Falha 'Não consegui baixar o modelo de IA (rode o instalador de novo; ele continua de onde parou).' }
}

# ==================================================================== 10. conferência final
Etapa 96 'Conferindo se está tudo funcionando'
if (Test-Path $ffExe) {
    $filtros = & $ffExe -hide_banner -filters 2>$null | Out-String
    if ($filtros -match '\sass\s' -and $filtros -match '\szscale\s') { Ok 'FFmpeg com legendas e conversão de cores' } else { Falha 'FFmpeg sem suporte a legendas.' }
    if ($gpu) {
        & $ffExe -hide_banner -loglevel error -f lavfi -i color=c=black:s=256x256:d=0.2 -c:v h264_nvenc -f null - 2>$null
        if ($LASTEXITCODE -eq 0) { Ok 'exportação acelerada pela placa NVIDIA' } else { Aviso 'exportação pelo processador (atualize o driver NVIDIA para acelerar)' }
    }
}
if (Test-Path $venvPy) {
    & $venvPy -c "import faster_whisper, cv2, yaml, numpy; from editor import estudio" 2>$null
    if ($LASTEXITCODE -eq 0) { Ok 'Estúdio pronto para abrir' } else { Falha 'o Estúdio não carregou (detalhes em instalacao.log)' }
}
Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue

$min = [math]::Round(((Get-Date) - $inicio).TotalMinutes, 1)
Progresso 100
if ($Problemas.Count -eq 0) {
    Ok "Instalação concluída em $min min."
    if ($abrirAgora -and (Test-Path $pyw)) { Start-Process -FilePath $pyw -ArgumentList '-m editor' -WorkingDirectory $Raiz }
} else {
    Aviso "Terminou em $min min, com pendências:"
    foreach ($p in $Problemas) { Aviso " - $p" }
    Aviso 'Rode o instalador de novo: ele continua de onde parou.'
}
$codigo = if ($Problemas.Count -gt 0) { 1 } else { 0 }
if ($Status) { try { [IO.File]::AppendAllText($Status, "@@FIM $codigo`r`n", $UTF16) } catch {} }
if ($Janela -or -not $Silencioso) {
    if ($Problemas.Count -gt 0) { Read-Host '  Aperte Enter para fechar' | Out-Null } else { Start-Sleep -Seconds 3 }
}
exit $codigo
