"""Janela própria do Estúdio (WebView2, o mesmo motor do Edge, mas sem abrir o Edge).

Roda num processo separado:  pythonw -m editor.janela <porta>
- tem o ícone do Estúdio na barra de tarefas e dá para "Fixar na barra de tarefas"
  (identidade própria do Windows: AppUserModelID + comando para reabrir);
- se o WebView2/pywebview não estiver disponível, cai no jeito antigo (Edge em modo app).
"""
from __future__ import annotations

import ctypes
import hashlib
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
AUMID = "EstudioDeVideo.Editor"
NOME = "Estúdio de Vídeo"
ICONE = RAIZ / "estudio.ico"


# ------------------------------------------------------------------ identidade no Windows (barra de tarefas)
class _GUID(ctypes.Structure):
    _fields_ = [("d1", ctypes.c_uint32), ("d2", ctypes.c_uint16), ("d3", ctypes.c_uint16), ("d4", ctypes.c_ubyte * 8)]


def _guid(s: str) -> _GUID:
    import uuid
    u = uuid.UUID(s)
    g = _GUID()
    g.d1, g.d2, g.d3 = u.fields[0], u.fields[1], u.fields[2]
    for i, b in enumerate(u.bytes[8:]):
        g.d4[i] = b
    return g


class _PKEY(ctypes.Structure):
    _fields_ = [("fmtid", _GUID), ("pid", ctypes.c_uint32)]


class _PROPVARIANT(ctypes.Structure):
    _fields_ = [("vt", ctypes.c_ushort), ("r1", ctypes.c_ushort), ("r2", ctypes.c_ushort), ("r3", ctypes.c_ushort),
                ("p", ctypes.c_void_p), ("p2", ctypes.c_void_p)]


_FMT_AUMID = "9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"
_IID_PROPSTORE = "886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"
PK_ID, PK_RELAUNCH_CMD, PK_RELAUNCH_ICON, PK_RELAUNCH_NOME = 5, 2, 3, 4


def _gravar_propriedades(store_ptr: ctypes.c_void_p, valores: dict[int, str]) -> None:
    """IPropertyStore::SetValue + Commit, chamando a tabela de funções do COM direto."""
    vtbl = ctypes.cast(ctypes.cast(store_ptr, ctypes.POINTER(ctypes.c_void_p))[0], ctypes.POINTER(ctypes.c_void_p))
    set_value = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.POINTER(_PKEY), ctypes.POINTER(_PROPVARIANT))(vtbl[6])
    commit = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p)(vtbl[7])
    release = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(vtbl[2])
    guardados = []
    try:
        for pid, texto in valores.items():
            k = _PKEY(_guid(_FMT_AUMID), pid)
            buf = ctypes.create_unicode_buffer(texto)
            guardados.append(buf)
            pv = _PROPVARIANT(vt=31, p=ctypes.cast(buf, ctypes.c_void_p))   # VT_LPWSTR
            set_value(store_ptr, ctypes.byref(k), ctypes.byref(pv))
        commit(store_ptr)
    finally:
        release(store_ptr)


def _comando_reabrir() -> str:
    exe = Path(sys.executable)
    pyw = exe.parent / "pythonw.exe"
    return f'"{pyw if pyw.exists() else exe}" -m editor'


def marcar_atalhos() -> None:
    """Põe a mesma identidade nos atalhos do Menu Iniciar e da Área de Trabalho (uma vez, sem custo depois)."""
    if sys.platform != "win32":
        return
    try:
        shell32 = ctypes.windll.shell32
        ole32 = ctypes.windll.ole32
        ole32.CoInitialize(None)
        pastas = []
        for csidl in (0x0002, 0x0010):   # Programs (Menu Iniciar), Desktop
            buf = ctypes.create_unicode_buffer(260)
            if shell32.SHGetFolderPathW(None, csidl, None, 0, buf) == 0:
                pastas.append(Path(buf.value))
        for pasta in pastas:
            lnk = pasta / f"{NOME}.lnk"
            if not lnk.exists():
                continue
            marca = RAIZ / ".janela_webview" / f"atalho_{hashlib.md5(str(lnk).encode()).hexdigest()[:10]}.ok"
            if marca.exists():
                continue
            store = ctypes.c_void_p()
            iid = _guid(_IID_PROPSTORE)
            hr = shell32.SHGetPropertyStoreFromParsingName(ctypes.c_wchar_p(str(lnk)), None, 2,
                                                           ctypes.byref(iid), ctypes.byref(store))
            if hr == 0 and store.value:
                _gravar_propriedades(store, {PK_ID: AUMID})
                marca.parent.mkdir(parents=True, exist_ok=True)
                marca.write_text("ok")
    except Exception:  # noqa: BLE001
        pass


def identidade_janela(hwnd: int) -> None:
    """Na própria janela: identidade + como reabrir (é isso que o 'Fixar na barra de tarefas' usa)."""
    if sys.platform != "win32" or not hwnd:
        return
    try:
        store = ctypes.c_void_p()
        iid = _guid(_IID_PROPSTORE)
        hr = ctypes.windll.shell32.SHGetPropertyStoreForWindow(ctypes.c_void_p(hwnd), ctypes.byref(iid), ctypes.byref(store))
        if hr == 0 and store.value:
            _gravar_propriedades(store, {PK_ID: AUMID, PK_RELAUNCH_CMD: _comando_reabrir(),
                                         PK_RELAUNCH_ICON: f"{ICONE},0", PK_RELAUNCH_NOME: NOME})
    except Exception:  # noqa: BLE001
        pass


# ------------------------------------------------------------------ janela
def _edge_antigo(url: str) -> None:
    from .estudio import _navegador_app
    nav = _navegador_app()
    if nav:
        subprocess.Popen([nav, f"--app={url}", "--window-size=1500,920", f"--user-data-dir={RAIZ / '.janela'}",
                          "--no-first-run", "--disable-features=Translate"])
    else:
        import webbrowser
        webbrowser.open(url)


def _avisar_servidor(url: str, erro: str) -> None:
    try:
        import json
        urllib.request.urlopen(urllib.request.Request(f"{url}api/janela", data=json.dumps({"erro": erro}).encode(),
                                                      headers={"Content-Type": "application/json"}), timeout=3).read()
    except Exception:  # noqa: BLE001
        pass


def _registrar(msg: str) -> None:
    try:
        with open(RAIZ / "erros.log", "a", encoding="utf-8") as f:
            f.write(f"===== {time.strftime('%Y-%m-%d %H:%M:%S')} · janela · {msg}\n\n")
    except OSError:
        pass


def main() -> None:
    porta = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    url = f"http://127.0.0.1:{porta}/"
    pagina = url + (f"?j={sys.argv[2]}" if len(sys.argv) > 2 and sys.argv[2] else "")
    if sys.platform == "win32":
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(ctypes.c_wchar_p(AUMID))
        except Exception:  # noqa: BLE001
            pass
        marcar_atalhos()
    try:
        import webview  # pywebview (WebView2 no Windows)
    except Exception as e:  # noqa: BLE001
        _registrar(f"pywebview indisponível ({e}); usando o Edge em modo app")
        _avisar_servidor(url, f"o componente da janela própria não carregou ({str(e)[:150]})")
        _edge_antigo(pagina)
        return

    janela = None

    class Api:
        def fechar(self):
            try:
                janela.destroy()
            except Exception:  # noqa: BLE001
                pass

        def focar(self):
            try:
                janela.restore()
                janela.show()
                janela.on_top = True
                time.sleep(0.15)
                janela.on_top = False
            except Exception:  # noqa: BLE001
                pass

    janela = webview.create_window(NOME, pagina, width=1500, height=920, min_size=(1000, 650), js_api=Api(),
                                   maximized=True, background_color="#0c0c0e", text_select=True)

    def ao_mostrar():
        try:   # identidade na barra de tarefas (WinForms: na thread da interface)
            from System import Action  # type: ignore
            form = janela.native
            form.Invoke(Action(lambda: identidade_janela(int(form.Handle.ToInt64()))))
        except Exception as e:  # noqa: BLE001
            _registrar(f"ícone da janela: {e}")
        try:   # avisa o servidor que a janela existe (para não abrir outra)
            urllib.request.urlopen(urllib.request.Request(f"{url}api/janela", data=f'{{"pid": {os.getpid()}}}'.encode(),
                                                          headers={"Content-Type": "application/json"}), timeout=3).read()
        except Exception:  # noqa: BLE001
            pass

    janela.events.shown += ao_mostrar
    try:
        webview.start(private_mode=False, storage_path=str(RAIZ / ".janela_webview"),
                      icon=str(ICONE) if ICONE.exists() else None)
    except Exception as e:  # noqa: BLE001
        _registrar(f"WebView2 não abriu ({e}); usando o Edge em modo app")
        _avisar_servidor(url, f"a janela própria não abriu ({str(e)[:150]})")
        _edge_antigo(pagina)


if __name__ == "__main__":
    main()
