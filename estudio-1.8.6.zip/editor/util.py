"""Utilitários: configuração, ffmpeg/ffprobe, mensagens."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

import yaml

RAIZ = Path(__file__).resolve().parent.parent

if sys.platform == "win32":
    # Aberto pelo ícone (sem janela preta), cada ffmpeg abriria uma janela piscando: isto evita.
    _PopenOriginal = subprocess.Popen

    class _PopenSemJanela(_PopenOriginal):  # type: ignore[misc, valid-type]
        def __init__(self, *a, **k):
            k.setdefault("creationflags", 0x08000000)  # CREATE_NO_WINDOW
            super().__init__(*a, **k)

    subprocess.Popen = _PopenSemJanela  # type: ignore[misc]


# ---------------------------------------------------------------- mensagens
def info(msg: str) -> None:
    print(f"  {msg}", flush=True)


# O editor no navegador se registra aqui para mostrar o progresso da geração.
OUVINTES: list = []


def etapa(n: int, total: int, msg: str) -> None:
    print(f"\n[{n}/{total}] {msg}", flush=True)
    for f in OUVINTES:
        f("etapa", msg, None)


def aviso(msg: str) -> None:
    print(f"  ! {msg}", flush=True)


def barra(frac: float, largura: int = 30, sufixo: str = "") -> None:
    frac = max(0.0, min(1.0, frac))
    for f in OUVINTES:
        f("barra", sufixo, frac)
    cheio = int(frac * largura)
    sys.stdout.write(f"\r  [{'#' * cheio}{'.' * (largura - cheio)}] {frac * 100:5.1f}% {sufixo}   ")
    sys.stdout.flush()
    if frac >= 1.0:
        sys.stdout.write("\n")


# ---------------------------------------------------------------- config
def carregar_config() -> dict:
    with open(RAIZ / "config.yaml", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}
    carregar_env()
    return cfg


def carregar_env() -> None:
    env = RAIZ / ".env"
    if not env.exists():
        return
    for linha in env.read_text(encoding="utf-8").splitlines():
        linha = linha.strip()
        if not linha or linha.startswith("#") or "=" not in linha:
            continue
        k, v = linha.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"'))


def salvar_env(chave: str, valor: str) -> None:
    """Grava (ou troca) uma linha CHAVE=valor no arquivo .env e já vale para esta sessão."""
    env = RAIZ / ".env"
    linhas = env.read_text(encoding="utf-8").splitlines() if env.exists() else []
    linhas = [ln for ln in linhas if not ln.strip().startswith(chave + "=")]
    if valor:
        linhas.append(f"{chave}={valor}")
    env.write_text("\n".join(linhas) + "\n", encoding="utf-8")
    if valor:
        os.environ[chave] = valor
    else:
        os.environ.pop(chave, None)


def caminho_cfg(valor: str | None) -> Path | None:
    """Resolve um caminho do config (relativo à pasta do programa)."""
    if not valor:
        return None
    p = Path(valor)
    if not p.is_absolute():
        p = RAIZ / p
    return p


# ---------------------------------------------------------------- json
def salvar_json(caminho: Path, dados) -> None:
    caminho.parent.mkdir(parents=True, exist_ok=True)
    tmp = caminho.with_suffix(".tmp")
    tmp.write_text(json.dumps(dados, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(caminho)


def ler_json(caminho: Path):
    return json.loads(caminho.read_text(encoding="utf-8"))


# ---------------------------------------------------------------- ffmpeg
_FFMPEG_LOCAL = RAIZ / "ffmpeg" / "bin"   # cópia instalada pelo INSTALAR.bat (não depende do PATH do Windows)
if _FFMPEG_LOCAL.is_dir():
    os.environ["PATH"] = str(_FFMPEG_LOCAL) + os.pathsep + os.environ.get("PATH", "")


def exigir_ffmpeg() -> None:
    for prog in ("ffmpeg", "ffprobe"):
        if not shutil.which(prog):
            raise SystemExit(f"'{prog}' não encontrado. Rode o INSTALAR.bat de novo.")


def sondar(video: Path, exigir_audio: bool = True) -> dict:
    """Informações do vídeo: largura/altura já corrigidas pela rotação, fps, duração."""
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(video)],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
    )
    if out.returncode != 0:
        raise SystemExit(f"Não consegui ler o vídeo: {out.stderr.strip()}")
    d = json.loads(out.stdout)
    v = next((s for s in d["streams"] if s.get("codec_type") == "video"), None)
    a = next((s for s in d["streams"] if s.get("codec_type") == "audio"), None)
    if v is None:
        raise SystemExit("O arquivo não tem vídeo.")
    if a is None and exigir_audio:
        raise SystemExit("O arquivo não tem áudio — não há fala para editar.")
    w, h = int(v["width"]), int(v["height"])
    rot = 0
    for sd in v.get("side_data_list", []) or []:
        if "rotation" in sd:
            rot = int(float(sd["rotation"]))
    rot = int(v.get("tags", {}).get("rotate", rot))
    if abs(rot) % 180 == 90:
        w, h = h, w
    num, den = (v.get("avg_frame_rate") or v.get("r_frame_rate") or "30/1").split("/")
    fps = float(num) / float(den) if float(den) else 30.0
    if not 10 <= fps <= 121:
        fps = 30.0
    fps = padronizar_fps(fps)
    dur = float(d["format"].get("duration") or v.get("duration") or 0)
    trc = (v.get("color_transfer") or "").lower()
    tags = {k.lower(): val for k, val in (d["format"].get("tags") or {}).items()}
    tags.update({k.lower(): val for k, val in (v.get("tags") or {}).items() if k.lower() not in tags})
    return {"largura": w, "altura": h, "fps": fps, "duracao": dur,
            "vertical": h > w, "proporcao": w / h,
            "hdr": trc in ("arib-std-b67", "smpte2084"),       # iPhone/Android gravando em HDR
            "dez_bits": "10" in (v.get("pix_fmt") or ""),
            "tem_audio": a is not None,
            "data_gravacao": tags.get("com.apple.quicktime.creationdate") or tags.get("creation_time")}


def padronizar_fps(fps: float) -> float:
    """Encaixa na taxa padrão mais próxima (sem trocar 29,97 por 30: preserva a fluidez original)."""
    alvos = (24000 / 1001, 24, 25, 30000 / 1001, 30, 50, 60000 / 1001, 60, 120)
    melhor = min(alvos, key=lambda a: abs(fps - a))
    return float(melhor) if abs(fps - melhor) < 0.02 * melhor else float(round(fps))


def rodar_ffmpeg(args: list[str], duracao: float | None = None, rotulo: str = "",
                 cwd: Path | None = None) -> None:
    """Roda ffmpeg mostrando barra de progresso. Levanta erro com o log se falhar."""
    cmd = ["ffmpeg", "-hide_banner", "-y", "-nostats", "-loglevel", "error"]
    if duracao:
        cmd += ["-progress", "pipe:1"]
    cmd += args
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            text=True, encoding="utf-8", errors="replace", cwd=cwd)
    erros: list[str] = []

    import threading

    def ler_erros():
        for l in proc.stderr:
            erros.append(l)

    t = threading.Thread(target=ler_erros, daemon=True)
    t.start()
    ultimo = 0.0
    if duracao:
        for linha in proc.stdout:
            m = re.match(r"out_time_us=(\d+)", linha)
            if m and time.time() - ultimo > 0.4:
                ultimo = time.time()
                barra(int(m.group(1)) / 1e6 / duracao, sufixo=rotulo)
    proc.wait()
    t.join(timeout=2)
    if proc.returncode != 0:
        raise RuntimeError("ffmpeg falhou:\n" + "".join(erros[-25:]) + "\nComando: " + " ".join(cmd))
    if duracao:
        barra(1.0, sufixo=rotulo)


_ENCODER_CACHE: dict = {}


def escolher_encoder(cfg: dict) -> str:
    """'nvenc' se a placa NVIDIA funciona no ffmpeg, senão 'cpu'."""
    pref = str(cfg.get("encoder", "auto")).lower()
    if pref == "cpu":
        return "cpu"
    if "r" in _ENCODER_CACHE:
        return _ENCODER_CACHE["r"]

    def funciona(codec: str) -> bool:
        return subprocess.run(
            ["ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i",
             "color=c=black:s=256x256:d=0.2", "-c:v", codec, "-f", "null", "-"],
            capture_output=True,
        ).returncode == 0

    # placa de vídeo: NVIDIA (NVENC), Intel (Quick Sync) ou AMD (AMF); senão, o processador
    ordem = {"nvenc": ["nvenc"], "qsv": ["qsv"], "amf": ["amf"]}.get(pref, ["nvenc", "qsv", "amf"])
    r = next((e for e in ordem if funciona(f"h264_{e}")), "cpu")
    if pref not in ("auto", r):
        aviso(f"Aceleração '{pref}' indisponível — usando {r}.")
    _ENCODER_CACHE["r"] = r
    return r


COR_BT709 = ["-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709",
             "-color_range", "tv"]


def args_video(encoder: str, qualidade: str = "final", altura: int = 1920, fps: float = 30) -> list[str]:
    """Parâmetros de codificação.
    intermediario: sem perdas (nada se perde entre os cortes e a versão final)
    final:         alta qualidade para publicação (taxa no topo do que as redes aceitam)
    leve:          WhatsApp / prévia
    """
    gop = str(int(round(fps * 2)))  # quadro-chave a cada 2 s: o que YouTube/Instagram recomendam
    lado = altura
    if qualidade == "intermediario":
        if encoder == "nvenc":
            return ["-c:v", "h264_nvenc", "-preset", "p4", "-tune", "lossless", "-pix_fmt", "yuv420p"]
        return ["-c:v", "libx264", "-preset", "ultrafast", "-qp", "0", "-pix_fmt", "yuv420p"]
    if qualidade == "leve":
        taxa, maximo = "2500k", "4000k"
        cq, crf = "24", "23"
    else:
        # 4K ~45 Mbps · 1080p ~16 Mbps (teto); a qualidade constante decide abaixo disso
        taxa, maximo = ("30M", "50M") if lado >= 2160 else ("12M", "20M")
        cq, crf = "17", "16"
    if encoder == "qsv":       # Intel Quick Sync
        a = ["-c:v", "h264_qsv", "-preset", "veryslow", "-global_quality", cq, "-look_ahead", "1",
             "-profile:v", "high", "-g", gop]
    elif encoder == "amf":     # AMD
        qi, qp = (int(cq) + 1, int(cq) + 3)
        a = ["-c:v", "h264_amf", "-quality", "quality", "-rc", "cqp", "-qp_i", str(qi), "-qp_p", str(qp),
             "-qp_b", str(qp + 2), "-profile:v", "high", "-g", gop]
    elif encoder == "nvenc":
        a = ["-c:v", "h264_nvenc", "-preset", "p7", "-tune", "hq", "-rc", "vbr", "-cq", cq,
             "-b:v", taxa, "-maxrate", maximo, "-bufsize", maximo, "-multipass", "fullres",
             "-spatial-aq", "1", "-temporal-aq", "1", "-aq-strength", "8", "-rc-lookahead", "32",
             "-bf", "3", "-profile:v", "high", "-g", gop]
    else:
        a = ["-c:v", "libx264", "-preset", "slow", "-crf", crf, "-maxrate", maximo,
             "-bufsize", maximo, "-tune", "film", "-bf", "3", "-profile:v", "high", "-g", gop]
    if lado >= 2160:
        a += ["-level:v", "5.2"]
    return a + ["-pix_fmt", "yuv420p", *COR_BT709]


def fmt_tempo(seg: float) -> str:
    seg = max(0, seg)
    m, s = divmod(int(round(seg)), 60)
    h, m = divmod(m, 60)
    return f"{h}h{m:02d}m{s:02d}s" if h else f"{m}m{s:02d}s"


def mandar_para_lixeira(p: Path) -> str:
    """Manda um arquivo ou pasta para a Lixeira do Windows (dá para recuperar). Fora do Windows: pasta .lixeira."""
    import shutil
    import sys
    p = Path(p)
    if not p.exists():
        return ""
    if sys.platform == "win32":
        import ctypes
        from ctypes import wintypes

        class SHFILEOPSTRUCTW(ctypes.Structure):
            _fields_ = [("hwnd", wintypes.HWND), ("wFunc", wintypes.UINT), ("pFrom", wintypes.LPCWSTR),
                        ("pTo", wintypes.LPCWSTR), ("fFlags", ctypes.c_uint16), ("fAnyOperationsAborted", wintypes.BOOL),
                        ("hNameMappings", ctypes.c_void_p), ("lpszProgressTitle", wintypes.LPCWSTR)]
        op = SHFILEOPSTRUCTW(None, 3, str(p.resolve()) + "\0", None, 0x40 | 0x10 | 0x04 | 0x400, False, None, None)
        if ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op)) == 0 and not p.exists():
            return "Lixeira"
    destino = RAIZ / ".lixeira" / p.name
    destino.parent.mkdir(parents=True, exist_ok=True)
    if destino.exists():
        destino = destino.with_name(f"{destino.stem}_{int(__import__('time').time())}{destino.suffix}")
    shutil.move(str(p), str(destino))
    return str(destino.parent)


def tamanho_pasta(p: Path) -> int:
    total = 0
    for f in Path(p).rglob("*"):
        try:
            if f.is_file():
                total += f.stat().st_size
        except OSError:
            pass
    return total

