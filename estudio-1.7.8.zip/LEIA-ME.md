# Estúdio de Vídeo — edição automática

Você solta o vídeo cru e o Estúdio faz o resto:

- **Limpa a fala:** corta erros, repetições, vícios de linguagem e pausas.
- **Legenda:** coloca legenda palavra a palavra.
- **Junta extras:** imagens de apoio, outras partes da fala, abertura e encerramento, tudo harmonizado.
- **Editor visual:** abre um editor parecido com o **CapCut** para você ajustar.
- **Exporta:** em alta qualidade para cada rede.
- **Organiza:** arquiva tudo em pastas **Tema › Mês › Título**.

A inteligência artificial é **local e gratuita**: Ollama + Gemma, rodando no seu computador. Não tem conta, não tem chave e nada vai para a internet.

## Instalação (uma vez só)

1. Dê dois cliques em **EstudioDeVideo-Instalador.exe**. Se o Windows mostrar "O Windows protegeu o computador", clique em **Mais informações → Executar assim mesmo**. O aviso aparece porque o instalador não tem uma assinatura digital paga.
2. Siga o assistente:
   - **Componentes:** IA local gratuita, fixar na barra de tarefas, ligar junto com o Windows.
   - **Pasta do programa:** o padrão não exige senha de administrador.
   - **Pastas dos vídeos:** a entrada, onde você solta os vídeos crus, e a biblioteca, onde eles ficam organizados.
3. Clique em **Instalar** e acompanhe o progresso. Leva de 15 a 40 minutos, conforme a internet:
   - o instalador baixa o Python, o FFmpeg, as bibliotecas e o modelo de transcrição;
   - baixa também o Ollama e o modelo Gemma do tamanho certo para a sua placa;
   - cria o ícone **Estúdio de Vídeo** na área de trabalho e no menu Iniciar.
4. No final, marque **"Abrir o Estúdio de Vídeo agora"**.

**Se algo falhar:** rode o instalador de novo, que ele continua de onde parou. O registro fica em `instalacao.log`, na pasta do programa.

**Para desinstalar:** use Configurações › Aplicativos › Estúdio de Vídeo. Seus vídeos e a biblioteca não são apagados.

**Barra de tarefas:** o Windows não deixa programas se fixarem sozinhos. Se o instalador não conseguir, abra o menu Iniciar, procure **Estúdio de Vídeo**, clique com o botão direito e escolha **Fixar na barra de tarefas**.

(Opcional) Coloque na pasta do editor:
- `logo\logo.png`: seu logo;
- `musica\`: músicas de fundo em .mp3;
- `vinhetas\`: abertura e encerramento. Também dá para enviar pelo Estúdio.

## Uso no dia a dia

1. Abra o **Estúdio de Vídeo**. Se você escolheu ligar junto com o Windows, ele já está rodando e a janela abre sozinha quando um vídeo fica pronto para revisar.
2. Coloque os vídeos crus de um destes jeitos:
   - arraste para dentro da janela do Estúdio;
   - clique em **＋ Importar vídeo**;
   - solte na pasta **Videos para editar**.
3. A **tela inicial** mostra cada vídeo com o progresso: na fila → preparando → para revisar → exportando → pronto.
4. Clique no vídeo para abrir o **editor**. Não quer esperar? Use **▶ Importar e abrir já** (ou **▶ Abrir agora** no cartão): o editor abre com o vídeo enquanto a transcrição roda, e a legenda e os cortes aparecem sozinhos quando ela termina.
5. Ajuste o que quiser e clique em **⤓ Exportar**: escolha **em quais formatos** (só Reels, só YouTube, todos…). Confira em **Prontos** e depois clique em **Arquivar**.

O Estúdio faz um trabalho pesado de cada vez (preparar, exportar, arquivar), para a placa de vídeo não ficar disputada. Enquanto um vídeo exporta, você já pode editar o próximo.

## O editor

```
┌ ← Projetos │ Título │ Tema ─────────────────────────────── Exportar ┐
│ Ferramentas │ Painel        │         MONITOR (prévia)   │ Inspetor │
│ Mídia       │ (muda com a   │  9:16 · 16:9 · 1:1         │ (proprie-│
│ Texto       │  ferramenta)  │  legenda, logo e imagens   │  dades do│
│ Legendas    │               │  ao vivo                   │  item    │
│ Estilo …    │               │  ⏮  ▶  ⏭                  │  marcado)│
├─────────────┴───────────────┴────────────────────────────┴──────────┤
│ ↶ ↷ │ ✂ Dividir  🗑 Excluir  [ Início  ] Fim │ Pular cortes │ zoom   │
│ Legenda  ▭▭ ▭▭▭ ▭▭  ▭▭▭                                            │
│ Imagens        ▭▭▭▭▭           ▭▭▭▭                                │
│ Vídeo    ▭▭▭▭▭▭▭▭▭|▭▭▭▭▭▭|▭▭▭▭▭▭▭▭▭▭  (miniaturas)                   │
│ Voz      ▁▃▅▇▅▃▁▂▅▇▆▃▁ (forma de onda)                              │
│ Música   ▭▭▭▭▭▭▭▭▭▭▭▭▭▭▭▭▭▭▭▭▭▭▭▭▭                                  │
└──────────────────────────────────────────────────────────────────────┘
```

**Linha do tempo**
- **Trilha Vídeo:** mostra cada pedaço que fica. Para estender ou encurtar um pedaço, arraste a borda dele; o corte acompanha as palavras.
- **Trilha Imagens:** arraste uma imagem de apoio para mudar o momento em que ela entra, ou puxe a borda direita para mudar a duração. Para adicionar, arraste uma mídia do painel para esta trilha.
- **Trilha Legenda:** clique numa legenda para corrigir o texto ou começar uma nova legenda numa palavra. Arraste a legenda para adiantar ou atrasar, ou puxe as bordas ‹ › para ela aparecer antes ou ficar mais tempo na tela. Quando você estica ou encurta um pedaço do vídeo, as legendas acompanham sozinhas. O botão **↺ voltar ao tempo da fala** desfaz o ajuste.
- **Trilha Música:** arraste a música para ela começar em outro momento e puxe as bordas ‹ › para encurtar (a borda esquerda pula o começo da música). O fade de entrada e saída acompanha.
- **Lugares para imagem (tracejados):** também dá para arrastar e puxar as bordas.
- **No vídeo (prévia):** passe o mouse na legenda e puxe a bolinha do canto para aumentar ou diminuir a letra (vale para o vídeo todo). Textos, stickers, imagens e vídeos das trilhas também têm a bolinha no canto. Arrastar o meio continua mudando a posição.
- **Dividir (S) + Excluir (Delete):** remove qualquer pedaço. Também dá para marcar **[ Início (I)** e **] Fim (O)** e apertar Delete.
- **Desfazer/Refazer:** Ctrl+Z e Ctrl+Shift+Z.
- **Zoom:** ↔ largura (Ctrl + roda do mouse) e ↕ altura das linhas (Alt + roda do mouse).
- **Prévia (embaixo do vídeo):** **👁 Ver os cortes** toca tudo, e o que vai ser cortado aparece com borda vermelha e o botão **Manter**. **✂ Como vai ficar** toca pulando os cortes.

**Ferramentas (barra à esquerda)**
- **Mídia:** importe imagens de apoio e fotos. A IA olha cada uma, descreve o que mostra e encaixa no momento certo da fala. Aqui também ficam as partes da fala e a abertura e o encerramento.
- **Texto:** edite pela transcrição. O texto riscado sai. **Clique numa palavra** para tirar ou devolver só ela (mesmo dentro de uma repetição ou vício marcado), ou arraste sobre um trecho para cortar ou manter tudo. Ctrl+clique só leva o vídeo até a palavra.
- **Estilo (legenda):**
  - **Galeria de modelos** com prévia: Clássico, Caixa verde, Caixa roxa, Impacto, Uma palavra, Neon, Máquina, Frase, Quadrinhos, Divertido, Discreto, Claro.
  - **Tipos:** karaokê (a palavra falada muda de cor), caixa colorida na palavra, uma palavra por vez, frase inteira.
  - **Animações:** saltar, deslizar, surgir, máquina de escrever. **Fundos:** contorno, sombra, neon, tarja.
  - **9 fontes** já incluídas (Montserrat, Bebas Neue, Anton, Poppins, Oswald, Archivo Black, Bangers, Luckiest Guy, Roboto) e **+ Enviar uma fonte minha** (.ttf/.otf).
  - **Palavras-chave coloridas e emojis** escolhidos pela IA (ou por você).
  - **Meus modelos:** salve o estilo atual; ★ marca o modelo usado nos próximos vídeos.
  - **🎯 Copiar o estilo de um vídeo:** envie um vídeo com a legenda que você gosta e a IA cria um modelo parecido.
  - **Arraste a legenda** direto no vídeo para mudar a posição.
  - **Só uma legenda diferente:** clique nela na linha do tempo e mude tipo, animação, cores, palavra-chave ou emoji só dela.
- **＋ e − ao lado das trilhas** (ou as teclas **+** e **−**): **＋** cria uma nova linha de edição (vídeo, imagem/sticker, áudio ou texto); **−** apaga a linha selecionada (clique no nome dela para selecionar; duplo clique renomeia). Ctrl+Z desfaz.
- **🎵 Importar música:** no painel Áudio (ou em Sons). A música vai para a pasta `musica` e já entra como música de fundo.
- **＋ Trilha (na linha do tempo):** acrescenta trilhas de **vídeo**, **imagem/sticker**, **áudio** ou **texto**, quantas quiser. Cada trilha pode ser silenciada (🔈), escondida (👁), renomeada (clique no nome) ou apagada (✕). Arraste os itens para mudar o momento e puxe a borda direita para mudar a duração. A trilha mais acima é a camada mais à frente.
- **Itens por cima do vídeo:** no monitor, arraste para posicionar e use a roda do mouse para mudar o tamanho. À direita: tela cheia, girar, opacidade, espelhar, tirar fundo verde (chroma), volume, entrada e saída animadas, duplicar.
- **Mídia → ⧉:** põe uma imagem ou vídeo seu numa trilha por cima (janela pequena, tela dividida…). O ＋ continua pedindo para a IA encaixar em tela cheia.
- **Textos:** títulos prontos (caixa, neon, quadrinhos, máquina de escrever, nome/cargo…) numa trilha de texto.
- **Stickers:** 33 originais (chamadas como "Inscreva-se", "Link na bio", setas, círculo de destaque, balões…), mais de 100 emojis e os **animados mais populares** (Google Noto, baixados na hora). **＋ Adicionar meus stickers** guarda PNG, GIF ou WebP na sua coleção.
- **Sons:** 26 efeitos originais (boing, whoosh, pop, ba-dum-tss, buzzer, tambor de suspense, dinheiro, riser…). **Buscar na internet** encontra sons livres (risada, aplausos, cartoon, meme…) e guarda na sua coleção, com os créditos. **＋ Adicionar meus sons** para os seus arquivos.
- **Ajustes:** filtros prontos (vivo, quente, frio, cinema, retrô, P&B, suave), brilho, contraste, saturação, temperatura, vinheta, nitidez, **velocidade** (0,5× a 2×), espelhar, **transição nos cortes** (flash branco ou piscada preta), **efeitos de voz** (grave, aguda, esquilo, robô, eco, rádio, caverna) e volume da voz.
- **⚡ Edição rápida (barra de cima):** um clique faz tudo: corta para caber no tempo alvo, cria o gancho de abertura e as ênfases e escolhe palavras-chave e emojis. Depois é só revisar em "👁 Ver os cortes".
- **Tempo do vídeo (painel Exportar):** mínimo e máximo (padrão 30–45 s). Se passar do máximo, o Estúdio corta sozinho as frases menos importantes (nunca a primeira nem a última) e você revisa com o botão Manter. O tempo embaixo do vídeo fica verde dentro do alvo e vermelho fora.
- **Vozes:** **🔍 Separar as vozes** descobre quem fala o quê (diga quantos personagens são) e mostra a foto de cada personagem, tirada de um momento em que ele fala; **👥 Ver os personagens em tela grande** abre todos lado a lado. Escolher uma voz já toca um trecho com ela. Cada personagem ganha uma cor nas legendas e um efeito de voz próprio (esquilo, robô, grave…). Para corrigir, clique numa legenda e escolha quem fala.
- **Limpeza do som:** desligada, equilibrada (natural) ou **isolar só a voz** (tira ruído, ambiente e eco e silencia entre as falas).
- **Prévia igual ao vídeo final:** a prévia toca o som já tratado (limpeza e efeitos de voz de cada personagem), a música de fundo abaixando quando alguém fala, a abertura e o encerramento, o flash nos cortes, o zoom das ênfases, filtros, textos e stickers. **Tela cheia** (⛶ ou tecla F) mostra tudo isso também.
- **Ganchos:**
  - **Gancho de abertura:** a IA sugere frases para aparecer escritas nos 3 primeiros segundos; escolha uma ou escreva a sua.
  - **Momentos de ênfase:** os trechos mais fortes ganham zoom rápido, legenda maior e emoji.
  - **Imagens sugeridas:** marcações tracejadas na trilha Imagens dizem o que mostrar e onde. Clique numa para **buscar grátis** ou **enviar a sua**: fotos vêm do Openverse e vídeos do Wikimedia Commons, os dois sem cadastro. Para ter muito mais vídeos, crie uma conta grátis no Pixabay e coloque `PIXABAY_API_KEY=sua_chave` no arquivo `.env` (a chave aparece em pixabay.com/api/docs depois de entrar). Os créditos das imagens baixadas ficam salvos junto do vídeo.
- **Áudio:** limpeza da voz e música de fundo, que abaixa sozinha quando você fala.
- **Marca:** logo e zoom nos cortes.
- **Exportar:** formatos e resolução.
- **Prontos:** assista os vídeos exportados antes de arquivar.

**Monitor**
- Troque entre 9:16, 16:9 e 1:1 para ver como fica em cada rede.
- Para reenquadrar um trecho, **arraste a imagem** com o mouse.
- "Área segura" mostra onde os botões das redes cobrem a imagem.

**Atalhos de teclado**

| Tecla | Ação |
|---|---|
| Espaço | tocar |
| S | dividir |
| Delete | excluir |
| I / O | marcar início / fim de um trecho |
| ← / → | quadro a quadro (Shift = 1 s) |
| ↑ / ↓ | corte anterior / próximo |
| Ctrl+Z | desfazer |

## IA local

- **Para que serve:**
  - entender tomadas repetidas e falsos inícios;
  - separar o "é" de hesitação do "é" verbo;
  - sugerir título e tema;
  - escolher onde entra cada imagem de apoio, olhando a imagem.
- **Qual modelo:**

  | Sua placa de vídeo | Modelo instalado |
  |---|---|
  | 10 GB ou mais | `gemma3:12b` |
  | menos de 10 GB, ou sem placa NVIDIA | `gemma3:4b` (mais leve) |

  Para trocar, rode no terminal `ollama pull <modelo>` e mude `modelo_local` no `config.yaml`.
- **Segurança:** a IA local é mais "solta" que serviços pagos. Por isso, quando ela marca uma repetição que não se repete de fato, o corte vem **desligado**, como sugestão. Na dúvida, nada é cortado sem você ver.
- **Sem IA** (`provedor: nenhum`): tudo funciona com regras simples.
- **Claude API** (opcional): ponha a chave no arquivo `.env` e use `provedor: auto` ou `api`.

## Qualidade

- **Resolução:** nunca abaixo de 1080p. Se o original for 4K, sai em 4K.
- **Compressão:** só na versão final, nada se perde nas etapas intermediárias. H.264 na qualidade mais alta que as redes aceitam.
- **Cores e fluidez:** HDR do celular convertido certo, cores padrão e fluidez original.
- **Áudio:** 320 kbps, no volume padrão das redes (−14 LUFS).
- **Placa NVIDIA:** usada para transcrever, para a IA e para exportar.

## Onde as coisas ficam

```
Vídeos\Biblioteca\
  Finanças\
    2026-10 Outubro\
      Como organizar seu orçamento\
        Como organizar seu orçamento - Reels-TikTok-Shorts 9x16.mp4
        Como organizar seu orçamento - YouTube 16x9.mp4
        Como organizar seu orçamento - LinkedIn-Facebook 1x1.mp4
        Como organizar seu orçamento - WhatsApp.mp4
        Como organizar seu orçamento.srt
        Como organizar seu orçamento - original.mp4
        Imagens de apoio\...
```

- **Arquivos de trabalho:** ficam em `Biblioteca\_trabalho`. Pode apagar quando quiser; você só perde a reedição rápida.
- **Reeditar:** arraste o "- original" de um vídeo arquivado para dentro do Estúdio.

## Problemas comuns

- **Deu erro num vídeo:** no cartão do erro clique em **Ver detalhes → Copiar** e mande para o suporte. Tudo fica também em `erros.log`, na pasta do programa.
- **A prévia não toca:** o Estúdio refaz a prévia sozinho num formato compatível; se continuar, os detalhes vão para `erros.log`.

- **A janela não abriu:**
  1. Abra `http://127.0.0.1:8765` no navegador.
  2. Se não abrir, rode `ABRIR_ESTUDIO.bat`, que mostra o registro.
  3. O registro também fica salvo em `estudio.log`.
- **"IA: sem IA" na tela inicial:** o Estúdio liga o Ollama sozinho, escondido, ao abrir. Se continuar, feche e abra o Estúdio. **Não é preciso criar conta no Ollama:** a conta só serve para os modelos na nuvem deles; a IA do Estúdio roda no seu computador. Se a janela do Ollama aparecer pedindo para entrar, pode fechá-la.
- **Transcrição lenta:** atualize o driver NVIDIA. Sem placa NVIDIA, o modelo `medium` já é usado.

## GIFs e sons em alta
- **Stickers → 🔥 Em alta no GIPHY:** os GIFs e stickers sem fundo mais usados do momento, e busca (risada, uau, palmas…). Clique para baixar e colocar no vídeo; ficam guardados em “Animados baixados”. Precisa de uma chave grátis do GIPHY (o próprio painel mostra o passo a passo, uma vez só).
- **Sons → 🔥 Mais baixados no Freesound:** os efeitos mais baixados, por categoria (meme, risada, whoosh, aplausos…), só com licença que permite uso comercial. ▶ ouve, ＋ guarda na coleção e coloca no vídeo. Precisa de uma chave grátis do Freesound (passo a passo no painel).
- Os créditos de tudo que for baixado ficam em `créditos.txt` dentro de stickers/baixados e sons/baixados.

## Atualizações automáticas
Quando sai uma versão nova, o Estúdio mostra um aviso no canto da tela com o que mudou. Clique em **⬇ Atualizar agora**: ele baixa só o programa (poucos MB), confere se o arquivo chegou inteiro, troca os arquivos, testa e reinicia sozinho — o projeto que estava aberto reabre. Se algo der errado, ele volta para a versão anterior. Seus projetos, biblioteca, músicas, logos, vinhetas, stickers e sons próprios, config.yaml e chaves (.env) nunca são mexidos. Se estiver processando um vídeo, espere terminar. Na tela inicial, o botão **versão …** (ao lado da IA) procura atualização na hora. Para não ser avisado, ponha `verificar: false` em `atualizacao:` no config.yaml.

