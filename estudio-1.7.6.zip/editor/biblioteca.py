"""Bibliotecas de stickers e sons do Estúdio.

Stickers: originais do Estúdio (stickers/texto), emojis (emojis/), animados populares do Google
Noto (baixados sob demanda, CC BY 4.0), e os seus (stickers/meus).
Sons: efeitos originais (sons/efeitos), sons buscados no Openverse (sons/baixados) e os seus (sons/meus)."""
from __future__ import annotations

import json
import re
import time
import urllib.parse
import urllib.request
from pathlib import Path

from . import emojis
from .util import RAIZ, aviso

AGENTE = "EstudioDeVideo/1.6 (editor de video local)"
ST = RAIZ / "stickers"
SN = RAIZ / "sons"
NOTO_API = "https://googlefonts.github.io/noto-emoji-animation/data/api.json"
NOTO_ARQ = "https://fonts.gstatic.com/s/e/notoemoji/latest/{cp}/512.{ext}"
OPENVERSE = "https://api.openverse.org"
EXT_STICKER = (".png", ".gif", ".webp", ".jpg", ".jpeg")
EXT_SOM = (".mp3", ".wav", ".ogg", ".m4a", ".aac", ".flac", ".opus")


def _get_json(url: str, tempo: int = 20) -> dict:
    req = urllib.request.Request(url, headers={"User-Agent": AGENTE})
    with urllib.request.urlopen(req, timeout=tempo) as r:
        return json.load(r)


def _baixar(url: str, destino: Path, limite_mb: int = 60) -> Path:
    req = urllib.request.Request(url, headers={"User-Agent": AGENTE})
    destino.parent.mkdir(parents=True, exist_ok=True)
    tmp = destino.with_suffix(destino.suffix + ".parcial")
    lido = 0
    with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
        while True:
            b = r.read(1 << 20)
            if not b:
                break
            lido += len(b)
            if lido > limite_mb * 1024 * 1024:
                raise RuntimeError("arquivo grande demais")
            f.write(b)
    tmp.replace(destino)
    return destino


def _credito(pasta: Path, nome: str, texto: str) -> None:
    try:
        with open(pasta / "créditos.txt", "a", encoding="utf-8") as f:
            f.write(f"{nome}\n  {texto}\n\n")
    except OSError:
        pass


def _nome_seguro(t: str, padrao: str = "arquivo") -> str:
    t = re.sub(r"[^\w\- ]", "", t, flags=re.UNICODE).strip()[:50]
    return t or padrao


# ============================================================ stickers
def listar_stickers() -> list[dict]:
    out = []
    cat = ST / "texto" / "catalogo.json"
    if cat.exists():
        for x in json.loads(cat.read_text(encoding="utf-8")):
            if (ST / "texto" / x["arquivo"]).exists():
                out.append({"id": f"stickers/texto/{x['arquivo']}", "nome": x["nome"], "categoria": x["categoria"],
                            "tags": x.get("tags", [])})
    for e in emojis.disponiveis():
        out.append({"id": f"emojis/{emojis.codigo(e)}.png", "nome": e, "categoria": "Emojis", "tags": emojis.LISTA.get(e, [])})
    for sub, rot in (("baixados", "Animados baixados"), ("meus", "Meus stickers")):
        for f in sorted((ST / sub).glob("*")):
            if f.suffix.lower() in EXT_STICKER:
                out.append({"id": f"stickers/{sub}/{f.name}", "nome": f.stem, "categoria": rot, "tags": []})
    for x in out:
        x["url"] = "/" + x["id"]
        x["animado"] = x["id"].lower().endswith((".gif", ".webp"))
    return out


def stickers_populares(n: int = 80) -> dict:
    """Emojis animados mais populares (Google Noto, CC BY 4.0). A lista fica guardada por 1 dia."""
    cache = ST / "baixados" / ".populares.json"
    try:
        if cache.exists() and time.time() - cache.stat().st_mtime < 86400:
            dados = json.loads(cache.read_text(encoding="utf-8"))
        else:
            dados = _get_json(NOTO_API)
            cache.parent.mkdir(parents=True, exist_ok=True)
            cache.write_text(json.dumps(dados), encoding="utf-8")
    except Exception as e:  # noqa: BLE001
        if cache.exists():
            dados = json.loads(cache.read_text(encoding="utf-8"))
        else:
            return {"itens": [], "aviso": f"Sem internet para buscar os animados ({str(e)[:80]})."}
    icones = sorted(dados.get("icons", []), key=lambda x: -int(x.get("popularity", 0)))[:n]
    itens = []
    for ic in icones:
        cp = str(ic.get("codepoint", "")).replace(" ", "_")
        if not re.fullmatch(r"[0-9a-f_]+", cp):
            continue
        itens.append({"codigo": cp, "nome": (ic.get("tags") or [cp])[0].strip(":").replace("-", " "),
                      "previa": NOTO_ARQ.format(cp=cp, ext="webp"),
                      "baixado": (ST / "baixados" / f"noto_{cp}.gif").exists()})
    return {"itens": itens, "aviso": ""}


def baixar_sticker_animado(codigo: str) -> dict:
    if not re.fullmatch(r"[0-9a-f_]+", codigo):
        raise RuntimeError("código inválido")
    destino = ST / "baixados" / f"noto_{codigo}.gif"
    if not destino.exists():
        _baixar(NOTO_ARQ.format(cp=codigo, ext="gif"), destino)
        _credito(ST / "baixados", destino.name, "Noto Emoji Animation, Google — licença CC BY 4.0")
    return {"id": f"stickers/baixados/{destino.name}", "url": f"/stickers/baixados/{destino.name}"}


# ============================================================ sons
def listar_sons() -> list[dict]:
    out = []
    cat = SN / "efeitos" / "catalogo.json"
    if cat.exists():
        for x in json.loads(cat.read_text(encoding="utf-8")):
            if (SN / "efeitos" / x["arquivo"]).exists():
                out.append({"id": f"sons/efeitos/{x['arquivo']}", "nome": x["nome"], "categoria": x["categoria"],
                            "duracao": x.get("duracao"), "tags": x.get("tags", [])})
    for sub, rot in (("baixados", "Baixados"), ("meus", "Meus sons")):
        for f in sorted((SN / sub).glob("*")):
            if f.suffix.lower() in EXT_SOM:
                out.append({"id": f"sons/{sub}/{f.name}", "nome": f.stem.replace("_", " "), "categoria": rot, "tags": []})
    for x in out:
        x["url"] = "/" + x["id"]
    return out


def buscar_sons(consulta: str) -> dict:
    """Sons com licença livre no Openverse (Freesound, Wikimedia, Jamendo...). Sem cadastro."""
    q = consulta.strip() or "funny"
    try:
        d = _get_json(f"{OPENVERSE}/v1/audio/?" + urllib.parse.urlencode(
            {"q": q, "license_type": "commercial", "page_size": 20, "mature": "false"}))
    except Exception as e:  # noqa: BLE001
        return {"itens": [], "aviso": f"Openverse não respondeu ({str(e)[:80]})"}
    itens = []
    for r in d.get("results", []):
        if not r.get("url"):
            continue
        dur = r.get("duration")
        lic = f"CC {str(r.get('license', '')).upper()} {r.get('license_version', '')}".strip()
        if str(r.get("license", "")).lower() in ("cc0", "pdm"):
            lic = "Domínio público"
        itens.append({"titulo": (r.get("title") or "som")[:80], "url": r["url"],
                      "duracao": round(dur / 1000, 1) if isinstance(dur, (int, float)) else None,
                      "tipo_arquivo": r.get("filetype") or "", "licenca": lic, "pagina": r.get("foreign_landing_url"),
                      "credito": (r.get("attribution") or f"{r.get('title', '')} por {r.get('creator', '?')}")[:300],
                      "fonte": r.get("source") or "Openverse"})
    return {"itens": itens, "aviso": "" if itens else f"Nada encontrado para “{q}”."}


def baixar_som(url: str, titulo: str, credito: str, licenca: str, pagina: str) -> dict:
    """Baixa para sons/baixados e converte para mp3 (o FFmpeg lê de tudo)."""
    if not url.startswith(("https://", "http://")):
        raise RuntimeError("endereço inválido")
    nome = _nome_seguro(titulo, "som")
    ext = Path(urllib.parse.urlparse(url).path).suffix.lower()
    if ext not in EXT_SOM:
        ext = ".bin"
    bruto = _baixar(url, SN / "baixados" / f".{nome}{ext}", limite_mb=40)
    destino = SN / "baixados" / f"{nome}.mp3"
    k = 2
    while destino.exists():
        destino = SN / "baixados" / f"{nome} ({k}).mp3"
        k += 1
    from .util import rodar_ffmpeg
    try:
        rodar_ffmpeg(["-i", str(bruto), "-t", "60", "-vn", "-ac", "2", "-ar", "44100", "-b:a", "192k", str(destino)])
    finally:
        bruto.unlink(missing_ok=True)
    _credito(SN / "baixados", destino.name, f"{credito} — {licenca} — {pagina or ''}")
    return {"id": f"sons/baixados/{destino.name}", "url": f"/sons/baixados/{destino.name}", "nome": destino.stem}


def guardar_enviado(tipo: str, origem: Path) -> dict:
    """Arquivo enviado pelo editor vai para stickers/meus ou sons/meus."""
    pasta = (ST if tipo == "sticker" else SN) / "meus"
    pasta.mkdir(parents=True, exist_ok=True)
    validas = EXT_STICKER if tipo == "sticker" else EXT_SOM
    if origem.suffix.lower() not in validas:
        origem.unlink(missing_ok=True)
        raise RuntimeError("formato não aceito: use " + ", ".join(validas))
    destino = pasta / f"{_nome_seguro(origem.stem)}{origem.suffix.lower()}"
    k = 2
    while destino.exists():
        destino = pasta / f"{_nome_seguro(origem.stem)} ({k}){origem.suffix.lower()}"
        k += 1
    origem.replace(destino)
    sub = "stickers" if tipo == "sticker" else "sons"
    return {"id": f"{sub}/meus/{destino.name}", "url": f"/{sub}/meus/{destino.name}", "nome": destino.stem}


def arquivo_publico(caminho_url: str) -> Path | None:
    """/stickers/... e /sons/... servidos ao navegador (só dentro dessas pastas)."""
    rel = caminho_url.lstrip("/")
    if not rel.startswith(("stickers/", "sons/")) or ".." in rel:
        return None
    p = (RAIZ / rel).resolve()
    if not str(p).startswith(str(RAIZ.resolve())) or not p.is_file():
        return None
    return p


def avisar(msg: str) -> None:
    aviso(msg)
