"""Editor automático de vídeos falados."""

VERSAO = "1.7.6"   # muda a cada atualização: o Estúdio antigo que estiver aberto é substituído sozinho
