"""Editor automático de vídeos falados: corta erros/pausas, legenda, junta vídeos extras de forma
harmoniosa, exporta em alta qualidade e arquiva numa biblioteca organizada por Tema > Data."""
from __future__ import annotations

import argparse
import copy
import hashlib
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

from . import analyze, edl, emojis, framing, legenda_modelos, media, organizer, render, review, subtitles, transcribe
from .util import (RAIZ, aviso, caminho_cfg, carregar_config, etapa, exigir_ffmpeg, fmt_tempo, info,
                   ler_json, salvar_json, sondar)

CURTO = {"vertical": "9:16 Reels", "horizontal": "16:9 YouTube", "quadrado": "1:1 Feed", "whatsapp": "WhatsApp"}
PRINCIPAL = "principal"


def _mesclar(base: dict, extra: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (extra or {}).items():
        out[k] = _mesclar(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def _tamanho(p: Path) -> str:
    b = p.stat().st_size
    return f"{b / 1e9:.2f} GB" if b > 1e9 else f"{b / 1e6:.1f} MB"


def _legenda_padrao(lc: dict) -> dict:
    """config.yaml + o modelo marcado como padrão (se houver)."""
    from .legenda_modelos import estilo_padrao
    base = {k: lc[k] for k in subtitles.PADRAO if k in lc}
    return subtitles.estilo_global({**base, **estilo_padrao()})


def ajustes_padrao(cfg: dict, semente: str) -> dict:
    lc = cfg.get("legenda", {})
    musica = render.escolher_musica(cfg, semente)
    lcfg = cfg.get("logo", {})
    vcfg = cfg.get("vinhetas", {})
    return {
        "legenda": _legenda_padrao(lc),
        "leg_trechos": [], "leg_chave": [], "leg_emoji": {},
        "gancho": {"ativar": False, "texto": "", "dur": 3.0, "posicao": 0.2, "tamanho": 100,
                   "cor_caixa": "#FFD60A", "cor_texto": "#000000", "opcoes": []},
        "enfase": [], "marcadores": [], "trilhas": [], "folgas": {}, "leg_tempo": {}, "personagens": [], "falas": [],
        "duracao": {"minimo": float(cfg.get("duracao", {}).get("minimo", 30)),
                    "maximo": float(cfg.get("duracao", {}).get("maximo", 45)),
                    "ajustar_sozinho": bool(cfg.get("duracao", {}).get("ajustar_sozinho", True))},
        "ajustes_video": {"filtro": "nenhum", "brilho": 0, "contraste": 1, "saturacao": 1, "temperatura": 6500,
                          "vinheta": 0, "nitidez": 0, "espelhar": False, "velocidade": 1, "transicao": "nenhuma"},
        "zoom": {"ativar": True, "fator": 1.10, **cfg.get("zoom", {})},
        "musica": {"ativar": bool(musica), "arquivo": musica.name if musica else "",
                   "volume": float(cfg.get("musica", {}).get("volume", 0.12)),
                   "abaixar_quando_fala": bool(cfg.get("musica", {}).get("abaixar_quando_fala", True))},
        "logo": {"ativar": True, "posicao": lcfg.get("posicao", "superior_direito"),
                 "largura": float(lcfg.get("largura", 0.14)), "opacidade": float(lcfg.get("opacidade", 0.85))},
        "audio": {"melhorar": bool(cfg.get("audio", {}).get("melhorar", True))},
        "formatos": [f for f in cfg.get("formatos", list(render.FORMATOS)) if f in render.FORMATOS],
        "qualidade": {"resolucao": str(cfg.get("qualidade", {}).get("resolucao", "auto"))},
        "enquadramento": [],
        "cena": {"video": {"x": 0.5, "y": 0.5, "escala": 1.0, "rot": 0.0, "corte": {"e": 0, "d": 0, "c": 0, "b": 0},
                           "modo": "fixo", "chaves": [], "seguir_rosto": True},
                 "fundo": {"remover": False, "metodo": "ia", "chroma": {"cor": "#00FF00", "tol": 0.3, "suave": 0.08},
                           "tipo": "desfoque", "arquivo": "", "cor1": "#1E1E2E", "cor2": "#6A5ACD", "angulo": 135,
                           "x": 0.5, "y": 0.5, "escala": 1.0, "rot": 0.0, "desfoque": 0.6}},
        "broll": [],
        "vinhetas": {"abertura": bool(vcfg.get("abertura", True)), "encerramento": bool(vcfg.get("encerramento", True))},
    }


def cfg_com_ajustes(cfg: dict, aj: dict) -> dict:
    """Aplica o que foi escolhido no editor por cima do config.yaml (só para este vídeo)."""
    c = _mesclar(cfg, {k: aj[k] for k in ("legenda", "zoom", "audio", "qualidade") if k in aj})
    m = aj.get("musica", {})
    c["musica"] = _mesclar(cfg.get("musica", {}), m)
    if m.get("ativar") and m.get("arquivo"):
        c["musica"]["arquivo"] = str(RAIZ / "musica" / m["arquivo"])
    c["logo"] = _mesclar(cfg.get("logo", {}), aj.get("logo", {}))
    c["formatos"] = aj.get("formatos", cfg.get("formatos"))
    c["enquadramento"] = aj.get("enquadramento", [])
    return c


# ===================================================================================== projeto
class Projeto:
    """Vídeo principal + partes extras da fala + imagens de apoio, com todo o trabalho em cache."""

    def __init__(self, video: Path, cfg: dict, args):
        self.video, self.cfg, self.args = video, cfg, args
        self.biblioteca = organizer.ativa(cfg)
        if self.biblioteca:
            _, dst = organizer.pastas(cfg)
            self.trab = dst / "_trabalho" / organizer.impressao_digital(video)
        else:
            self.trab = video.parent / "_editor_trabalho" / video.stem
        self.trab.mkdir(parents=True, exist_ok=True)
        self.saida = self.trab / "saida"
        self.saida.mkdir(exist_ok=True)
        self.midia = self.trab / "midia"
        self.midia.mkdir(exist_ok=True)
        self.iv_original = sondar(video)
        self.data = organizer.data_gravacao(video, self.iv_original)
        self.semente = self.trab.name
        arq = self.trab / "partes.json"
        self.partes: list[dict] = ler_json(arq) if arq.exists() else [{"id": PRINCIPAL, "nome": video.name}]
        self.rastro: dict = {}
        self.erros_bg: list[BaseException] = []
        self.extras: dict = {}
        self.fonte, self.iv = video, self.iv_original
        self.palavras: list[dict] = []
        self.cortes_sug: list[dict] = []
        self.meta: dict = {}
        self.t_rosto = None

    # ---------------------------------------------------------------- fonte (vídeo de trabalho)
    @property
    def chave_partes(self) -> str:
        return hashlib.sha1("|".join(p["id"] for p in self.partes).encode()).hexdigest()[:10]

    @property
    def combinado(self) -> bool:
        return len(self.partes) > 1

    @property
    def base(self) -> Path:
        b = self.trab if not self.combinado else self.trab / f"combo_{self.chave_partes}"
        b.mkdir(exist_ok=True)
        return b

    def arquivo_parte(self, p: dict) -> Path:
        return self.video if p["id"] == PRINCIPAL else self.midia / p["nome"]

    def montar_fonte(self) -> None:
        """Sem partes extras: trabalha direto no original. Com partes: normaliza todas para o
        mesmo formato/cor/volume do principal e junta numa só fonte."""
        if not self.combinado:
            self.fonte, self.iv = self.video, self.iv_original
            return
        destino = self.base / "fonte.mkv"
        if not destino.exists():
            info("Harmonizando as partes da fala com o vídeo principal (tamanho, fluidez, cor e volume)...")
            ref = self.iv_original
            cor_ref = media.estatisticas_cor(self.video, dur=ref["duracao"], hdr=ref.get("hdr", False))
            normalizados = []
            for p in self.partes:
                pasta = self.trab / "partes" / p["id"]
                pasta.mkdir(parents=True, exist_ok=True)
                norm = pasta / "normalizado.mkv"
                if not norm.exists():
                    media.normalizar_parte(self.arquivo_parte(p), norm, ref, cor_ref, self.cfg, p["id"] == PRINCIPAL)
                normalizados.append(norm)
            media.juntar_partes(normalizados, destino)
        self.fonte = destino
        self.iv = sondar(destino)

    # ---------------------------------------------------------------- transcrição + análise
    def _transcrever_parte(self, p: dict) -> list[dict]:
        if p["id"] == PRINCIPAL:
            arq, origem = self.trab / "transcricao.json", self.video
            dur = self.iv_original["duracao"]
        else:
            arq = self.trab / "partes" / p["id"] / "transcricao.json"
            origem = self.trab / "partes" / p["id"] / "normalizado.mkv"
            dur = sondar(origem)["duracao"]
        if arq.exists() and not self.args.refazer:
            return ler_json(arq)
        info(f"Transcrevendo {p['nome']}...")
        pal = transcribe.transcrever(origem, self.cfg, dur)
        salvar_json(arq, pal)
        return pal

    def preparar_conteudo(self) -> None:
        etapa(1, 3, "Transcrevendo a fala")
        arq_tx = self.base / ("transcricao_combinada.json" if self.combinado else "transcricao.json")
        arq_cortes = self.base / "cortes_sugeridos.json"
        if self.combinado and (not arq_tx.exists() or self.args.refazer):
            todas, desloc = [], 0.0
            for p in self.partes:
                for w in self._transcrever_parte(p):
                    todas.append(dict(w, s=w["s"] + desloc, e=w["e"] + desloc, parte=p["id"], local=w["i"]))
                norm = self.trab / "partes" / p["id"] / "normalizado.mkv"
                desloc += sondar(norm)["duracao"]
            self.palavras = transcribe.normalizar(todas)
            salvar_json(arq_tx, self.palavras)
            arq_cortes.unlink(missing_ok=True)
        elif self.combinado:
            self.palavras = ler_json(arq_tx)
        else:
            self.palavras = self._transcrever_parte(self.partes[0])
            for w in self.palavras:
                w.setdefault("parte", PRINCIPAL)
                w.setdefault("local", w["i"])
        info(f"{len(self.palavras)} palavras.")

        etapa(2, 3, "Encontrando erros, repetições, vícios e pausas")
        if arq_cortes.exists() and not self.args.refazer:
            self.cortes_sug = analyze.manter_uma_ocorrencia(
                self.palavras, analyze.limitar_cortes(ler_json(arq_cortes), len(self.palavras)))
            info("Usando análise já feita.")
        else:
            env = analyze.envelope_db(self.fonte)
            analyze.refinar_palavras(self.palavras, env)
            salvar_json(arq_tx, self.palavras)
            self.cortes_sug = analyze.manter_uma_ocorrencia(
                self.palavras, analyze.analisar(self.palavras, self.iv["duracao"], env, self.cfg))
            salvar_json(arq_cortes, self.cortes_sug)
        resumo: dict[str, int] = {}
        for c in self.cortes_sug:
            if c["ativo"]:
                resumo[c["tipo"]] = resumo.get(c["tipo"], 0) + 1
        info("Sugestões: " + (", ".join(f"{v} {k}" for k, v in resumo.items()) or "nenhuma"))

        arq_meta = self.trab / "meta.json"
        self.meta = ler_json(arq_meta) if arq_meta.exists() else {}
        if not self.meta.get("titulo"):
            self.meta.update(organizer.sugerir_titulo_tema(self.palavras, self.cfg, self.cortes_sug)
                             if self.biblioteca else {"titulo": self.video.stem, "tema": ""})
            salvar_json(arq_meta, self.meta)
        if self.biblioteca:
            info(f"Título sugerido: {self.meta['titulo']}  ·  Tema: {self.meta['tema']}")

    # ---------------------------------------------------------------- tarefas em segundo plano
    def _paralelo(self, fn, *a):
        def alvo():
            try:
                fn(*a)
            except BaseException as e:  # noqa: BLE001
                self.erros_bg.append(e)
        t = threading.Thread(target=alvo, daemon=True)
        t.start()
        return t

    def iniciar_previa(self):
        self.previa = self.base / "previa_v2.mp4"   # v2: formato que qualquer navegador toca
        return self._paralelo(review.gerar_previa, self.fonte, self.previa, self.cfg, self.iv)

    def iniciar_rastro(self):
        arq = self.base / "rosto.json"
        self.rastro.clear()

        def rastrear():
            if arq.exists():
                self.rastro["r"] = ler_json(arq)
                return
            try:
                r = framing.rastrear_rosto(self.fonte, self.iv)
                salvar_json(arq, r)
                self.rastro["r"] = r
            except Exception as e:  # noqa: BLE001 — sem rosto, enquadra pelo centro
                aviso(f"Não consegui rastrear o rosto ({e}); usando enquadramento central.")
                self.rastro["r"] = []
        self.t_rosto = self._paralelo(rastrear)

    def cor_referencia(self) -> dict:
        arq = self.base / "cor.json"
        if arq.exists():
            return ler_json(arq)
        c = media.estatisticas_cor(self.fonte, dur=self.iv["duracao"], hdr=self.iv.get("hdr", False))
        salvar_json(arq, c)
        return c

    # ---------------------------------------------------------------- linha do tempo: miniaturas e forma de onda
    PASSO_QUADROS = 2.0

    def gerar_quadros(self) -> Path:
        """Uma miniatura a cada 2 s para desenhar a trilha de vídeo (estilo CapCut)."""
        pasta = self.base / "quadros"
        if pasta.is_dir() and any(pasta.iterdir()):
            return pasta
        pasta.mkdir(exist_ok=True)
        from .render import TONEMAP
        vf = (TONEMAP + "," if self.iv.get("hdr") else "") + f"fps=1/{self.PASSO_QUADROS},scale=-2:72"
        from .util import rodar_ffmpeg
        rodar_ffmpeg(["-i", str(self.fonte), "-an", "-vf", vf, "-q:v", "6", str(pasta / "q%05d.jpg")])
        return pasta

    def onda(self) -> list[float]:
        """Forma de onda da voz (picos a cada 50 ms, 0–1)."""
        arq = self.base / "onda.json"
        if arq.exists():
            return ler_json(arq)
        import numpy as np
        proc = subprocess.run(["ffmpeg", "-v", "error", "-i", str(self.fonte), "-vn", "-ac", "1", "-ar", "8000",
                               "-f", "s16le", "-"], capture_output=True)
        x = np.abs(np.frombuffer(proc.stdout, dtype=np.int16).astype(np.float32)) / 32768.0
        n = 400  # 50 ms a 8 kHz
        q = len(x) // n
        picos = x[: q * n].reshape(q, n).max(axis=1) if q else np.zeros(1)
        ref = float(np.percentile(picos, 99)) or 1.0
        out = [round(min(1.0, float(v) / ref), 3) for v in picos]
        salvar_json(arq, out)
        return out

    # ---------------------------------------------------------------- mídias
    def midias(self) -> list[dict]:
        arq = self.trab / "midias.json"
        return ler_json(arq) if arq.exists() else []

    def registrar_midia(self, m: dict) -> None:
        lista = [x for x in self.midias() if x["nome"] != m["nome"]] + [m]
        salvar_json(self.trab / "midias.json", lista)

    def vinhetas_dados(self) -> dict:
        out = {}
        for tipo in ("abertura", "encerramento"):
            v = media.info_vinheta(tipo)
            if v:
                prev = media.previa_vinheta(tipo, self.midia, self.cfg)
                self.extras[f"/vinheta/{tipo}"] = prev
                out[tipo] = {"nome": v["nome"], "duracao": round(v["duracao"], 2), "foto": v["foto"],
                             "url": f"/vinheta/{tipo}?v={int(prev.stat().st_mtime)}"}
            else:
                out[tipo] = None
        return out

    # ---------------------------------------------------------------- dados para o editor
    def montar_dados(self, estado: dict | None) -> dict:
        iv, cfg = self.iv, self.cfg
        if estado and estado.get("cortes") and self.palavras:
            estado = dict(estado, cortes=analyze.manter_uma_ocorrencia(self.palavras, estado["cortes"]))
        ajustes = _mesclar(ajustes_padrao(cfg, self.semente), (estado or {}).get("ajustes", {}))
        fontes = render.arquivos_de_fonte()
        fonte_nome = cfg.get("legenda", {}).get("fonte", "Montserrat ExtraBold").split()[0].lower()
        fonte_arq = next((f for f in fontes if fonte_nome in f.name.lower()), None)
        logo = caminho_cfg(cfg.get("logo", {}).get("arquivo"))
        self.extras = {f"/fontes/{f.name}": f for f in fontes}
        self.extras.update({f"/musica/{m.name}": m for m in render.listar_musicas()})
        if logo and logo.is_file():
            self.extras["/logo"] = logo
        resultados = []
        for nome in render.FORMATOS:
            f = self.saida / f"{nome}.mp4"
            if f.exists():
                W, H = render.dimensoes(nome, iv, cfg_com_ajustes(cfg, ajustes))
                resultados.append({"formato": nome, "rotulo": render.FORMATOS[nome][2], "url": f"/saida/{f.name}",
                                   "resolucao": f"{W}×{H}", "tamanho": _tamanho(f)})
        partes_ui = []
        for p in self.partes:
            arq = self.arquivo_parte(p)
            dur = self.iv_original["duracao"] if p["id"] == PRINCIPAL else sondar(arq)["duracao"]
            partes_ui.append({"id": p["id"], "nome": p["nome"], "duracao": round(dur, 1), "principal": p["id"] == PRINCIPAL})
        return {
            "nome": self.video.name, "duracao": iv["duracao"], "fps": iv["fps"], "largura": iv["largura"],
            "altura": iv["altura"], "hdr": self.iv_original.get("hdr", False),
            "fonte4k": min(iv["largura"], iv["altura"]) >= 2000,
            "pb": float(cfg.get("cortes", {}).get("respiro_antes", 0.10)),
            "pa": float(cfg.get("cortes", {}).get("respiro_depois", 0.16)),
            "palavras": [{"i": w["i"], "w": w["w"], "s": w["s"], "e": w["e"]} for w in self.palavras],
            "cortes": self.cortes_sug, "estado": estado, "ajustes": ajustes,
            "formatos": {k: {"W": v[0], "H": v[1], "rotulo": v[2], "curto": CURTO[k]} for k, v in render.FORMATOS.items()},
            "musicas": [m.name for m in render.listar_musicas()],
            "logo": bool(logo and logo.is_file()),
            "fonte_url": f"/fontes/{fonte_arq.name}" if fonte_arq else "",
            "titulo": (estado or {}).get("titulo") or self.meta.get("titulo", ""),
            "tema": (estado or {}).get("tema") or self.meta.get("tema", ""),
            "temas": organizer.temas_existentes(cfg) if self.biblioteca else [],
            "biblioteca": str(organizer.pastas(cfg)[1]) if self.biblioteca else "",
            "pasta_mes": organizer.pasta_do_mes(self.data),
            "pasta_saida_legado": str(self.video.parent / f"{self.video.stem}_EDITADO"),
            "resultados": resultados,
            "partes": partes_ui,
            "midias": self.midias(),
            "vinhetas": self.vinhetas_dados(),
            "transicao": render.TRANSICAO,
            "fontes": subtitles.catalogo_fontes(),
            "modelos_legenda": legenda_modelos.listar(),
            "emojis": {e: f"/emojis/{emojis.codigo(e)}.png" for e in emojis.disponiveis()},
        }

    # ---------------------------------------------------------------- reaproveitar a edição ao mudar partes
    def remapear_estado(self, estado: dict | None, partes_antigas: list[dict], palavras_antigas: list[dict]) -> dict | None:
        """Ao incluir/reordenar/remover partes da fala, mantém o que você já editou em cada parte."""
        if not estado:
            return None
        novo_idx = {(w.get("parte", PRINCIPAL), w.get("local", w["i"])): w["i"] for w in self.palavras}

        def idx(i):
            if not 0 <= int(i) < len(palavras_antigas):
                return None
            w = palavras_antigas[int(i)]
            return novo_idx.get((w.get("parte", PRINCIPAL), w.get("local", w["i"])))

        cortes = []
        for c in estado.get("cortes") or []:
            c = dict(c)
            if "pausa" in c:
                if c["pausa"] < 0:
                    continue
                k = idx(c["pausa"])
                if k is None:
                    continue
                c["pausa"] = k
            else:
                c["palavras"] = [k for k in (idx(i) for i in c.get("palavras", [])) if k is not None]
                if not c["palavras"]:
                    continue
            cortes.append(c)
        # sugestões automáticas para as partes que acabaram de entrar
        antigas = {p["id"] for p in partes_antigas}
        novas = {p["id"] for p in self.partes} - antigas
        parte_de = {w["i"]: w.get("parte") for w in self.palavras}
        for c in self.cortes_sug:
            alvo = c.get("palavras") or ([c["pausa"]] if c.get("pausa", -1) >= 0 else [])
            if alvo and all(parte_de.get(i) in novas for i in alvo):
                cortes.append(dict(c))
        # pausa no início do vídeo: segue a sugestão nova
        cortes += [dict(c) for c in self.cortes_sug if c.get("pausa") == -1]
        aj = copy.deepcopy(estado.get("ajustes") or {})
        aj["broll"] = [dict(b, palavra=idx(b["palavra"])) for b in aj.get("broll", []) if idx(b["palavra"]) is not None]
        aj["enquadramento"] = []  # tempos mudaram; o rosto é rastreado de novo
        return {**estado, "cortes": cortes, "ajustes": aj,
                "edicoes": {str(idx(k)): v for k, v in (estado.get("edicoes") or {}).items() if idx(k) is not None},
                "quebras": [idx(i) for i in estado.get("quebras") or [] if idx(i) is not None]}


def gerar(pj: Projeto, estado: dict) -> list[dict]:
    iv, trab = pj.iv, pj.base
    c = cfg_com_ajustes(pj.cfg, estado.get("ajustes", {}))
    aj = estado.get("ajustes", {})
    palavras = copy.deepcopy(pj.palavras)
    cortes = estado["cortes"]
    for k, txt in (estado.get("edicoes") or {}).items():
        palavras[int(k)]["txt"] = txt
    for i in estado.get("quebras") or []:
        palavras[int(i)]["quebra"] = True
    for corte in cortes:
        if corte.get("ativo"):
            for i in corte.get("palavras", []):
                if 0 <= i < len(palavras):
                    palavras[i]["removida"] = True
    trechos = edl.trechos_mantidos(palavras, cortes, iv["duracao"], c, iv["fps"], aj.get("folgas") or {})
    mapa = edl.Mapa(trechos)
    info(f"{len(trechos)} trechos · {fmt_tempo(iv['duracao'])} → {fmt_tempo(mapa.total)}")
    formatos = [f for f in c.get("formatos", []) if f in render.FORMATOS]
    rastro = pj.rastro.get("r", [])
    T = 3

    # imagens de apoio: posição presa a uma palavra (acompanha os cortes)
    brolls = []
    midias = {m["nome"]: m for m in pj.midias()}
    cor_ref = pj.cor_referencia() if aj.get("broll") else None
    for b in aj.get("broll") or []:
        m = midias.get(b.get("midia"))
        if not m or b.get("palavra") is None:
            continue
        i = int(b["palavra"])
        ini = None
        for w in palavras[i:]:
            if not w.get("removida"):
                r = mapa.palavra(w)
                if r:
                    ini = r[0]
                    break
        if ini is None:
            continue
        dur = float(b.get("dur", 4.0))
        if m["tipo"] == "video":
            dur = min(dur, max(0.5, m["duracao"] - float(b.get("inicio", 0))))
        dur = min(dur, mapa.total - ini - 0.1)
        if dur < 0.6:
            continue
        brolls.append({"arquivo": pj.midia / m["nome"], "foto": m["tipo"] == "foto", "ini": round(ini, 3),
                       "dur": round(dur, 3), "inicio": float(b.get("inicio", 0)),
                       "cor": media.filtro_harmonizar(cor_ref, m["cor"]) if b.get("harmonizar", True) else ""})
    brolls.sort(key=lambda x: x["ini"])
    for a, b in zip(brolls, brolls[1:]):  # sem sobreposição
        if a["ini"] + a["dur"] > b["ini"] - 0.05:
            a["dur"] = max(0.6, b["ini"] - 0.05 - a["ini"])

    vinhetas = {}
    for tipo in ("abertura", "encerramento"):
        if (aj.get("vinhetas") or {}).get(tipo):
            v = media.info_vinheta(tipo)
            if v:
                vinhetas[tipo] = v

    # cena: fundo tirado (máscara da pessoa) — faz agora se ainda não foi feita no editor
    cena = aj.get("cena") or {}
    fd = cena.get("fundo") or {}
    mascara = None
    if fd.get("remover"):
        from . import fundo as fundo_mod
        mascara = fundo_mod.mascara_existente(pj.base, fd, pj.fonte)
        if mascara is None:
            etapa(1, T, "Tirando o fundo do vídeo")
            mascara = fundo_mod.gerar(pj.fonte, getattr(pj, "previa", None), pj.base, fd, iv["fps"])["mascara"]
    etapa(1, T, "Montando o vídeo sem os erros")
    master, zooms = render.renderizar_cortes(pj.fonte, trechos, iv, rastro, c, trab, mascara=mascara)
    etapa(2, T, "Tratando o áudio")
    from . import voz as voz_mod
    c.setdefault("audio", {})["efeitos_trechos"] = [list(x) for x in voz_mod.trechos_personagens(aj, palavras, mapa.palavra)]
    master_final = render.tratar_audio(master, mapa.total, c, trab, pj.semente)
    etapa(3, T, "Gerando: " + ", ".join(render.FORMATOS[f][2] for f in formatos))
    fonte, negrito = render.preparar_fontes(trab, c)
    # trilhas extras (vídeo, imagem/sticker, áudio, texto) e ajustes de imagem
    from . import trilhas as trilhas_mod
    extras = trilhas_mod.resolver(aj, palavras, mapa, pj.midia)
    textos = [x for x in extras if x["tipo"] == "texto"]
    acum, cortes_t = 0.0, []
    for s0, e0 in trechos[:-1]:
        acum += e0 - s0
        cortes_t.append(round(acum, 3))
    # momentos de ênfase com zoom rápido (punch-in): intervalos no tempo do vídeo final
    punch = []
    for m in aj.get("enfase") or []:
        if not m.get("zoom", True):
            continue
        tempos = [mapa.palavra(w) for w in palavras[int(m["de"]): int(m["ate"]) + 1] if not w.get("removida")]
        tempos = [t for t in tempos if t]
        if tempos:
            punch.append((max(0.0, tempos[0][0] - 0.05), tempos[-1][1] + 0.15))
    pal_saida = subtitles.palavras_saida(palavras, mapa)
    desloc = (vinhetas["abertura"]["duracao"] - render.TRANSICAO) if "abertura" in vinhetas else 0.0
    subtitles.gerar_srt(pal_saida, pj.saida / "legenda.srt", desloc)
    def um_formato(k: int, nome: str) -> dict:
        W, H = render.dimensoes(nome, iv, c)
        etapa(3, T, f"Gerando {render.FORMATOS[nome][2]} ({W}×{H}) — {k} de {len(formatos)}")
        ass = trab / f"legenda_{nome}.ass"
        emo = subtitles.gerar_ass(pal_saida, ass, W, H, nome, c, fonte, negrito,
                                  trechos=aj.get("leg_trechos") or [], chaves=aj.get("leg_chave") or [],
                                  emojis=aj.get("leg_emoji") or {}, enfases=aj.get("enfase") or [],
                                  gancho=aj.get("gancho"), textos_livres=textos,
                                  leg_tempo=aj.get("leg_tempo") or {})
        arq = render.renderizar_formato(nome, master_final, iv, trechos, mapa, rastro, zooms, ass,
                                        pj.saida / f"{nome}.mp4", c, trab, brolls, vinhetas, emo, punch,
                                        extras=[x for x in extras if x["tipo"] != "texto"],
                                        ajustes_video=aj.get("ajustes_video") or {}, cortes_t=cortes_t,
                                        cena=cena, mascara=(trab / "master_mascara.mkv") if mascara else None,
                                        pasta_midia=pj.midia)
        return {"formato": nome, "rotulo": render.FORMATOS[nome][2], "url": f"/saida/{arq.name}",
                "resolucao": f"{W}×{H}", "tamanho": _tamanho(arq)}

    # com placa de vídeo, dois formatos ao mesmo tempo (as placas atuais codificam várias saídas juntas)
    from .util import escolher_encoder
    paralelo = 2 if len(formatos) > 1 and escolher_encoder(c) != "cpu" else 1
    if paralelo > 1:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=paralelo) as ex:
            saida = list(ex.map(lambda kn: um_formato(*kn), list(enumerate(formatos, 1))))
    else:
        saida = [um_formato(k, nome) for k, nome in enumerate(formatos, 1)]
    return saida


def arquivar(pj: Projeto, estado: dict) -> Path:
    video, cfg = pj.video, pj.cfg
    titulo = organizer.nome_seguro(estado.get("titulo") or video.stem)
    if pj.biblioteca:
        tema = organizer.nome_seguro(estado.get("tema") or "Geral", 40)
        destino = organizer.pasta_final(cfg, tema, titulo, pj.data, video)
    else:
        destino = video.parent / f"{video.stem}_EDITADO"
    destino.mkdir(parents=True, exist_ok=True)
    for nome in render.FORMATOS:
        f = pj.saida / f"{nome}.mp4"
        if f.exists():
            organizer.mover(f, destino / f"{titulo} - {render.FORMATOS[nome][2]}.mp4")
    if (pj.saida / "legenda.srt").exists():
        organizer.mover(pj.saida / "legenda.srt", destino / f"{titulo}.srt")
    # vídeos extras usados ficam junto, para poder reeditar no futuro
    usados = {b.get("midia") for b in (estado.get("ajustes") or {}).get("broll", [])}
    for m in pj.midias():
        if m["nome"] in usados and (pj.midia / m["nome"]).exists():
            (destino / "Imagens de apoio").mkdir(exist_ok=True)
            shutil.copy2(pj.midia / m["nome"], destino / "Imagens de apoio" / m["nome"])
    creditos = [m for m in pj.midias() if m["nome"] in usados and m.get("credito")]
    if creditos:   # imagens baixadas de bancos gratuitos: guarde os créditos (algumas licenças pedem)
        (destino / "Créditos das imagens.txt").write_text(
            "Imagens e vídeos de apoio baixados de bancos gratuitos.\n"
            "Para licenças CC BY, coloque o crédito na descrição do post.\n\n"
            + "\n\n".join(f"{m['nome']}\n  {m['credito']}\n  Licença: {m.get('licenca', '')}\n  {m.get('pagina', '')}"
                           for m in creditos) + "\n", encoding="utf-8")
    for n, p in enumerate([p for p in pj.partes if p["id"] != PRINCIPAL], 2):
        arq = pj.arquivo_parte(p)
        if arq.exists():
            shutil.copy2(arq, destino / f"{titulo} - original parte {n}{arq.suffix.lower()}")
    if pj.biblioteca and cfg.get("biblioteca", {}).get("mover_original", True):
        organizer.mover(video, destino / f"{titulo} - original{video.suffix.lower()}")
    # libera espaço: os intermediários são grandes (transcrição e edição ficam, para reeditar)
    for b in {pj.trab, pj.base}:
        for f in ("master.mkv", "master_final.mkv", "master.chave", "master_final.chave", "fonte.mkv"):
            (b / f).unlink(missing_ok=True)
    for f in (pj.trab / "partes").glob("*/normalizado.mkv"):
        f.unlink(missing_ok=True)
    return destino


def _janela_para_frente(pasta: Path, antes: set[int]) -> None:
    """Traz a janela do Explorador para a frente do Estúdio.

    O Windows impede que um programa em segundo plano (o servidor do Estúdio) coloque
    outra janela na frente: ela abre "atrás". Aqui esperamos a janela da pasta aparecer
    e a trazemos para cima (simulando a tecla Alt, que libera a troca de foco)."""
    import ctypes
    from ctypes import wintypes
    u32 = ctypes.windll.user32
    nome = pasta.name.lower()
    PROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def janelas() -> list[tuple[int, str]]:
        achadas = []

        def cb(h, _):
            cls = ctypes.create_unicode_buffer(64)
            u32.GetClassNameW(h, cls, 64)
            if cls.value in ("CabinetWClass", "ExploreWClass") and u32.IsWindowVisible(h):
                t = ctypes.create_unicode_buffer(512)
                u32.GetWindowTextW(h, t, 512)
                achadas.append((h, t.value))
            return True
        u32.EnumWindows(PROC(cb), 0)
        return achadas

    for _ in range(40):          # até ~4 s
        time.sleep(0.1)
        cands = [h for h, t in janelas() if h not in antes or t.lower() == nome]
        cands = sorted(cands, key=lambda h: h not in antes, reverse=True)
        if cands:
            h = cands[0]
            break
    else:
        return
    try:
        if u32.IsIconic(h):
            u32.ShowWindow(h, 9)                       # SW_RESTORE
        u32.keybd_event(0x12, 0, 0, 0)                 # Alt pressionado...
        u32.keybd_event(0x12, 0, 2, 0)                 # ...e solto: libera o SetForegroundWindow
        frente = u32.GetForegroundWindow()
        t1 = u32.GetWindowThreadProcessId(frente, None)
        t2 = ctypes.windll.kernel32.GetCurrentThreadId()
        u32.AttachThreadInput(t2, t1, True)
        flags = 0x0001 | 0x0002 | 0x0040               # NOSIZE | NOMOVE | SHOWWINDOW
        u32.SetWindowPos(h, -1, 0, 0, 0, 0, flags)     # sempre no topo...
        u32.SetWindowPos(h, -2, 0, 0, 0, 0, flags)     # ...e volta ao normal, já na frente
        u32.BringWindowToTop(h)
        u32.SetForegroundWindow(h)
        u32.AttachThreadInput(t2, t1, False)
    except Exception:  # noqa: BLE001
        pass


def abrir_pasta(p: Path) -> None:
    try:
        if sys.platform == "win32":
            import threading
            antes: set[int] = set()
            try:
                import ctypes
                from ctypes import wintypes
                u32 = ctypes.windll.user32
                PROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

                def cb(h, _):
                    cls = ctypes.create_unicode_buffer(64)
                    u32.GetClassNameW(h, cls, 64)
                    if cls.value in ("CabinetWClass", "ExploreWClass"):
                        antes.add(h)
                    return True
                u32.EnumWindows(PROC(cb), 0)
                u32.AllowSetForegroundWindow(-1)       # ASFW_ANY
            except Exception:  # noqa: BLE001
                pass
            os.startfile(p)  # type: ignore[attr-defined]
            threading.Thread(target=_janela_para_frente, args=(Path(p), antes), daemon=True).start()
        elif sys.platform == "darwin":
            subprocess.run(["open", str(p)])
    except Exception:  # noqa: BLE001
        pass


def main() -> None:
    from .estudio import principal
    principal()


if __name__ == "__main__":
    main()
