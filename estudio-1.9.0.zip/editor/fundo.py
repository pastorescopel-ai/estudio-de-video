"""Tirar o fundo do vídeo principal: máscara da pessoa (IA ou tela verde) + prévia com transparência.

- IA: Robust Video Matting (modelo pequeno, ~15 MB, baixado na 1ª vez) rodando com onnxruntime
  (placa de vídeo pelo DirectML no Windows; senão o processador). Funciona sem tela verde.
- Tela verde (chroma key): o FFmpeg tira a cor escolhida.

A máscara fica no tempo do vídeo original (mascara_<chave>.mkv, tons de cinza: branco = pessoa).
A exportação corta a máscara junto com os trechos; a prévia usa um .webm com transparência."""
from __future__ import annotations

import hashlib
import importlib
import json
import os
import subprocess
import sys
import threading
import urllib.request
from pathlib import Path

from .util import RAIZ, aviso, info, rodar_ffmpeg

MODELO_URL = "https://github.com/PeterL1n/RobustVideoMatting/releases/download/v1.0.0/rvm_mobilenetv3_fp32.onnx"
MODELO = RAIZ / "modelos" / "rvm_mobilenetv3_fp32.onnx"
LADO_IA = 720          # a IA trabalha com o lado menor em 720 px (a máscara é ampliada na exportação)
_trava_instalar = threading.Lock()


# ------------------------------------------------------------------ chaves e arquivos
def chave(cfg_fundo: dict, fonte: Path) -> str:
    met = cfg_fundo.get("metodo", "ia")
    partes = [met, str(fonte.stat().st_size), int(fonte.stat().st_mtime)]
    if met == "chroma":
        c = cfg_fundo.get("chroma") or {}
        partes += [str(c.get("cor", "#00FF00")).upper(), round(float(c.get("tol", 0.3)), 3), round(float(c.get("suave", 0.08)), 3)]
    return hashlib.sha1(json.dumps(partes).encode()).hexdigest()[:12]


def arquivos(pasta: Path, ch: str) -> tuple[Path, Path]:
    return pasta / f"mascara_{ch}.mkv", pasta / f"previa_alpha_{ch}.webm"


def pronta(pasta: Path, ch: str) -> bool:
    m, p = arquivos(pasta, ch)
    return m.exists() and m.stat().st_size > 0 and p.exists() and p.stat().st_size > 0


# ------------------------------------------------------------------ IA (onnxruntime)
def _instalar_onnx() -> None:
    with _trava_instalar:
        try:
            importlib.invalidate_caches()
            import onnxruntime  # noqa: F401
            return
        except Exception:  # noqa: BLE001
            pass
        pacote = "onnxruntime-directml" if sys.platform == "win32" else "onnxruntime"
        info(f"Instalando o componente da IA que tira o fundo ({pacote})…")
        exe = Path(sys.executable)
        py = exe.parent / "python.exe" if exe.name.lower() == "pythonw.exe" and (exe.parent / "python.exe").exists() else exe
        uv = RAIZ / "tools" / ("uv.exe" if sys.platform == "win32" else "uv")
        cmd = ([str(uv), "pip", "install", "--python", str(py), pacote] if uv.exists()
               else [str(py), "-m", "pip", "install", "--disable-pip-version-check", pacote])
        r = subprocess.run(cmd, cwd=RAIZ, capture_output=True, text=True, timeout=1800,
                           env={**os.environ, "UV_CACHE_DIR": str(RAIZ / ".cache" / "uv")},
                           **({"creationflags": 0x08000000} if sys.platform == "win32" else {}))
        if r.returncode != 0:
            raise RuntimeError("não consegui instalar o componente da IA: "
                               + ((r.stderr or r.stdout or "").strip().splitlines() or ["?"])[-1][:200])
        importlib.invalidate_caches()


def _modelo() -> Path:
    if MODELO.exists() and MODELO.stat().st_size > 1_000_000:
        return MODELO
    MODELO.parent.mkdir(parents=True, exist_ok=True)
    info("Baixando o modelo da IA que tira o fundo (15 MB, uma vez só)…")
    tmp = MODELO.with_suffix(".parcial")
    req = urllib.request.Request(MODELO_URL, headers={"User-Agent": "EstudioDeVideo"})
    with urllib.request.urlopen(req, timeout=120) as r, open(tmp, "wb") as f:
        while True:
            b = r.read(1 << 20)
            if not b:
                break
            f.write(b)
    tmp.replace(MODELO)
    return MODELO


def _sessao():
    _instalar_onnx()
    import onnxruntime as ort
    disp = ort.get_available_providers()
    prov = [p for p in ("DmlExecutionProvider", "CUDAExecutionProvider", "CPUExecutionProvider") if p in disp] or disp
    try:
        return ort.InferenceSession(str(_modelo()), providers=prov), prov[0]
    except Exception:  # noqa: BLE001  (placa recusou: vai no processador)
        return ort.InferenceSession(str(_modelo()), providers=["CPUExecutionProvider"]), "CPUExecutionProvider"


def _medidas(fonte: Path) -> tuple[int, int, float, float]:
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                        "stream=width,height,avg_frame_rate:stream_side_data=rotation:format=duration", "-of", "json", str(fonte)],
                       capture_output=True, text=True)
    d = json.loads(r.stdout or "{}")
    s = (d.get("streams") or [{}])[0]
    w, h = int(s.get("width", 1080)), int(s.get("height", 1920))
    rot = 0
    for sd in s.get("side_data_list") or []:
        rot = int(float(sd.get("rotation", 0) or 0))
    if abs(rot) in (90, 270):
        w, h = h, w
    num, _, den = str(s.get("avg_frame_rate", "30/1")).partition("/")
    fps = float(num) / float(den or 1) if float(den or 1) else 30.0
    return w, h, fps or 30.0, float((d.get("format") or {}).get("duration", 0) or 0)


def _tam_trabalho(w: int, h: int, lado: int) -> tuple[int, int]:
    k = min(1.0, lado / min(w, h))
    return max(2, int(w * k) // 2 * 2), max(2, int(h * k) // 2 * 2)


def mascara_ia(fonte: Path, saida: Path, fps: float, progresso=None) -> str:
    import numpy as np
    sess, prov = _sessao()
    W, H, _, dur = _medidas(fonte)
    w, h = _tam_trabalho(W, H, LADO_IA)
    n_total = max(1, int(dur * fps))
    dec = subprocess.Popen(["ffmpeg", "-v", "error", "-nostdin", "-i", str(fonte), "-an",
                            "-vf", f"fps={fps:.6f},scale={w}:{h}:flags=bilinear,format=rgb24",
                            "-f", "rawvideo", "-"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                           **({"creationflags": 0x08000000} if sys.platform == "win32" else {}))
    tmp = saida.with_name(saida.stem + ".parcial.mkv")
    enc = subprocess.Popen(["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "gray", "-s", f"{w}x{h}",
                            "-r", f"{fps:.6f}", "-i", "-", "-c:v", "libx264", "-preset", "veryfast", "-crf", "16",
                            "-pix_fmt", "gray", str(tmp)], stdin=subprocess.PIPE, stderr=subprocess.DEVNULL,
                           **({"creationflags": 0x08000000} if sys.platform == "win32" else {}))
    rec = [np.zeros((1, 1, 1, 1), dtype=np.float32)] * 4
    ds = np.array([min(1.0, 512 / max(w, h))], dtype=np.float32)
    n = 0
    tam = w * h * 3
    try:
        while True:
            b = dec.stdout.read(tam)
            if len(b) < tam:
                break
            src = np.frombuffer(b, np.uint8).reshape(h, w, 3).transpose(2, 0, 1)[None].astype(np.float32) / 255.0
            out = sess.run(None, {"src": src, "r1i": rec[0], "r2i": rec[1], "r3i": rec[2], "r4i": rec[3], "downsample_ratio": ds})
            pha, rec = out[1], out[2:6]
            enc.stdin.write((np.clip(pha[0, 0], 0, 1) * 255 + 0.5).astype(np.uint8).tobytes())
            n += 1
            if progresso and n % 10 == 0:
                progresso(min(0.99, n / n_total), f"Tirando o fundo com IA… {n} de ~{n_total} quadros")
    finally:
        enc.stdin.close()
        enc.wait()
        dec.stdout.close()
        dec.wait()
    if n == 0 or enc.returncode != 0:
        tmp.unlink(missing_ok=True)
        raise RuntimeError("a IA não conseguiu ler o vídeo")
    tmp.replace(saida)
    return "placa de vídeo" if prov != "CPUExecutionProvider" else "processador"


def _hex(c: str) -> str:
    c = str(c or "#00FF00").lstrip("#")
    return c if len(c) == 6 else "00FF00"


def mascara_chroma(fonte: Path, saida: Path, fps: float, ch: dict, progresso=None) -> None:
    W, H, _, dur = _medidas(fonte)
    w, h = _tam_trabalho(W, H, 1080)
    tol = max(0.01, min(0.9, float(ch.get("tol", 0.3))))
    suave = max(0.0, min(0.5, float(ch.get("suave", 0.08))))
    tmp = saida.with_name(saida.stem + ".parcial.mkv")
    rodar_ffmpeg(["-i", str(fonte), "-an", "-vf",
                  f"fps={fps:.6f},scale={w}:{h},format=yuva444p,chromakey=0x{_hex(ch.get('cor'))}:{tol:.3f}:{suave:.3f},"
                  f"alphaextract,format=gray", "-c:v", "libx264", "-preset", "veryfast", "-crf", "16", "-pix_fmt", "gray",
                  str(tmp)], duracao=dur, rotulo="tela verde")
    tmp.replace(saida)


def previa_alpha(previa: Path, mascara: Path, saida: Path) -> None:
    """Prévia com transparência (VP9 + alfa): toca no Edge/Chrome/janela do Estúdio."""
    w, h, fps, dur = _medidas(previa)
    tmp = saida.with_name(saida.stem + ".parcial.webm")
    rodar_ffmpeg(["-i", str(previa), "-i", str(mascara), "-filter_complex",
                  f"[1:v]scale={w}:{h}:flags=bilinear,format=gray,setpts=PTS-STARTPTS[m];"
                  f"[0:v]setpts=PTS-STARTPTS,format=yuv420p[c];[c][m]alphamerge,format=yuva420p[v]",
                  "-map", "[v]", "-an", "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p", "-deadline", "realtime",
                  "-cpu-used", "8", "-row-mt", "1", "-crf", "36", "-b:v", "0", "-auto-alt-ref", "0", "-g", "30",
                  str(tmp)], duracao=dur, rotulo="prévia sem fundo")
    tmp.replace(saida)


def gerar(fonte: Path, previa: Path, pasta: Path, cfg_fundo: dict, fps: float, progresso=None) -> dict:
    """Faz a máscara e a prévia (se ainda não existem). Devolve {chave, mascara, previa, onde}."""
    ch = chave(cfg_fundo, fonte)
    mascara, alpha = arquivos(pasta, ch)
    onde = ""
    if not (mascara.exists() and mascara.stat().st_size > 0):
        for velho in pasta.glob("mascara_*.mkv"):
            velho.unlink(missing_ok=True)
        if cfg_fundo.get("metodo") == "chroma":
            if progresso:
                progresso(0.1, "Tirando a tela verde…")
            mascara_chroma(fonte, mascara, fps, cfg_fundo.get("chroma") or {}, progresso)
        else:
            onde = mascara_ia(fonte, mascara, fps, progresso)
    if previa and Path(previa).exists() and not (alpha.exists() and alpha.stat().st_size > 0):
        for velho in pasta.glob("previa_alpha_*.webm"):
            velho.unlink(missing_ok=True)
        if progresso:
            progresso(0.99, "Preparando a prévia sem fundo…")
        previa_alpha(previa, mascara, alpha)
    return {"chave": ch, "mascara": mascara, "previa": alpha, "onde": onde}


def mascara_existente(pasta: Path, cfg_fundo: dict, fonte: Path) -> Path | None:
    m, _ = arquivos(pasta, chave(cfg_fundo, fonte))
    return m if m.exists() and m.stat().st_size > 0 else None


def avisar(msg: str) -> None:
    aviso(msg)
