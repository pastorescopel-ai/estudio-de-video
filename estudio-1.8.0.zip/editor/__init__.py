"""Editor automático de vídeos falados."""

VERSAO = "1.8.0"   # muda a cada atualização: o Estúdio antigo que estiver aberto é substituído sozinho
