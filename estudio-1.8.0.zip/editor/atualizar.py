"""Atualização automática do Estúdio pelo GitHub.

Cada versão publicada deixa na raiz do repositório (ramo main):
  atualizacao.json  -> {"versao", "arquivo", "sha256", "tamanho", "notas"}
  estudio-<versao>.zip -> só o programa (editor/, emojis, fontes, stickers e sons prontos, .bat ...)

O Estúdio confere ao abrir (e a cada 6 h), avisa na janela e, quando a pessoa clica em
"Atualizar agora": baixa, confere o sha256, guarda uma cópia da versão atual, troca os
arquivos, instala bibliotecas novas (se mudaram), testa se abre e reinicia. Se algo der
errado, volta a versão anterior. Projetos, biblioteca, config.yaml, .env, músicas, logos,
vinhetas e stickers/sons próprios nunca são tocados."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

from .util import RAIZ, aviso, info

REPO_PADRAO = "pastorescopel-ai/estudio-de-video"
# o que uma atualização pode substituir (o resto é da pessoa)
PERMITIDOS = ("editor/", "emojis/", "fontes/", "stickers/texto/", "stickers/LEIA-ME.txt",
              "sons/LEIA-ME.txt", "LEIA-ME.md", "requirements.txt", "requirements-nvidia.txt", "estudio.ico",
              "estudio.png", "ABRIR_ESTUDIO.bat", "EDITAR_VIDEO.bat", "INSTALAR.bat", "instalar.ps1",
              "config.yaml.novo")
# não vão nas atualizações (quase nunca mudam e o Windows pode estar usando): só no instalador
FORA_DO_PACOTE = ("fontes/", "estudio.ico", "estudio.png")
PASTA = RAIZ / ".atualizacao"


def _versao(v: str) -> tuple:
    out = []
    for p in str(v or "0").lstrip("vV").split("."):
        num = "".join(c for c in p if c.isdigit())
        out.append(int(num) if num else 0)
    return tuple(out + [0] * (4 - len(out)))


def repo(cfg: dict) -> str:
    return str((cfg.get("atualizacao") or {}).get("repo") or os.environ.get("ESTUDIO_REPO") or REPO_PADRAO).strip("/")


def url_base(cfg: dict) -> str:
    base = (cfg.get("atualizacao") or {}).get("url")   # para testes ou outro servidor
    return str(base).rstrip("/") if base else f"https://raw.githubusercontent.com/{repo(cfg)}/main"


def _baixar(url: str, timeout: int = 20) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "EstudioDeVideo", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


class Atualizador:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.trava = threading.Lock()
        self.disponivel: dict | None = None
        self.conferido_em = 0.0
        self.erro_conferir = ""
        self.estado = {"fase": "parado", "pct": 0, "msg": ""}

    # ------------------------------------------------------------ conferir
    def ligado(self) -> bool:
        return (self.cfg.get("atualizacao") or {}).get("verificar", True) is not False

    def conferir(self, forcar: bool = False) -> dict:
        from . import VERSAO
        if not forcar and time.time() - self.conferido_em < 6 * 3600:
            return self.resumo()
        self.conferido_em = time.time()
        try:
            d = json.loads(_baixar(url_base(self.cfg) + "/atualizacao.json").decode("utf-8-sig"))
            self.erro_conferir = ""
            self.disponivel = d if _versao(d.get("versao")) > _versao(VERSAO) else None
            if self.disponivel:
                info(f"Atualização disponível: versão {d.get('versao')}")
        except Exception as e:  # noqa: BLE001
            self.erro_conferir = str(e)[:200]
        return self.resumo()

    def resumo(self) -> dict:
        from . import VERSAO
        d = self.disponivel or {}
        return {"atual": VERSAO, "nova": d.get("versao"), "notas": d.get("notas", ""),
                "tamanho": d.get("tamanho"), "estado": self.estado, "erro": self.erro_conferir,
                "repo": repo(self.cfg)}

    def conferir_em_segundo_plano(self):
        def laco():
            time.sleep(8)
            while True:
                if self.ligado():
                    self.conferir(forcar=True)
                time.sleep(6 * 3600)
        threading.Thread(target=laco, daemon=True).start()

    # ------------------------------------------------------------ aplicar
    def _fase(self, fase: str, msg: str, pct: float = 0):
        self.estado = {"fase": fase, "pct": round(pct), "msg": msg}
        info(f"Atualização: {msg}")

    def iniciar(self) -> dict:
        with self.trava:
            if self.estado["fase"] in ("baixando", "instalando", "testando", "reiniciando"):
                return {"ok": True, "ja": True}
            if not self.disponivel:
                self.conferir(forcar=True)
            if not self.disponivel:
                return {"ok": False, "erro": "Você já está na versão mais nova."}
            self._fase("baixando", "Baixando a atualização…", 0)
        threading.Thread(target=self._aplicar, args=(dict(self.disponivel),), daemon=True).start()
        return {"ok": True}

    def _aplicar(self, d: dict):
        from . import VERSAO
        backup = PASTA / f"anterior_{VERSAO}"
        trocados: list[str] = []
        novos: list[str] = []
        try:
            PASTA.mkdir(exist_ok=True)
            zipf = PASTA / "pacote.zip"
            self._baixar_com_progresso(url_base(self.cfg) + "/" + d["arquivo"], zipf, int(d.get("tamanho") or 0))
            h = hashlib.sha256(zipf.read_bytes()).hexdigest()
            if h.lower() != str(d.get("sha256", "")).lower():
                raise RuntimeError("o arquivo baixado veio diferente do publicado (sha256 não confere)")
            self._fase("instalando", "Instalando…", 0)
            with zipfile.ZipFile(zipf) as z:
                nomes = [n for n in z.namelist() if not n.endswith("/")]
                for n in nomes:
                    if ".." in Path(n).parts or Path(n).is_absolute() or not n.startswith(PERMITIDOS):
                        raise RuntimeError(f"arquivo fora do permitido no pacote: {n}")
                req_antes = (RAIZ / "requirements.txt").read_bytes() if (RAIZ / "requirements.txt").exists() else b""
                nv_antes = (RAIZ / "requirements-nvidia.txt").read_bytes() if (RAIZ / "requirements-nvidia.txt").exists() else b""
                if backup.exists():
                    shutil.rmtree(backup, ignore_errors=True)
                for k, n in enumerate(nomes):
                    alvo = RAIZ / n
                    self.estado["pct"] = round(100 * (k + 1) / len(nomes))
                    if alvo.exists() and alvo.stat().st_size == z.getinfo(n).file_size:
                        with z.open(n) as src:
                            if src.read() == alvo.read_bytes():
                                continue   # igual: nem mexe (o Windows não deixa trocar arquivo em uso)
                    if alvo.exists():
                        (backup / n).parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(alvo, backup / n)
                        trocados.append(n)
                    else:
                        novos.append(n)
                    alvo.parent.mkdir(parents=True, exist_ok=True)
                    tmp = alvo.with_name(alvo.name + ".novo_tmp")
                    with z.open(n) as src, open(tmp, "wb") as dst:
                        shutil.copyfileobj(src, dst)
                    os.replace(tmp, alvo)
                    self.estado["pct"] = round(100 * (k + 1) / len(nomes))
            # bibliotecas novas
            if (RAIZ / "requirements.txt").read_bytes() != req_antes or (
                    (RAIZ / "requirements-nvidia.txt").exists()
                    and (RAIZ / "requirements-nvidia.txt").read_bytes() != nv_antes and self._tem_nvidia()):
                self._fase("instalando", "Instalando bibliotecas novas (pode levar alguns minutos)…", 0)
                self._instalar_bibliotecas()
            self._fase("testando", "Conferindo se a versão nova abre…", 100)
            r = subprocess.run([self._python(), "-c", "import editor.estudio, editor.main; from editor import VERSAO; print(VERSAO)"],
                               cwd=RAIZ, capture_output=True, text=True, timeout=180, **_sem_janela())
            if r.returncode != 0 or r.stdout.strip() != str(d["versao"]):
                raise RuntimeError("a versão nova não abriu: " + (r.stderr.strip().splitlines() or ["?"])[-1][:200])
            zipf.unlink(missing_ok=True)
            self._fase("reiniciando", f"Pronto! Reiniciando na versão {d['versao']}…", 100)
            time.sleep(0.5)
            self._reiniciar()
        except Exception as e:  # noqa: BLE001
            aviso(f"Atualização falhou: {e}")
            for n in trocados:   # volta tudo como estava
                try:
                    shutil.copy2(backup / n, RAIZ / n)
                except Exception:  # noqa: BLE001
                    pass
            for n in novos:
                try:
                    (RAIZ / n).unlink(missing_ok=True)
                except Exception:  # noqa: BLE001
                    pass
            self._fase("erro", f"Não consegui atualizar: {e}. Nada foi alterado — a versão {VERSAO} continua.", 0)

    def _baixar_com_progresso(self, url: str, destino: Path, total: int):
        req = urllib.request.Request(url, headers={"User-Agent": "EstudioDeVideo"})
        with urllib.request.urlopen(req, timeout=60) as r, open(destino, "wb") as f:
            total = int(r.headers.get("Content-Length") or total or 0)
            feito = 0
            while True:
                b = r.read(256 * 1024)
                if not b:
                    break
                f.write(b)
                feito += len(b)
                if total:
                    self.estado["pct"] = round(100 * feito / total)
                    self.estado["msg"] = f"Baixando a atualização… {feito / 1e6:.1f} de {total / 1e6:.1f} MB"

    # ------------------------------------------------------------ apoio
    @staticmethod
    def _python() -> str:
        exe = Path(sys.executable)
        if exe.name.lower() == "pythonw.exe" and (exe.parent / "python.exe").exists():
            return str(exe.parent / "python.exe")
        return str(exe)

    @staticmethod
    def _tem_nvidia() -> bool:
        import importlib.util
        try:
            return importlib.util.find_spec("nvidia") is not None
        except Exception:  # noqa: BLE001
            return False

    def _instalar_bibliotecas(self):
        reqs = ["-r", str(RAIZ / "requirements.txt")]
        if self._tem_nvidia() and (RAIZ / "requirements-nvidia.txt").exists():
            reqs += ["-r", str(RAIZ / "requirements-nvidia.txt")]
        uv = RAIZ / "tools" / ("uv.exe" if sys.platform == "win32" else "uv")
        env = {**os.environ, "UV_CACHE_DIR": str(RAIZ / ".cache" / "uv")}
        cmd = ([str(uv), "pip", "install", "--python", self._python(), *reqs] if uv.exists()
               else [self._python(), "-m", "pip", "install", "--disable-pip-version-check", *reqs])
        r = subprocess.run(cmd, cwd=RAIZ, capture_output=True, text=True, timeout=1800, env=env, **_sem_janela())
        if r.returncode != 0:
            raise RuntimeError("não consegui instalar as bibliotecas novas: " + (r.stderr.strip().splitlines() or ["?"])[-1][:200])

    def _reiniciar(self):
        """Abre a versão nova (sem janela nova: a janela atual recarrega sozinha). Ela fecha esta."""
        exe = Path(sys.executable)
        pyw = exe.parent / "pythonw.exe"
        cmd = [str(pyw if sys.platform == "win32" and pyw.exists() else exe), "-m", "editor", "--sem-janela"]
        kw: dict = {"cwd": str(RAIZ), "stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
        if sys.platform == "win32":
            kw["creationflags"] = 0x00000008 | 0x00000200   # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
        else:
            kw["start_new_session"] = True
        subprocess.Popen(cmd, **kw)


def _sem_janela() -> dict:
    return {"creationflags": 0x08000000} if sys.platform == "win32" else {}   # CREATE_NO_WINDOW


# ---------------------------------------------------------------- publicar (usado por quem desenvolve)
def montar_pacote(origem: Path, destino_pasta: Path, versao: str, notas: str) -> tuple[Path, Path]:
    """Gera estudio-<versao>.zip e atualizacao.json a partir de uma pasta do programa (o 'pacote')."""
    destino_pasta.mkdir(parents=True, exist_ok=True)
    zipf = destino_pasta / f"estudio-{versao}.zip"
    with zipfile.ZipFile(zipf, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(origem.rglob("*")):
            if not f.is_file() or "__pycache__" in f.parts:
                continue
            rel = f.relative_to(origem).as_posix()
            if rel == "config.yaml":
                z.write(f, "config.yaml.novo")
            elif rel.startswith(PERMITIDOS) and not rel.startswith(FORA_DO_PACOTE):
                z.write(f, rel)
    dados = {"versao": versao, "arquivo": zipf.name, "sha256": hashlib.sha256(zipf.read_bytes()).hexdigest(),
             "tamanho": zipf.stat().st_size, "notas": notas, "publicado": time.strftime("%Y-%m-%d")}
    js = destino_pasta / "atualizacao.json"
    js.write_text(json.dumps(dados, ensure_ascii=False, indent=2), encoding="utf-8")
    return zipf, js


if __name__ == "__main__":   # python -m editor.atualizar <pasta_pacote> <saida> <versao> "<notas>"
    a = sys.argv[1:]
    print(montar_pacote(Path(a[0]), Path(a[1]), a[2], a[3] if len(a) > 3 else ""))
