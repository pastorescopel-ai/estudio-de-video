"""Estúdio: um programa só, sempre ligado.

- vigia a pasta de entrada;
- uma fila de trabalhos pesados, um de cada vez (preparar vídeo, exportar, juntar partes, arquivar),
  para a placa de vídeo não ser disputada;
- serve a interface (estilo CapCut) em http://127.0.0.1:8765 e abre como um aplicativo.
"""
from __future__ import annotations

import argparse
import json
import mimetypes
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from . import atualizar, ia, media, organizer, render, util
from .main import PRINCIPAL, Projeto, abrir_pasta, arquivar, gerar
from .util import RAIZ, aviso, carregar_config, exigir_ffmpeg, info, ler_json, salvar_json

PAGINA = Path(__file__).with_name("estudio.html")
PORTA_PADRAO = 8765
FASES_ATIVAS = ("na_fila", "preparando", "revisao", "exportando", "pronto", "juntando", "arquivando", "erro")


class Item:
    """Um vídeo no estúdio: estado visível na tela inicial + o Projeto com todo o trabalho."""

    def __init__(self, video: Path, pid: str):
        self.video = video
        self.id = pid
        self.pj: Projeto | None = None
        self.status = {"fase": "na_fila", "etapa": "Na fila", "rotulo": "", "frac": 0.0, "erro": "",
                       "arquivos": [], "pasta": "", "versao": 0}
        self.titulo = ""
        self.tema = ""
        self.criado = time.time()
        self.atualizado = time.time()
        self.duracao = 0.0

    def resumo(self) -> dict:
        thumb = ""
        if self.pj and (self.pj.base / "capa.jpg").exists():
            thumb = f"/api/p/{self.id}/capa.jpg"
        return {"id": self.id, "nome": self.video.name, "titulo": self.titulo, "tema": self.tema,
                "duracao": self.duracao, "capa": thumb, "criado": self.criado, "atualizado": self.atualizado,
                **self.status}


class Estudio:
    def __init__(self, cfg: dict, args):
        self.cfg, self.args = cfg, args
        self.itens: dict[str, Item] = {}
        self.ordem: list[str] = []
        self.jobs: queue.Queue = queue.Queue()
        self.trava = threading.RLock()
        self.atual: Item | None = None
        self.ultimo_contato = 0.0           # última vez que a tela pediu o estado (para saber se está aberta)
        self.atualizador = atualizar.Atualizador(cfg)
        self.janela_pid: int | None = None
        self.focar_janela = False
        self.porta = int(cfg.get("revisao", {}).get("porta", PORTA_PADRAO))
        util.OUVINTES.append(self._progresso)
        self.historico_arq = None
        if organizer.ativa(cfg):
            _, dst = organizer.pastas(cfg)
            (dst / "_trabalho").mkdir(parents=True, exist_ok=True)
            self.historico_arq = dst / "_trabalho" / "historico.json"
        self.historico: list[dict] = ler_json(self.historico_arq) if self.historico_arq and self.historico_arq.exists() else []
        self.arquivados: dict[str, Item] = {}

    # ================================================================= estado
    def _progresso(self, tipo, msg, frac):
        it = self.atual
        if not it:
            return
        with self.trava:
            if tipo == "etapa":
                it.status.update(etapa=msg, frac=0.0, rotulo="")
            else:
                it.status.update(rotulo=msg, frac=frac)
            it.atualizado = time.time()

    def fase(self, it: Item, fase: str, **extra):
        with self.trava:
            it.status["fase"] = fase
            it.status.update(extra)
            it.atualizado = time.time()
        self._salvar_item(it)

    def _salvar_item(self, it: Item):
        if it.pj:
            salvar_json(it.pj.trab / "projeto.json", {
                "video": str(it.video), "fase": it.status["fase"], "titulo": it.titulo, "tema": it.tema,
                "criado": it.criado, "duracao": it.duracao})

    # ================================================================= projetos
    def adicionar(self, video: Path, restaurar: dict | None = None) -> Item | None:
        video = video.resolve()
        try:
            pid = organizer.impressao_digital(video) if organizer.ativa(self.cfg) else re.sub(r"\W+", "_", video.stem)
        except OSError:
            return None
        with self.trava:
            if pid in self.itens:
                it = self.itens[pid]
                it.video = video
                return it
            it = Item(video, pid)
            if restaurar:
                it.titulo, it.tema = restaurar.get("titulo", ""), restaurar.get("tema", "")
                it.criado = restaurar.get("criado", it.criado)
            self.itens[pid] = it
            self.ordem.append(pid)
        info(f"Novo vídeo na fila: {video.name}")
        self.jobs.put(("preparar", it, {}))
        return it

    def restaurar(self):
        """Ao abrir o estúdio de novo, recupera os vídeos que estavam em edição."""
        if not organizer.ativa(self.cfg):
            return
        _, dst = organizer.pastas(self.cfg)
        for arq in sorted((dst / "_trabalho").glob("*/projeto.json"), key=lambda p: p.stat().st_mtime):
            try:
                d = ler_json(arq)
            except Exception:  # noqa: BLE001
                continue
            v = Path(d.get("video", ""))
            if d.get("fase") in FASES_ATIVAS and d.get("fase") != "na_fila" and v.is_file():
                self.adicionar(v, d)

    # ================================================================= trabalhador (um de cada vez)
    def trabalhador(self):
        while True:
            acao, it, corpo = self.jobs.get()
            self.atual = it
            try:
                getattr(self, f"_job_{acao}")(it, corpo)
            except BaseException as e:  # noqa: BLE001
                msg = str(e) or e.__class__.__name__
                aviso(f"{it.video.name}: {msg[:300]}")
                it.status["log"] = registrar_erro(it.video, acao, e)
                fase_erro = "revisao" if acao in ("exportar", "juntar") and it.pj and it.pj.palavras else "erro"
                self.fase(it, fase_erro, erro=msg[-1500:], etapa="Erro: " + msg.splitlines()[0][:120])
            finally:
                self.atual = None

    def _job_preparar(self, it: Item, _):
        self.fase(it, "preparando", etapa="Lendo o vídeo…", erro="")
        cfg = carregar_config()
        self.cfg = cfg
        it.pj = pj = Projeto(it.video, cfg, self.args)
        pj.pronto = False
        it.duracao = pj.iv_original["duracao"]
        self._capa(pj)
        pj.montar_fonte()
        t_prev = pj.iniciar_previa()
        pj.preparar_conteudo()
        pj.iniciar_rastro()
        util.etapa(3, 3, "Preparando a linha do tempo")
        pj.gerar_quadros()
        pj.onda()
        t_prev.join()
        if pj.erros_bg:
            raise pj.erros_bg[0]
        est = self.estado_salvo(pj)
        it.titulo = (est or {}).get("titulo") or pj.meta.get("titulo", it.video.stem)
        it.tema = (est or {}).get("tema") or pj.meta.get("tema", "")
        existentes = [f for f in pj.saida.glob("*.mp4")]
        pj.pronto = True
        self.fase(it, "pronto" if existentes else "revisao", etapa="Pronto para revisar",
                  arquivos=self._arquivos(pj) if existentes else [])
        self._chamar_atencao()

    def _job_exportar(self, it: Item, estado: dict):
        self.fase(it, "exportando", etapa="Começando a exportação…", erro="")
        it.pj.cfg = carregar_config()
        if it.pj.t_rosto:
            it.pj.t_rosto.join()
        arquivos = gerar(it.pj, estado)
        self.fase(it, "pronto", etapa="Vídeos prontos", arquivos=arquivos)

    def _job_juntar(self, it: Item, corpo: dict):
        pj = it.pj
        self.fase(it, "juntando", etapa="Juntando as partes da fala…", erro="")
        estado = corpo.get("estado") or self.estado_salvo(pj)
        antigas, palavras_antigas = list(pj.partes), list(pj.palavras)
        pj.partes = [p for p in corpo.get("partes", []) if p.get("id")]
        if not any(p["id"] == PRINCIPAL for p in pj.partes):
            pj.partes.insert(0, {"id": PRINCIPAL, "nome": it.video.name})
        salvar_json(pj.trab / "partes.json", pj.partes)
        pj.montar_fonte()
        t_prev = pj.iniciar_previa()
        pj.preparar_conteudo()
        pj.iniciar_rastro()
        pj.gerar_quadros()
        pj.onda()
        estado = pj.remapear_estado(estado, antigas, palavras_antigas)
        if estado:
            salvar_json(pj.trab / "edicao.json", estado)
        t_prev.join()
        it.status["versao"] += 1
        self.fase(it, "revisao", etapa="Partes juntadas")

    def _job_arquivar(self, it: Item, estado: dict):
        self.fase(it, "arquivando", etapa="Arquivando na biblioteca…")
        salvar_json(it.pj.trab / "edicao.json", estado)
        pasta = arquivar(it.pj, estado)
        self.fase(it, "concluido", etapa="Arquivado", pasta=str(pasta))
        self.historico.insert(0, {"id": it.id, "titulo": estado.get("titulo") or it.titulo,
                                  "tema": estado.get("tema") or it.tema, "pasta": str(pasta),
                                  "quando": time.time(), "duracao": it.duracao,
                                  "capa": f"/api/p/{it.id}/capa.jpg"})
        self.historico = self.historico[:200]
        if self.historico_arq:
            salvar_json(self.historico_arq, self.historico)
        with self.trava:
            self.itens.pop(it.id, None)
            if it.id in self.ordem:
                self.ordem.remove(it.id)
            self.arquivados[it.id] = it

    def _capa(self, pj: Projeto):
        capa = pj.base / "capa.jpg"
        if not capa.exists():
            from .util import rodar_ffmpeg
            try:
                t = min(2.0, pj.iv_original["duracao"] / 3)
                rodar_ffmpeg(["-ss", f"{t:.2f}", "-i", str(pj.video), "-frames:v", "1", "-vf", "scale=-2:240",
                              str(capa)])
            except Exception:  # noqa: BLE001
                pass

    def _arquivos(self, pj: Projeto) -> list[dict]:
        out = []
        for nome in render.FORMATOS:
            f = pj.saida / f"{nome}.mp4"
            if f.exists():
                out.append({"formato": nome, "rotulo": render.FORMATOS[nome][2], "url": f"/saida/{f.name}",
                            "tamanho": f"{f.stat().st_size / 1e6:.1f} MB"})
        return out

    @staticmethod
    def estado_salvo(pj: Projeto) -> dict | None:
        arq = pj.trab / "edicao.json"
        return ler_json(arq) if arq.exists() else None

    def _chamar_atencao(self):
        """Vídeo pronto para revisar e a janela do estúdio não está aberta? Abre."""
        if time.time() - self.ultimo_contato > 15 and not self.args.sem_janela_auto:
            self.mostrar_janela()

    def mostrar_janela(self):
        """Uma janela só: se já está aberta, traz para a frente; senão abre."""
        if self.janela_pid and _processo_vivo(self.janela_pid):
            self.focar_janela = True
            return
        self.janela_pid = None
        abrir_janela(self.porta)

    # ================================================================= vigia
    def vigiar(self):
        ent, dst = organizer.pastas(self.cfg)
        for p in (ent, dst, ent / "_pausados", ent / "_com_erro"):
            p.mkdir(parents=True, exist_ok=True)
        vistos: dict = {}
        conhecidos: set = set()
        intervalo = int(self.cfg.get("biblioteca", {}).get("verificar_a_cada", 10))
        while True:
            try:
                for f in sorted(ent.rglob("*")):
                    if (not f.is_file() or f.suffix.lower() not in organizer.EXTENSOES
                            or any(p in organizer.IGNORAR for p in f.relative_to(ent).parts)):
                        continue
                    chave = (str(f), f.stat().st_size)
                    if chave in conhecidos or not organizer._estavel(f, vistos):
                        continue
                    conhecidos.add(chave)
                    self.adicionar(f)
            except Exception as e:  # noqa: BLE001
                aviso(f"Vigia: {e}")
            time.sleep(intervalo)

    # ================================================================= servidor
    def servir(self):
        est = self

        def item(pid) -> Item | None:
            with est.trava:
                return est.itens.get(pid) or est.arquivados.get(pid)

        class H(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *a):
                pass

            # -------------------------------------------------- GET
            def do_GET(self):
                u = urlparse(self.path)
                c = unquote(u.path)
                if c in ("/", "/index.html"):
                    return self._enviar(200, PAGINA.read_bytes(), "text/html; charset=utf-8")
                if c in ("/favicon.ico", "/icone.png"):
                    return self._arquivo(RAIZ / ("estudio.ico" if c.endswith("ico") else "estudio.png"))
                if c == "/api/atualizacao":   # a janela pergunta; se faz tempo, confere de novo no GitHub
                    atu = est.atualizador
                    if atu.ligado() and time.time() - atu.conferido_em > 15 * 60 and atu.estado["fase"] == "parado":
                        atu.conferido_em = time.time()
                        threading.Thread(target=atu.conferir, kwargs={"forcar": True}, daemon=True).start()
                    return self._json(atu.resumo())
                if c == "/api/ping":
                    from . import VERSAO
                    return self._json({"ok": True, "app": "estudio", "versao": VERSAO})
                if c == "/api/estado":
                    est.ultimo_contato = time.time()
                    with est.trava:
                        lista = [est.itens[p].resumo() for p in est.ordem if p in est.itens]
                        atual = est.atual.id if est.atual else None
                    ent, dst = organizer.pastas(est.cfg)
                    focar, est.focar_janela = est.focar_janela, False
                    return self._json({"projetos": lista, "atual": atual, "historico": est.historico[:60],
                                       "ia": ia.descricao(est.cfg), "entrada": str(ent), "biblioteca": str(dst),
                                       "fila": est.jobs.qsize(), "focar": focar})
                if c.startswith("/stickers/") or c.startswith("/sons/"):
                    from . import biblioteca
                    return self._arquivo(biblioteca.arquivo_publico(c))
                if c == "/api/stickers":
                    from . import biblioteca
                    return self._json(biblioteca.listar_stickers())
                if c == "/api/stickers_populares":
                    from . import biblioteca
                    return self._json(biblioteca.stickers_populares())
                if c == "/api/sons":
                    from . import biblioteca
                    return self._json(biblioteca.listar_sons())
                if c.startswith("/emojis/") and c.endswith(".png"):
                    return self._arquivo(RAIZ / "emojis" / Path(c).name)
                if c == "/api/modelos_legenda":
                    from . import legenda_modelos
                    return self._json(legenda_modelos.listar())
                if c == "/api/fontes":
                    from .subtitles import catalogo_fontes
                    return self._json(catalogo_fontes())
                if c.startswith("/fontes/") or c.startswith("/musica/") or c == "/logo":
                    for f in render.arquivos_de_fonte():
                        if c == f"/fontes/{f.name}":
                            return self._arquivo(f)
                    for m in render.listar_musicas():
                        if c == f"/musica/{m.name}":
                            return self._arquivo(m)
                    logo = util.caminho_cfg(est.cfg.get("logo", {}).get("arquivo"))
                    if c == "/logo" and logo and logo.is_file():
                        return self._arquivo(logo)
                    return self._enviar(404, b"", "text/plain")
                m = re.match(r"^/api/p/([\w-]+)(/.*)?$", c)
                if m:
                    it = item(m.group(1))
                    resto = m.group(2) or ""
                    if not it:
                        return self._enviar(404, b"", "text/plain")
                    pj = it.pj
                    if resto == "/capa.jpg" and pj:
                        return self._arquivo(pj.base / "capa.jpg")
                    ocupado = it.status["fase"] in ("na_fila", "preparando", "juntando") and not getattr(pj, "pronto", False)
                    previa_ok = bool(pj and getattr(pj, "previa", None) and Path(pj.previa).is_file())
                    if not pj or ((not pj.palavras or ocupado) and not previa_ok):
                        return self._json({"ok": False, "fase": it.status["fase"]}, 409)
                    if resto in ("", "/") and (ocupado or not pj.palavras):
                        # modo "abrir já": a prévia existe, mas a transcrição ainda não terminou
                        dados = pj.montar_dados(est.estado_salvo(pj))
                        dados.update(id=it.id, versao=it.status["versao"], fase=it.status["fase"], provisorio=True,
                                     palavras=[], cortes=[], ia=ia.descricao(est.cfg), passo_quadros=pj.PASSO_QUADROS,
                                     n_quadros=len(list((pj.base / "quadros").glob("*.jpg"))))
                        return self._json(dados)
                    if resto in ("", "/"):
                        dados = pj.montar_dados(est.estado_salvo(pj))
                        dados.update(id=it.id, versao=it.status["versao"], fase=it.status["fase"],
                                     ia=ia.descricao(est.cfg), passo_quadros=pj.PASSO_QUADROS,
                                     n_quadros=len(list((pj.base / "quadros").glob("*.jpg"))))
                        return self._json(dados)
                    if resto == "/video":
                        return self._arquivo(pj.previa if hasattr(pj, "previa") else pj.base / "previa.mp4")
                    if resto == "/rosto":
                        return self._json(pj.rastro.get("r", []))
                    if resto == "/onda":
                        return self._json(pj.onda())
                    if resto.startswith("/quadros/"):
                        return self._arquivo(pj.base / "quadros" / Path(resto[9:]).name)
                    if resto.startswith("/midia/"):
                        return self._arquivo(pj.midia / Path(resto[7:]).name)
                    if resto.startswith("/saida/"):
                        return self._arquivo(pj.saida / Path(resto[7:]).name)
                    if resto in pj.extras:
                        return self._arquivo(pj.extras[resto])
                return self._enviar(404, b"", "text/plain")

            # -------------------------------------------------- POST
            def do_POST(self):
                n = int(self.headers.get("Content-Length", 0))
                try:
                    corpo = json.loads((self.rfile.read(n) if n else b"{}").decode("utf-8") or "{}")
                except json.JSONDecodeError:
                    corpo = {}
                c = urlparse(self.path).path
                if c == "/api/adicionar":
                    feitos = [it.id for it in (est.adicionar(Path(p)) for p in corpo.get("caminhos", [])) if it]
                    return self._json({"ok": True, "ids": feitos})
                if c == "/api/chave":     # chaves grátis de bancos de imagens (Pixabay, Pexels)
                    nome_k = str(corpo.get("nome", ""))
                    if nome_k not in ("PIXABAY_API_KEY", "PEXELS_API_KEY", "GIPHY_API_KEY", "FREESOUND_API_KEY"):
                        return self._json({"ok": False, "erro": "chave desconhecida"}, 400)
                    util.salvar_env(nome_k, re.sub(r"[^\w-]", "", str(corpo.get("valor", "")))[:100])
                    return self._json({"ok": True})
                if c == "/api/chaves":
                    return self._json({"ok": True, "pixabay": bool(os.environ.get("PIXABAY_API_KEY")),
                                       "pexels": bool(os.environ.get("PEXELS_API_KEY")),
                                       "giphy": bool(os.environ.get("GIPHY_API_KEY")),
                                       "freesound": bool(os.environ.get("FREESOUND_API_KEY"))})
                if c in ("/api/sons_buscar", "/api/sons_baixar", "/api/sticker_animado", "/api/gifs", "/api/gif_baixar",
                         "/api/sons_populares"):
                    from . import biblioteca
                    try:
                        if c == "/api/gifs":
                            return self._json({"ok": True, **biblioteca.gifs(str(corpo.get("tipo", "gifs")), str(corpo.get("q", "")),
                                                                            int(corpo.get("inicio") or 0))})
                        if c == "/api/gif_baixar":
                            return self._json({"ok": True, **biblioteca.baixar_gif(
                                str(corpo.get("id", "")), str(corpo.get("url", "")), str(corpo.get("titulo", ""))[:100],
                                str(corpo.get("autor", ""))[:60])})
                        if c == "/api/sons_populares":
                            return self._json({"ok": True, **biblioteca.sons_populares(str(corpo.get("q", "")), int(corpo.get("pagina") or 1))})
                        if c == "/api/sons_buscar":
                            return self._json({"ok": True, **biblioteca.buscar_sons(str(corpo.get("q", ""))[:100])})
                        if c == "/api/sons_baixar":
                            return self._json({"ok": True, **biblioteca.baixar_som(
                                str(corpo.get("url", "")), str(corpo.get("titulo", "som")), str(corpo.get("credito", "")),
                                str(corpo.get("licenca", "")), str(corpo.get("pagina", "")))})
                        return self._json({"ok": True, **biblioteca.baixar_sticker_animado(str(corpo.get("codigo", "")))})
                    except Exception as e:  # noqa: BLE001
                        return self._json({"ok": False, "erro": str(e)[:300]})
                if c == "/api/modelos_legenda":
                    from . import legenda_modelos as lm
                    a = corpo.get("acao")
                    if a == "salvar":
                        return self._json(lm.salvar(corpo.get("nome", ""), corpo.get("estilo") or {}))
                    if a == "apagar":
                        return self._json(lm.apagar(str(corpo.get("id", ""))))
                    if a == "padrao":
                        return self._json(lm.definir_padrao(corpo.get("id")))
                    return self._json(lm.listar())
                if c == "/api/atualizacao":
                    if corpo.get("acao") == "instalar":
                        if est.atual is not None or not est.jobs.empty():
                            nome = f"\"{est.atual.video.name}\"" if est.atual is not None else "o vídeo da fila"
                            return self._json({"ok": False, "erro": f"Espere terminar {nome} que está sendo processado e tente de novo."})
                        return self._json(est.atualizador.iniciar())
                    return self._json(est.atualizador.conferir(forcar=True))
                if c == "/api/janela":         # a janela própria avisa que abriu
                    est.janela_pid = int(corpo.get("pid") or 0) or None
                    return self._json({"ok": True})
                if c == "/api/mostrar_janela":  # clicaram no ícone com o Estúdio já ligado
                    est.mostrar_janela()
                    return self._json({"ok": True})
                if c == "/api/sair":      # um Estúdio mais novo está assumindo
                    self._json({"ok": True})
                    threading.Timer(0.3, lambda: os._exit(0)).start()
                    return None
                if c == "/api/log_cliente":   # erros do player/janela, para o erros.log
                    try:
                        with open(RAIZ / "erros.log", "a", encoding="utf-8") as f:
                            f.write(f"===== {time.strftime('%Y-%m-%d %H:%M:%S')} · janela · {str(corpo.get('msg'))[:2000]}\n"
                                    f"{self.headers.get('User-Agent', '')}\n\n")
                    except Exception:  # noqa: BLE001
                        pass
                    return self._json({"ok": True})
                if c == "/api/abrir_log":
                    arq = RAIZ / "erros.log"
                    if not arq.exists():
                        arq.write_text("Nenhum erro registrado.\n", encoding="utf-8")
                    try:
                        if sys.platform == "win32":
                            os.startfile(arq)  # type: ignore[attr-defined]
                    except Exception:  # noqa: BLE001
                        abrir_pasta(RAIZ)
                    return self._json({"ok": True, "arquivo": str(arq)})
                if c == "/api/abrir_pasta":
                    alvo = corpo.get("pasta") or str(organizer.pastas(est.cfg)[{"entrada": 0}.get(corpo.get("qual"), 1)])
                    abrir_pasta(Path(alvo))
                    return self._json({"ok": True})
                m = re.match(r"^/api/p/([\w-]+)/(\w+)$", c)
                if not m:
                    return self._enviar(404, b"", "text/plain")
                it, acao = item(m.group(1)), m.group(2)
                if not it:
                    return self._json({"ok": False, "erro": "projeto não encontrado"}, 404)
                pj = it.pj
                if acao == "salvar" and pj:
                    if corpo.get("provisorio"):
                        antigo = est.estado_salvo(pj) or {}
                        if antigo and not antigo.get("provisorio"):
                            corpo = {**antigo, "ajustes": corpo.get("ajustes", antigo.get("ajustes")),
                                     "titulo": corpo.get("titulo") or antigo.get("titulo"),
                                     "tema": corpo.get("tema") or antigo.get("tema")}
                    salvar_json(pj.trab / "edicao.json", corpo)
                    it.titulo, it.tema = corpo.get("titulo") or it.titulo, corpo.get("tema") or it.tema
                    est._salvar_item(it)
                    return self._json({"ok": True})
                if acao in ("exportar", "arquivar") and pj:
                    salvar_json(pj.trab / "edicao.json", corpo)
                    it.titulo, it.tema = corpo.get("titulo") or it.titulo, corpo.get("tema") or it.tema
                    est.fase(it, "na_fila", etapa="Na fila para " + ("exportar" if acao == "exportar" else "arquivar"))
                    est.jobs.put((acao, it, corpo))
                    return self._json({"ok": True})
                if acao == "juntar" and pj:
                    est.fase(it, "na_fila", etapa="Na fila para juntar as partes")
                    est.jobs.put(("juntar", it, corpo))
                    return self._json({"ok": True})
                if acao == "pausar":
                    with est.trava:
                        est.itens.pop(it.id, None)
                        if it.id in est.ordem:
                            est.ordem.remove(it.id)
                    if it.pj:
                        it.status["fase"] = "pausado"
                        est._salvar_item(it)
                    ent, _ = organizer.pastas(est.cfg)
                    try:
                        if it.video.exists() and ent in it.video.parents:
                            organizer.mover(it.video, ent / "_pausados" / it.video.name)
                    except OSError:
                        pass
                    return self._json({"ok": True})
                if acao == "personagens" and pj:
                    from . import personagens
                    try:
                        r = personagens.separar(pj.fonte, pj.palavras, max(1, min(6, int(corpo.get("n", 2)))))
                        return self._json({"ok": True, **r})
                    except Exception as e:  # noqa: BLE001
                        registrar_erro(it.video, "personagens", e)
                        return self._json({"ok": False, "erro": str(e)[:300]})
                if acao == "rostos" and pj:
                    from . import rostos
                    try:
                        n = max(1, min(6, int(corpo.get("n", 2))))
                        r = rostos.fotos(pj.fonte, pj.palavras, corpo.get("falas") or [], n, pj.base)
                        fotos = {}
                        for k, info_r in r.items():
                            arq = pj.base / f"personagem_{k}.jpg"
                            pj.extras[f"/personagem_{k}.jpg"] = arq
                            fotos[k] = {**info_r, "url": f"/personagem_{k}.jpg?v={int(arq.stat().st_mtime)}"}
                        return self._json({"ok": True, "fotos": fotos})
                    except Exception as e:  # noqa: BLE001
                        registrar_erro(it.video, "rostos", e)
                        return self._json({"ok": False, "erro": str(e)[:300]})
                if acao == "audio_previa" and pj:
                    from . import voz
                    try:
                        acfg = {k: corpo.get(k) for k in ("limpeza", "melhorar", "volume_voz", "efeito_voz")}
                        trechos = [tuple(x) for x in (corpo.get("trechos") or [])][:2000]
                        arq = voz.audio_previa(pj.fonte, pj.base, acfg, trechos)
                        pj.extras["/audio_previa"] = arq
                        return self._json({"ok": True, "url": f"/api/p/{it.id}/audio_previa?v={arq.stem[-12:]}"})
                    except Exception as e:  # noqa: BLE001
                        registrar_erro(it.video, "audio_previa", e)
                        return self._json({"ok": False, "erro": str(e)[:300]})
                if acao == "duracao":
                    from . import duracao
                    return self._json({"ok": True, **duracao.escolher(corpo.get("frases") or [], float(corpo.get("total", 0)),
                                                                      float(corpo.get("alvo", 45)), est.cfg)})
                if acao == "ganchos":
                    from . import ganchos
                    return self._json({"ok": True, **ganchos.sugerir(corpo.get("falas") or [], corpo.get("titulo", ""),
                                                                     corpo.get("tema", ""), est.cfg)})
                if acao == "buscar_midia":
                    from . import ganchos
                    return self._json({"ok": True, **ganchos.buscar(str(corpo.get("q", ""))[:120],
                                                                    corpo.get("tipo", "imagem"), est.cfg)})
                if acao == "baixar_midia" and pj:
                    from . import ganchos
                    try:
                        arq = ganchos.baixar(str(corpo.get("url", "")), pj.midia, str(corpo.get("nome") or "sugestao"))
                        mi = media.preparar_midia(arq, pj.midia, est.cfg)
                        mi.update({k: str(corpo.get(k, ""))[:400] for k in ("credito", "licenca", "pagina") if corpo.get(k)})
                        pj.registrar_midia(mi)
                        return self._json({"ok": True, "midia": mi})
                    except Exception as e:  # noqa: BLE001
                        registrar_erro(it.video, "baixar_midia", e)
                        return self._json({"ok": False, "erro": str(e)[:300]})
                if acao == "legenda_ia":
                    from . import legenda_modelos as lm
                    return self._json({"ok": True, **lm.chaves_e_emojis(corpo.get("grupos") or [], est.cfg)})
                if acao == "refazer_previa" and pj:   # o navegador não conseguiu tocar a prévia
                    from .review import gerar_previa
                    try:
                        alvo = pj.base / "previa_v2.mp4"
                        pj.previa = alvo
                        velha = alvo.with_name("previa_antiga.mp4")
                        if alvo.exists():
                            alvo.replace(velha)
                        gerar_previa(pj.fonte, alvo, est.cfg, getattr(pj, "iv", None), forcar_cpu=True)
                        velha.unlink(missing_ok=True)
                        it.status["versao"] += 1
                        return self._json({"ok": True})
                    except Exception as e:  # noqa: BLE001
                        registrar_erro(it.video, "refazer_previa", e)
                        return self._json({"ok": False, "erro": str(e)[:300]})
                if acao == "tentar":
                    est.fase(it, "na_fila", etapa="Na fila", erro="")
                    est.jobs.put(("preparar", it, {}))
                    return self._json({"ok": True})
                if acao == "abrir_pasta":
                    abrir_pasta(Path(it.status.get("pasta") or it.video.parent))
                    return self._json({"ok": True})
                if acao == "sugerir_broll" and pj:
                    try:
                        nomes = set(corpo.get("nomes") or [])
                        lista = [x for x in pj.midias() if x["nome"] in nomes]
                        itens = media.sugerir_broll(lista, pj.midia, corpo.get("falas") or [],
                                                    corpo.get("ocupados") or [], est.cfg)
                        for x in lista:  # guarda a descrição que a IA fez de cada imagem
                            pj.registrar_midia(x)
                        return self._json({"ok": True, "itens": itens,
                                           "midias": {x["nome"]: x for x in pj.midias()}})
                    except Exception as e:  # noqa: BLE001
                        return self._json({"ok": False, "erro": str(e)[:300]})
                return self._json({"ok": False, "erro": "ação desconhecida"}, 400)

            # -------------------------------------------------- PUT (envio de arquivos)
            def do_PUT(self):
                u = urlparse(self.path)
                q = parse_qs(u.query)
                nome = media.nome_seguro_arquivo((q.get("nome") or ["arquivo"])[0])
                tamanho = int(self.headers.get("Content-Length", 0))
                if u.path == "/api/importar":   # vídeo cru novo, enviado pela tela inicial
                    ent, _ = organizer.pastas(est.cfg)
                    destino = ent / nome
                    self._receber(destino, tamanho)
                    it = est.adicionar(destino)
                    return self._json({"ok": bool(it), "id": it.id if it else None})
                if u.path == "/api/musica":            # música de fundo importada pelo editor
                    destino = RAIZ / "musica" / nome
                    if destino.suffix.lower() not in render.EXT_MUSICA:
                        return self._json({"ok": False, "erro": "use um arquivo de áudio: " + ", ".join(render.EXT_MUSICA)})
                    destino.parent.mkdir(exist_ok=True)
                    self._receber(destino, tamanho)
                    return self._json({"ok": True, "nome": destino.name,
                                       "musicas": [m.name for m in render.listar_musicas()]})
                if u.path == "/api/biblioteca":        # sticker ou som seu, para a coleção
                    from . import biblioteca
                    import tempfile
                    tipo_b = (q.get("tipo") or ["sticker"])[0]
                    tmp = Path(tempfile.gettempdir()) / nome
                    self._receber(tmp, tamanho)
                    try:
                        return self._json({"ok": True, **biblioteca.guardar_enviado("sticker" if tipo_b == "sticker" else "som", tmp)})
                    except Exception as e:  # noqa: BLE001
                        return self._json({"ok": False, "erro": str(e)[:300]})
                if u.path == "/api/copiar_estilo":   # vídeo de exemplo -> modelo de legenda
                    from . import legenda_modelos as lm
                    import tempfile
                    tmp = Path(tempfile.gettempdir()) / f"estudio_ref_{int(time.time())}{Path(nome).suffix or '.mp4'}"
                    self._receber(tmp, tamanho)
                    try:
                        base = Path(nome).stem[:28]
                        return self._json({"ok": True, **lm.copiar_de_video(tmp, est.cfg, f"Estilo de {base}")})
                    except Exception as e:  # noqa: BLE001
                        return self._json({"ok": False, "erro": str(e)[:300]})
                    finally:
                        tmp.unlink(missing_ok=True)
                if u.path == "/api/fonte":      # fonte própria para a legenda
                    from .subtitles import _METRICAS, catalogo_fontes
                    if Path(nome).suffix.lower() not in (".ttf", ".otf"):
                        self._receber(RAIZ / "fontes" / ".descartar", tamanho)
                        (RAIZ / "fontes" / ".descartar").unlink(missing_ok=True)
                        return self._json({"ok": False, "erro": "envie um arquivo .ttf ou .otf"})
                    destino = RAIZ / "fontes" / nome
                    self._receber(destino, tamanho)
                    from .render import _familia_da_fonte
                    fam = _familia_da_fonte(destino)
                    if not fam:
                        destino.unlink(missing_ok=True)
                        return self._json({"ok": False, "erro": "não reconheci esse arquivo como fonte"})
                    _METRICAS.clear()
                    return self._json({"ok": True, "familia": fam, "fontes": catalogo_fontes()})
                m = re.match(r"^/api/p/([\w-]+)/upload$", u.path)
                it = item(m.group(1)) if m else None
                if not it or not it.pj:
                    return self._json({"ok": False, "erro": "projeto não encontrado"}, 404)
                pj = it.pj
                destino = pj.midia / nome
                self._receber(destino, tamanho)
                tipo = (q.get("tipo") or ["broll"])[0]
                try:
                    if tipo == "broll":
                        mi = media.preparar_midia(destino, pj.midia, est.cfg)
                        pj.registrar_midia(mi)
                        return self._json({"ok": True, "midia": mi})
                    if tipo == "fala":
                        return self._json({"ok": True, "parte": {"id": "p" + organizer.impressao_digital(destino),
                                                                 "nome": destino.name}})
                    if tipo in ("abertura", "encerramento"):
                        media.PASTA_VINHETAS.mkdir(exist_ok=True)
                        for f in media.PASTA_VINHETAS.iterdir():
                            if f.stem.lower() == tipo:
                                f.unlink()
                        shutil.move(str(destino), media.PASTA_VINHETAS / f"{tipo}{destino.suffix.lower()}")
                        return self._json({"ok": True, "vinhetas": pj.vinhetas_dados()})
                    return self._json({"ok": False, "erro": "tipo desconhecido"})
                except BaseException as e:  # noqa: BLE001
                    return self._json({"ok": False, "erro": str(e)[:500]})

            # -------------------------------------------------- utilidades
            def _receber(self, destino: Path, n: int):
                destino.parent.mkdir(parents=True, exist_ok=True)
                with open(destino, "wb") as f:
                    resto = n
                    while resto > 0:
                        bloco = self.rfile.read(min(1 << 20, resto))
                        if not bloco:
                            break
                        f.write(bloco)
                        resto -= len(bloco)

            def _json(self, obj, cod=200):
                self._enviar(cod, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

            def _enviar(self, cod, corpo, tipo):
                self.send_response(cod)
                self.send_header("Content-Type", tipo)
                self.send_header("Content-Length", str(len(corpo)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(corpo)

            def _arquivo(self, p: Path | None):
                if not p or not Path(p).is_file():
                    return self._enviar(404, b"", "text/plain")
                p = Path(p)
                tam = p.stat().st_size
                ini, fim = 0, tam - 1
                m = re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range", ""))
                if m:
                    if m.group(1):
                        ini = int(m.group(1))
                        if m.group(2):
                            fim = min(int(m.group(2)), tam - 1)
                    elif m.group(2):
                        ini = max(0, tam - int(m.group(2)))
                    self.send_response(206)
                    self.send_header("Content-Range", f"bytes {ini}-{fim}/{tam}")
                else:
                    self.send_response(200)
                tipo = {".mp4": "video/mp4", ".m4a": "audio/mp4", ".mp3": "audio/mpeg", ".jpg": "image/jpeg",
                        ".gif": "image/gif", ".webp": "image/webp", ".wav": "audio/wav", ".ogg": "audio/ogg",
                        ".webm": "video/webm", ".mov": "video/quicktime", ".opus": "audio/ogg", ".flac": "audio/flac",
                        ".png": "image/png", ".ttf": "font/ttf", ".otf": "font/otf", ".ico": "image/x-icon"}
                # não confia no mimetypes do Windows (ele lê o registro, que às vezes está errado)
                self.send_header("Content-Type", tipo.get(p.suffix.lower()) or mimetypes.guess_type(p.name)[0]
                                 or "application/octet-stream")
                self.send_header("Accept-Ranges", "bytes")
                self.send_header("Content-Length", str(fim - ini + 1))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                try:
                    with open(p, "rb") as f:
                        f.seek(ini)
                        resto = fim - ini + 1
                        while resto > 0:
                            bloco = f.read(min(1 << 20, resto))
                            if not bloco:
                                break
                            self.wfile.write(bloco)
                            resto -= len(bloco)
                except (ConnectionResetError, BrokenPipeError, ConnectionAbortedError):
                    pass

        srv = ThreadingHTTPServer(("127.0.0.1", self.porta), H)
        srv.daemon_threads = True
        srv.serve_forever()


# ===================================================================== registro de erros
def info_ambiente() -> str:
    """Versões de tudo o que importa para diagnosticar um erro."""
    import platform
    from importlib import metadata
    from . import VERSAO
    linhas = [f"Estúdio {VERSAO} · Python {platform.python_version()} · {platform.platform()}"]
    pacotes = []
    for pkg in ("faster-whisper", "ctranslate2", "av", "numpy", "opencv-python", "nvidia-cublas-cu12", "nvidia-cudnn-cu12"):
        try:
            pacotes.append(f"{pkg} {metadata.version(pkg)}")
        except Exception:  # noqa: BLE001
            pacotes.append(f"{pkg} -")
    linhas.append(" · ".join(pacotes))
    try:
        r = subprocess.run(["ffmpeg", "-hide_banner", "-version"], capture_output=True, text=True, timeout=10)
        linhas.append((r.stdout.splitlines() or ["ffmpeg ?"])[0])
    except Exception as e:  # noqa: BLE001
        linhas.append(f"ffmpeg: {e}")
    try:
        r = subprocess.run(["nvidia-smi", "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader"],
                           capture_output=True, text=True, timeout=10)
        linhas.append("Placa: " + (r.stdout.strip() or "não encontrada"))
    except Exception:  # noqa: BLE001
        linhas.append("Placa: nvidia-smi indisponível")
    return "\n".join(linhas)


def registrar_erro(video: Path, acao: str, e: BaseException) -> str:
    """Grava o erro completo em erros.log (pasta do programa) e devolve o texto para a tela."""
    import traceback
    texto = (f"===== {time.strftime('%Y-%m-%d %H:%M:%S')} · {acao} · {video.name}\n"
             + info_ambiente() + "\n\n"
             + "".join(traceback.format_exception(type(e), e, e.__traceback__)))
    try:
        with open(RAIZ / "erros.log", "a", encoding="utf-8") as f:
            f.write(texto + "\n")
    except Exception:  # noqa: BLE001
        pass
    print(texto, flush=True)
    return texto[-6000:]


# ===================================================================== janela do aplicativo
def _navegador_app() -> str | None:
    cands = [shutil.which("msedge"), shutil.which("chrome")]
    for base in (os.environ.get("ProgramFiles(x86)", ""), os.environ.get("ProgramFiles", ""),
                 os.environ.get("LOCALAPPDATA", "")):
        if base:
            cands += [os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                      os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")]
    return next((c for c in cands if c and os.path.isfile(c)), None)


def _processo_vivo(pid: int) -> bool:
    if sys.platform != "win32":
        try:
            os.kill(pid, 0)
            return True
        except OSError:
            return False
    import ctypes
    k = ctypes.windll.kernel32
    h = k.OpenProcess(0x1000, False, int(pid))   # PROCESS_QUERY_LIMITED_INFORMATION
    if not h:
        return False
    codigo = ctypes.c_ulong()
    ok = k.GetExitCodeProcess(h, ctypes.byref(codigo))
    k.CloseHandle(h)
    return bool(ok) and codigo.value == 259   # STILL_ACTIVE


_instalando_janela = False


def _preparar_janela_propria() -> None:
    """Instala o pywebview (janela própria, sem o Edge) em segundo plano, uma vez só."""
    global _instalando_janela
    if _instalando_janela:
        return
    _instalando_janela = True

    def instalar():
        try:
            py = Path(sys.executable)
            py = py.parent / "python.exe" if py.name.lower() == "pythonw.exe" and (py.parent / "python.exe").exists() else py
            uv = RAIZ / "tools" / "uv.exe"
            cmd = ([str(uv), "pip", "install", "--python", str(py), "pywebview>=6"] if uv.exists()
                   else [str(py), "-m", "pip", "install", "--disable-pip-version-check", "pywebview>=6"])
            r = subprocess.run(cmd, cwd=RAIZ, capture_output=True, text=True, timeout=900,
                               env={**os.environ, "UV_CACHE_DIR": str(RAIZ / ".cache" / "uv")},
                               creationflags=0x08000000)
            info("Janela própria do Estúdio pronta (vale na próxima vez que abrir)." if r.returncode == 0
                 else f"Não instalei a janela própria: {(r.stderr or '').strip()[-200:]}")
        except Exception as e:  # noqa: BLE001
            aviso(f"Não instalei a janela própria: {e}")
    threading.Thread(target=instalar, daemon=True).start()


def abrir_janela(porta: int = PORTA_PADRAO) -> None:
    """Abre o estúdio numa janela própria (com o ícone do Estúdio na barra de tarefas)."""
    if os.environ.get("EDITOR_SEM_NAVEGADOR"):
        return
    url = f"http://127.0.0.1:{porta}/"
    if sys.platform == "win32":
        import importlib.util
        if importlib.util.find_spec("webview") is not None:
            exe = Path(sys.executable)
            pyw = exe.parent / "pythonw.exe"
            subprocess.Popen([str(pyw if pyw.exists() else exe), "-m", "editor.janela", str(porta)], cwd=str(RAIZ),
                             creationflags=0x00000008 | 0x00000200)
            return
        _preparar_janela_propria()   # desta vez abre do jeito antigo; da próxima, já na janela própria
    nav = _navegador_app()
    if nav:
        perfil = RAIZ / ".janela"
        subprocess.Popen([nav, f"--app={url}", "--window-size=1500,920", f"--user-data-dir={perfil}",
                          "--no-first-run", "--disable-features=Translate"])
    else:
        webbrowser.open(url)


def _ping(porta: int) -> dict | None:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{porta}/api/ping", timeout=1.5) as r:
            d = json.load(r)
            return d if d.get("app") == "estudio" else None
    except Exception:  # noqa: BLE001
        return None


def _ja_rodando(porta: int) -> bool:
    return _ping(porta) is not None


def _porta_livre(porta: int) -> bool:
    import socket
    with socket.socket() as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", porta)) != 0


def _fechar_versao_antiga(porta: int) -> bool:
    """Depois de uma atualização, o Estúdio antigo pode continuar aberto (ele fica em segundo
    plano) e seguir rodando o código velho. Pede para ele sair; se for antigo demais para
    entender o pedido, encerra o processo que ocupa a porta."""
    try:
        req = urllib.request.Request(f"http://127.0.0.1:{porta}/api/sair", data=b"{}",
                                     headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=3).read()
    except Exception:  # noqa: BLE001
        pass
    for _ in range(20):
        if _porta_livre(porta):
            return True
        time.sleep(0.25)
    if sys.platform == "win32":
        try:
            r = subprocess.run(["netstat", "-ano", "-p", "TCP"], capture_output=True, text=True, timeout=15)
            pids = {ln.split()[-1] for ln in r.stdout.splitlines()
                    if f"127.0.0.1:{porta} " in ln and "LISTEN" in ln.upper()}
            for pid in pids:
                if pid.isdigit() and int(pid) != os.getpid():
                    subprocess.run(["taskkill", "/F", "/PID", pid], capture_output=True, timeout=15)
        except Exception as e:  # noqa: BLE001
            aviso(f"Não consegui fechar o Estúdio antigo: {e}")
    for _ in range(40):
        if _porta_livre(porta):
            return True
        time.sleep(0.25)
    return False


def _enviar_para_rodando(porta: int, caminhos: list[str]) -> None:
    req = urllib.request.Request(f"http://127.0.0.1:{porta}/api/adicionar",
                                 data=json.dumps({"caminhos": caminhos}).encode(),
                                 headers={"Content-Type": "application/json"})
    urllib.request.urlopen(req, timeout=10).read()


def principal() -> None:
    ap = argparse.ArgumentParser(prog="editor", description="Estúdio de vídeo automático")
    ap.add_argument("videos", nargs="*", help="vídeos para adicionar")
    ap.add_argument("--sem-janela", action="store_true", help="não abre a janela ao iniciar (início com o Windows)")
    ap.add_argument("--refazer", action="store_true", help="ignora transcrição/análise já salvas")
    ap.add_argument("--vigiar", action="store_true", help="(compatibilidade) igual a abrir o estúdio")
    ap.add_argument("--nao-abrir-pasta", action="store_true")
    args = ap.parse_args()
    args.sem_janela_auto = False
    if sys.stdout is None or sys.stderr is None:   # aberto pelo ícone (sem janela preta): registra em arquivo
        log = open(RAIZ / "estudio.log", "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stdout or log
        sys.stderr = sys.stderr or log
    if sys.platform == "win32":
        try:
            sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            pass

    cfg = carregar_config()
    porta = int(cfg.get("revisao", {}).get("porta", PORTA_PADRAO))
    videos = []
    for v in args.videos:
        p = Path(v)
        if p.is_dir():
            videos += [str(f.resolve()) for f in sorted(p.iterdir()) if f.suffix.lower() in organizer.EXTENSOES]
        elif p.is_file():
            videos.append(str(p.resolve()))

    from . import VERSAO
    rodando = _ping(porta)
    if rodando and rodando.get("versao") != VERSAO:
        info(f"Atualizando: fechando o Estúdio {rodando.get('versao') or 'antigo'} que estava aberto…")
        if _fechar_versao_antiga(porta):
            rodando = None
    if rodando:   # o estúdio já está aberto: só entrega os vídeos e mostra a janela
        if videos:
            _enviar_para_rodando(porta, videos)
        try:
            urllib.request.urlopen(urllib.request.Request(f"http://127.0.0.1:{porta}/api/mostrar_janela", data=b"{}",
                                                          headers={"Content-Type": "application/json"}), timeout=5).read()
        except Exception:  # noqa: BLE001
            abrir_janela(porta)
        return

    exigir_ffmpeg()
    threading.Thread(target=ia.ligar_local, args=(cfg,), daemon=True).start()   # liga o Ollama escondido, se preciso
    est = Estudio(cfg, args)
    threading.Thread(target=est.servir, daemon=True).start()
    if est.atualizador.ligado():
        est.atualizador.conferir_em_segundo_plano()
    threading.Thread(target=est.trabalhador, daemon=True).start()
    print("\n" + "=" * 64)
    print(f"  ESTÚDIO DE VÍDEO LIGADO  (versão {VERSAO})")
    print(f"  Painel: http://127.0.0.1:{porta}/")
    print(f"  IA: {ia.descricao(cfg)}")
    if organizer.ativa(cfg):
        ent, dst = organizer.pastas(cfg)
        print(f"  Solte os vídeos crus em:  {ent}")
        print(f"  Biblioteca organizada em: {dst}")
        threading.Thread(target=est.vigiar, daemon=True).start()
    print("  (deixe esta janela aberta ou minimizada; feche para desligar)")
    print("=" * 64, flush=True)
    est.restaurar()
    for v in videos:
        est.adicionar(Path(v))
    if not args.sem_janela:
        est.mostrar_janela()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n  Estúdio desligado.")
